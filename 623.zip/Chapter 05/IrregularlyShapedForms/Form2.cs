using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace IrregularlyShapedForms
{
	/// <summary>
	/// Summary description for Form2.
	/// </summary>
	public class Form2 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Button Button1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form2()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// Button1
			// 
			this.Button1.Location = new System.Drawing.Point(20, 24);
			this.Button1.Name = "Button1";
			this.Button1.Size = new System.Drawing.Size(136, 36);
			this.Button1.TabIndex = 1;
			this.Button1.Text = "Button1";
			// 
			// Form2
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Button1});
			this.Name = "Form2";
			this.Text = "Shaped Form";
			this.Load += new System.EventHandler(this.Form2_Load);
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new Form2());
		}

		private void Form2_Load(object sender, System.EventArgs e)
		{
			GraphicsPath path = new GraphicsPath();
			path.AddEllipse(0, 0, this.Width / 2, this.Height / 2);
			path.AddRectangle(new Rectangle(this.Width / 2, this.Top / 2, this.Width / 2, this.Top / 2));
			path.AddEllipse(this.Width / 2, this.Height / 2, this.Width / 2, this.Height / 2);
			this.Region = new Region(path);
		}

	}
}
