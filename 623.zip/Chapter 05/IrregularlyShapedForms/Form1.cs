using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Drawing.Drawing2D;

namespace IrregularlyShapedForms
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Label lblDrag;
		internal System.Windows.Forms.PictureBox picFour;
		internal System.Windows.Forms.PictureBox picThree;
		internal System.Windows.Forms.PictureBox picOne;
		internal System.Windows.Forms.PictureBox picTwo;
		internal System.Windows.Forms.ImageList imgNormalButtons;
		internal System.Windows.Forms.ImageList imgSelectedButtons;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.lblDrag = new System.Windows.Forms.Label();
			this.picFour = new System.Windows.Forms.PictureBox();
			this.picThree = new System.Windows.Forms.PictureBox();
			this.picOne = new System.Windows.Forms.PictureBox();
			this.picTwo = new System.Windows.Forms.PictureBox();
			this.imgNormalButtons = new System.Windows.Forms.ImageList(this.components);
			this.imgSelectedButtons = new System.Windows.Forms.ImageList(this.components);
			this.SuspendLayout();
			// 
			// lblDrag
			// 
			this.lblDrag.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(224)), ((System.Byte)(224)));
			this.lblDrag.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDrag.Location = new System.Drawing.Point(80, 36);
			this.lblDrag.Name = "lblDrag";
			this.lblDrag.Size = new System.Drawing.Size(124, 20);
			this.lblDrag.TabIndex = 9;
			this.lblDrag.Text = "      < Drag Here! >";
			this.lblDrag.MouseUp += new System.Windows.Forms.MouseEventHandler(this.lblDrag_MouseUp);
			this.lblDrag.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lblDrag_MouseMove);
			this.lblDrag.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lblDrag_MouseDown);
			// 
			// picFour
			// 
			this.picFour.Image = ((System.Drawing.Bitmap)(resources.GetObject("picFour.Image")));
			this.picFour.Location = new System.Drawing.Point(44, 176);
			this.picFour.Name = "picFour";
			this.picFour.Size = new System.Drawing.Size(209, 29);
			this.picFour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.picFour.TabIndex = 8;
			this.picFour.TabStop = false;
			this.picFour.Tag = "3";
			this.picFour.Click += new System.EventHandler(this.picFour_Click);
			this.picFour.MouseEnter += new System.EventHandler(this.pic_MouseEnter);
			this.picFour.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pic_MouseUp);
			this.picFour.MouseLeave += new System.EventHandler(this.pic_MouseLeave);
			this.picFour.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pic_MouseDown);
			// 
			// picThree
			// 
			this.picThree.Image = ((System.Drawing.Bitmap)(resources.GetObject("picThree.Image")));
			this.picThree.Location = new System.Drawing.Point(44, 144);
			this.picThree.Name = "picThree";
			this.picThree.Size = new System.Drawing.Size(209, 27);
			this.picThree.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.picThree.TabIndex = 7;
			this.picThree.TabStop = false;
			this.picThree.Tag = "2";
			this.picThree.MouseEnter += new System.EventHandler(this.pic_MouseEnter);
			this.picThree.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pic_MouseUp);
			this.picThree.MouseLeave += new System.EventHandler(this.pic_MouseLeave);
			this.picThree.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pic_MouseDown);
			// 
			// picOne
			// 
			this.picOne.Image = ((System.Drawing.Bitmap)(resources.GetObject("picOne.Image")));
			this.picOne.Location = new System.Drawing.Point(44, 80);
			this.picOne.Name = "picOne";
			this.picOne.Size = new System.Drawing.Size(209, 26);
			this.picOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.picOne.TabIndex = 6;
			this.picOne.TabStop = false;
			this.picOne.Tag = "0";
			this.picOne.MouseEnter += new System.EventHandler(this.pic_MouseEnter);
			this.picOne.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pic_MouseUp);
			this.picOne.MouseLeave += new System.EventHandler(this.pic_MouseLeave);
			this.picOne.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pic_MouseDown);
			// 
			// picTwo
			// 
			this.picTwo.Image = ((System.Drawing.Bitmap)(resources.GetObject("picTwo.Image")));
			this.picTwo.Location = new System.Drawing.Point(44, 112);
			this.picTwo.Name = "picTwo";
			this.picTwo.Size = new System.Drawing.Size(209, 28);
			this.picTwo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.picTwo.TabIndex = 5;
			this.picTwo.TabStop = false;
			this.picTwo.Tag = "1";
			this.picTwo.MouseEnter += new System.EventHandler(this.pic_MouseEnter);
			this.picTwo.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pic_MouseUp);
			this.picTwo.MouseLeave += new System.EventHandler(this.pic_MouseLeave);
			this.picTwo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pic_MouseDown);
			// 
			// imgNormalButtons
			// 
			this.imgNormalButtons.ColorDepth = System.Windows.Forms.ColorDepth.Depth16Bit;
			this.imgNormalButtons.ImageSize = new System.Drawing.Size(209, 29);
			this.imgNormalButtons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgNormalButtons.ImageStream")));
			this.imgNormalButtons.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// imgSelectedButtons
			// 
			this.imgSelectedButtons.ColorDepth = System.Windows.Forms.ColorDepth.Depth16Bit;
			this.imgSelectedButtons.ImageSize = new System.Drawing.Size(209, 29);
			this.imgSelectedButtons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgSelectedButtons.ImageStream")));
			this.imgSelectedButtons.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.BackgroundImage = ((System.Drawing.Bitmap)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblDrag,
																		  this.picFour,
																		  this.picThree,
																		  this.picOne,
																		  this.picTwo});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			GraphicsPath path = new GraphicsPath();
			path.AddEllipse(10, 50, this.Width - 20, this.Height - 60);
			this.Region = new Region(path);
			
			picOne.Image = imgNormalButtons.Images[0];
			picTwo.Image = imgNormalButtons.Images[1];
			picThree.Image = imgNormalButtons.Images[2];
			picFour.Image = imgNormalButtons.Images[3];
		}

		private void picFour_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void pic_MouseEnter(object sender, System.EventArgs e)
		{
			PictureBox pic = (PictureBox)sender;
			int imageIndex = int.Parse((pic.Tag.ToString()));
			pic.Image = imgSelectedButtons.Images[imageIndex];
		}

		private void pic_MouseLeave(object sender, System.EventArgs e)
		{
			PictureBox pic = (PictureBox)sender;
			int imageIndex = int.Parse((pic.Tag.ToString()));
			pic.Image = imgNormalButtons.Images[imageIndex];
		}

		private void pic_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			PictureBox pic = (PictureBox)sender;
			pic.Top += 2;
			pic.Left += 2;
		}

		private void pic_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			PictureBox pic = (PictureBox)sender;
			pic.Top -= 2;
			pic.Left -= 2;
		}

		private bool formDragging;
		private Point pointClicked;

		private void lblDrag_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			 // Set drag mode on.
			formDragging = true;

            // Store the offset where the control was clicked.
			pointClicked = new Point(e.X, e.Y);
		}

		private void lblDrag_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (formDragging)
			{
				Point pointMoveTo;
				
				// Find the current mouse position in screen coordinates.
				pointMoveTo = this.PointToScreen(new Point(e.X, e.Y));
				
				// Compensate for the position the control was clicked.
				pointMoveTo.Offset(-pointClicked.X, -pointClicked.Y);
				
				// Compensate for the non-client region (title bar).
				// This code is not necessary if you explicitly hide the title bar
				//  by setting the form's BorderStyle to None.
				pointMoveTo.Offset(0, -25);
				
				// Move the form.
				this.Location = pointMoveTo;
			}

		}

		private void lblDrag_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			formDragging = false;
		}

	}
}
