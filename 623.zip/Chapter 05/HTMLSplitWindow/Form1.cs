using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace HTMLSplitWindow
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Panel Panel3;
		internal System.Windows.Forms.TextBox TextBox1;
		internal System.Windows.Forms.Splitter Splitter1;
		internal System.Windows.Forms.Panel Panel2;
		private AxSHDocVw.AxWebBrowser AxWebBrowser2;
		internal System.Windows.Forms.Splitter Splitter2;
		internal System.Windows.Forms.Panel pnlShow;
		internal System.Windows.Forms.Button cmdShow;
		internal System.Windows.Forms.Panel pnlFileList;
		internal System.Windows.Forms.Button cmdHide;
		internal System.Windows.Forms.ListView ListView1;
		internal System.Windows.Forms.ColumnHeader ColumnHeader1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.Panel3 = new System.Windows.Forms.Panel();
			this.TextBox1 = new System.Windows.Forms.TextBox();
			this.Splitter1 = new System.Windows.Forms.Splitter();
			this.Panel2 = new System.Windows.Forms.Panel();
			this.AxWebBrowser2 = new AxSHDocVw.AxWebBrowser();
			this.Splitter2 = new System.Windows.Forms.Splitter();
			this.pnlShow = new System.Windows.Forms.Panel();
			this.cmdShow = new System.Windows.Forms.Button();
			this.pnlFileList = new System.Windows.Forms.Panel();
			this.cmdHide = new System.Windows.Forms.Button();
			this.ListView1 = new System.Windows.Forms.ListView();
			this.ColumnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.Panel3.SuspendLayout();
			this.Panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.AxWebBrowser2)).BeginInit();
			this.pnlShow.SuspendLayout();
			this.pnlFileList.SuspendLayout();
			this.SuspendLayout();
			// 
			// Panel3
			// 
			this.Panel3.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.TextBox1});
			this.Panel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.Panel3.Location = new System.Drawing.Point(204, 131);
			this.Panel3.Name = "Panel3";
			this.Panel3.Size = new System.Drawing.Size(239, 154);
			this.Panel3.TabIndex = 28;
			// 
			// TextBox1
			// 
			this.TextBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.TextBox1.Multiline = true;
			this.TextBox1.Name = "TextBox1";
			this.TextBox1.ReadOnly = true;
			this.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.TextBox1.Size = new System.Drawing.Size(240, 153);
			this.TextBox1.TabIndex = 0;
			this.TextBox1.Text = "";
			// 
			// Splitter1
			// 
			this.Splitter1.Dock = System.Windows.Forms.DockStyle.Top;
			this.Splitter1.Location = new System.Drawing.Point(204, 128);
			this.Splitter1.Name = "Splitter1";
			this.Splitter1.Size = new System.Drawing.Size(239, 3);
			this.Splitter1.TabIndex = 27;
			this.Splitter1.TabStop = false;
			// 
			// Panel2
			// 
			this.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.Panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.AxWebBrowser2});
			this.Panel2.Dock = System.Windows.Forms.DockStyle.Top;
			this.Panel2.Location = new System.Drawing.Point(204, 5);
			this.Panel2.Name = "Panel2";
			this.Panel2.Size = new System.Drawing.Size(239, 123);
			this.Panel2.TabIndex = 26;
			// 
			// AxWebBrowser2
			// 
			this.AxWebBrowser2.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.AxWebBrowser2.ContainingControl = this;
			this.AxWebBrowser2.Enabled = true;
			this.AxWebBrowser2.Location = new System.Drawing.Point(-4, 0);
			this.AxWebBrowser2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("AxWebBrowser2.OcxState")));
			this.AxWebBrowser2.Size = new System.Drawing.Size(240, 120);
			this.AxWebBrowser2.TabIndex = 0;
			// 
			// Splitter2
			// 
			this.Splitter2.Location = new System.Drawing.Point(201, 5);
			this.Splitter2.Name = "Splitter2";
			this.Splitter2.Size = new System.Drawing.Size(3, 280);
			this.Splitter2.TabIndex = 25;
			this.Splitter2.TabStop = false;
			// 
			// pnlShow
			// 
			this.pnlShow.Controls.AddRange(new System.Windows.Forms.Control[] {
																				  this.cmdShow});
			this.pnlShow.Dock = System.Windows.Forms.DockStyle.Left;
			this.pnlShow.Location = new System.Drawing.Point(181, 5);
			this.pnlShow.Name = "pnlShow";
			this.pnlShow.Size = new System.Drawing.Size(20, 280);
			this.pnlShow.TabIndex = 24;
			this.pnlShow.Visible = false;
			// 
			// cmdShow
			// 
			this.cmdShow.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left);
			this.cmdShow.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmdShow.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cmdShow.Name = "cmdShow";
			this.cmdShow.Size = new System.Drawing.Size(16, 280);
			this.cmdShow.TabIndex = 17;
			this.cmdShow.Text = ">";
			this.cmdShow.Click += new System.EventHandler(this.cmdShow_Click);
			// 
			// pnlFileList
			// 
			this.pnlFileList.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.cmdHide,
																					  this.ListView1});
			this.pnlFileList.Dock = System.Windows.Forms.DockStyle.Left;
			this.pnlFileList.Location = new System.Drawing.Point(5, 5);
			this.pnlFileList.Name = "pnlFileList";
			this.pnlFileList.Size = new System.Drawing.Size(176, 280);
			this.pnlFileList.TabIndex = 23;
			// 
			// cmdHide
			// 
			this.cmdHide.Anchor = ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.cmdHide.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmdHide.Location = new System.Drawing.Point(0, 260);
			this.cmdHide.Name = "cmdHide";
			this.cmdHide.Size = new System.Drawing.Size(172, 20);
			this.cmdHide.TabIndex = 1;
			this.cmdHide.Text = "<< Hide";
			this.cmdHide.Click += new System.EventHandler(this.cmdHide_Click);
			// 
			// ListView1
			// 
			this.ListView1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.ListView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.ColumnHeader1});
			this.ListView1.Name = "ListView1";
			this.ListView1.Size = new System.Drawing.Size(172, 256);
			this.ListView1.TabIndex = 0;
			this.ListView1.View = System.Windows.Forms.View.Details;
			this.ListView1.SelectedIndexChanged += new System.EventHandler(this.ListView1_SelectedIndexChanged);
			// 
			// ColumnHeader1
			// 
			this.ColumnHeader1.Text = "File";
			this.ColumnHeader1.Width = 99;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(448, 290);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Panel3,
																		  this.Splitter1,
																		  this.Panel2,
																		  this.Splitter2,
																		  this.pnlShow,
																		  this.pnlFileList});
			this.DockPadding.All = 5;
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "HTML Split";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Panel3.ResumeLayout(false);
			this.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.AxWebBrowser2)).EndInit();
			this.pnlShow.ResumeLayout(false);
			this.pnlFileList.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void cmdHide_Click(object sender, System.EventArgs e)
		{
			pnlFileList.Visible = false;
			pnlShow.Visible = true;
		}

		private void cmdShow_Click(object sender, System.EventArgs e)
		{
			pnlFileList.Visible = true;
			pnlShow.Visible = false;
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			DirectoryInfo d = new DirectoryInfo(Application.StartupPath + @"\..\..\view\");
			foreach (FileInfo f in d.GetFiles())
			{
				ListView1.Items.Add(f.Name);
			}

		}

		private void ListView1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			try
			{
				// Construct the objects required for the Navigate2 method call.
				// C# does not support optional parameters.
				string urlText = @"C:\Program Files\Microsoft Visual Studio .NET\FrameworkSDK\Samples\" + ListView1.SelectedItems[0].Text;
				object url = urlText;
				int emptyInt = 0;
				object empty = emptyInt;

				AxWebBrowser2.Navigate2(ref url, ref empty, ref empty, ref empty, ref empty);
				StreamReader r = File.OpenText(@"C:\Program Files\Microsoft Visual Studio .NET\FrameworkSDK\Samples\" + ListView1.SelectedItems[0].Text);
				TextBox1.Text = r.ReadToEnd();
			}
			catch
			{
			}

		}
	}
}
