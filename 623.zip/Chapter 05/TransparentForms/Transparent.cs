using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace TransparentForms
{
	/// <summary>
	/// Summary description for Form2.
	/// </summary>
	public class Transparent : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.GroupBox GroupBox1;
		internal System.Windows.Forms.Button cmdApply;
		internal System.Windows.Forms.NumericUpDown udOpacity;
		internal System.Windows.Forms.Label Label1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Transparent()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.GroupBox1 = new System.Windows.Forms.GroupBox();
			this.cmdApply = new System.Windows.Forms.Button();
			this.udOpacity = new System.Windows.Forms.NumericUpDown();
			this.Label1 = new System.Windows.Forms.Label();
			this.GroupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.udOpacity)).BeginInit();
			this.SuspendLayout();
			// 
			// GroupBox1
			// 
			this.GroupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.cmdApply,
																					this.udOpacity,
																					this.Label1});
			this.GroupBox1.Location = new System.Drawing.Point(12, 75);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Size = new System.Drawing.Size(268, 116);
			this.GroupBox1.TabIndex = 4;
			this.GroupBox1.TabStop = false;
			// 
			// cmdApply
			// 
			this.cmdApply.Location = new System.Drawing.Point(172, 64);
			this.cmdApply.Name = "cmdApply";
			this.cmdApply.Size = new System.Drawing.Size(80, 24);
			this.cmdApply.TabIndex = 5;
			this.cmdApply.Text = "Apply";
			this.cmdApply.Click += new System.EventHandler(this.cmdApply_Click);
			// 
			// udOpacity
			// 
			this.udOpacity.Increment = new System.Decimal(new int[] {
																		5,
																		0,
																		0,
																		0});
			this.udOpacity.Location = new System.Drawing.Point(88, 32);
			this.udOpacity.Name = "udOpacity";
			this.udOpacity.Size = new System.Drawing.Size(48, 21);
			this.udOpacity.TabIndex = 4;
			this.udOpacity.Value = new System.Decimal(new int[] {
																	50,
																	0,
																	0,
																	0});
			// 
			// Label1
			// 
			this.Label1.Location = new System.Drawing.Point(20, 36);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(56, 16);
			this.Label1.TabIndex = 3;
			this.Label1.Text = "Opacity:";
			// 
			// Form2
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.GroupBox1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form2";
			this.Text = "A Transparent Form";
			this.GroupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.udOpacity)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void cmdApply_Click(object sender, System.EventArgs e)
		{
			this.Opacity = (double)udOpacity.Value / 100;
		}

		[STAThread]
		static void Main() 
		{
			Application.Run(new Transparent());
		}
	}
}
