using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Docking
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.GroupBox GroupBox1;
		internal System.Windows.Forms.Button cmdUpdate;
		internal System.Windows.Forms.NumericUpDown udDockPaddingForm;
		internal System.Windows.Forms.NumericUpDown udDockPaddingPanel;
		internal System.Windows.Forms.ComboBox lstDockPanel;
		internal System.Windows.Forms.Label Label3;
		internal System.Windows.Forms.Label Label4;
		internal System.Windows.Forms.ComboBox lstDockTextBox;
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.Panel pnlDock;
		internal System.Windows.Forms.TextBox txtDock;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.GroupBox1 = new System.Windows.Forms.GroupBox();
			this.cmdUpdate = new System.Windows.Forms.Button();
			this.udDockPaddingForm = new System.Windows.Forms.NumericUpDown();
			this.udDockPaddingPanel = new System.Windows.Forms.NumericUpDown();
			this.lstDockPanel = new System.Windows.Forms.ComboBox();
			this.Label3 = new System.Windows.Forms.Label();
			this.Label4 = new System.Windows.Forms.Label();
			this.lstDockTextBox = new System.Windows.Forms.ComboBox();
			this.Label2 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.pnlDock = new System.Windows.Forms.Panel();
			this.txtDock = new System.Windows.Forms.TextBox();
			this.GroupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.udDockPaddingForm)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.udDockPaddingPanel)).BeginInit();
			this.pnlDock.SuspendLayout();
			this.SuspendLayout();
			// 
			// GroupBox1
			// 
			this.GroupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.cmdUpdate,
																					this.udDockPaddingForm,
																					this.udDockPaddingPanel,
																					this.lstDockPanel,
																					this.Label3,
																					this.Label4,
																					this.lstDockTextBox,
																					this.Label2,
																					this.Label1});
			this.GroupBox1.Location = new System.Drawing.Point(192, 20);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Size = new System.Drawing.Size(284, 224);
			this.GroupBox1.TabIndex = 12;
			this.GroupBox1.TabStop = false;
			this.GroupBox1.Text = "Configure";
			// 
			// cmdUpdate
			// 
			this.cmdUpdate.Location = new System.Drawing.Point(160, 180);
			this.cmdUpdate.Name = "cmdUpdate";
			this.cmdUpdate.Size = new System.Drawing.Size(84, 24);
			this.cmdUpdate.TabIndex = 10;
			this.cmdUpdate.Text = "Update";
			this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
			// 
			// udDockPaddingForm
			// 
			this.udDockPaddingForm.Increment = new System.Decimal(new int[] {
																				5,
																				0,
																				0,
																				0});
			this.udDockPaddingForm.Location = new System.Drawing.Point(160, 32);
			this.udDockPaddingForm.Name = "udDockPaddingForm";
			this.udDockPaddingForm.Size = new System.Drawing.Size(52, 21);
			this.udDockPaddingForm.TabIndex = 4;
			// 
			// udDockPaddingPanel
			// 
			this.udDockPaddingPanel.Increment = new System.Decimal(new int[] {
																				 5,
																				 0,
																				 0,
																				 0});
			this.udDockPaddingPanel.Location = new System.Drawing.Point(160, 56);
			this.udDockPaddingPanel.Name = "udDockPaddingPanel";
			this.udDockPaddingPanel.Size = new System.Drawing.Size(52, 21);
			this.udDockPaddingPanel.TabIndex = 5;
			this.udDockPaddingPanel.Value = new System.Decimal(new int[] {
																			 20,
																			 0,
																			 0,
																			 0});
			// 
			// lstDockPanel
			// 
			this.lstDockPanel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.lstDockPanel.Location = new System.Drawing.Point(156, 100);
			this.lstDockPanel.Name = "lstDockPanel";
			this.lstDockPanel.Size = new System.Drawing.Size(92, 21);
			this.lstDockPanel.TabIndex = 8;
			// 
			// Label3
			// 
			this.Label3.Location = new System.Drawing.Point(16, 104);
			this.Label3.Name = "Label3";
			this.Label3.Size = new System.Drawing.Size(136, 20);
			this.Label3.TabIndex = 6;
			this.Label3.Text = "Dock Panel To:";
			// 
			// Label4
			// 
			this.Label4.Location = new System.Drawing.Point(16, 128);
			this.Label4.Name = "Label4";
			this.Label4.Size = new System.Drawing.Size(136, 20);
			this.Label4.TabIndex = 7;
			this.Label4.Text = "Dock TextBox To:";
			// 
			// lstDockTextBox
			// 
			this.lstDockTextBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.lstDockTextBox.Location = new System.Drawing.Point(156, 124);
			this.lstDockTextBox.Name = "lstDockTextBox";
			this.lstDockTextBox.Size = new System.Drawing.Size(92, 21);
			this.lstDockTextBox.TabIndex = 9;
			// 
			// Label2
			// 
			this.Label2.Location = new System.Drawing.Point(16, 60);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(136, 20);
			this.Label2.TabIndex = 3;
			this.Label2.Text = "Set Panel\'s DockPadding:";
			// 
			// Label1
			// 
			this.Label1.Location = new System.Drawing.Point(16, 36);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(136, 20);
			this.Label1.TabIndex = 2;
			this.Label1.Text = "Set Form\'s DockPadding:";
			// 
			// pnlDock
			// 
			this.pnlDock.Controls.AddRange(new System.Windows.Forms.Control[] {
																				  this.txtDock});
			this.pnlDock.Dock = System.Windows.Forms.DockStyle.Left;
			this.pnlDock.DockPadding.All = 20;
			this.pnlDock.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.pnlDock.Name = "pnlDock";
			this.pnlDock.Size = new System.Drawing.Size(224, 314);
			this.pnlDock.TabIndex = 11;
			// 
			// txtDock
			// 
			this.txtDock.Dock = System.Windows.Forms.DockStyle.Left;
			this.txtDock.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtDock.Location = new System.Drawing.Point(20, 20);
			this.txtDock.Multiline = true;
			this.txtDock.Name = "txtDock";
			this.txtDock.Size = new System.Drawing.Size(108, 274);
			this.txtDock.TabIndex = 0;
			this.txtDock.Text = "I\'m docked to the edge of this Panel.\r\n\r\nThe Panel is docked to the edge of the f" +
				"orm.\r\n\r\nThe Panel\'s DockPadding gives the necessary room to breathe.";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(496, 314);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.GroupBox1,
																		  this.pnlDock});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "Docking At Work";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.GroupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.udDockPaddingForm)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.udDockPaddingPanel)).EndInit();
			this.pnlDock.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			lstDockPanel.Items.AddRange(Enum.GetNames(Dock.GetType()));
			lstDockTextBox.Items.AddRange(Enum.GetNames(Dock.GetType()));
		}

		private void cmdUpdate_Click(object sender, System.EventArgs e)
		{
			this.DockPadding.All = (int)udDockPaddingForm.Value;
			pnlDock.DockPadding.All = (int)udDockPaddingPanel.Value;
			
			// Now we use some rather unusual code to translate the string
			//  in the listbox into an enumeration object that can be used
			//  to set the Dock property.
			// This looks quite strange, but is actually just one more
			//  part of the shared class library.
			
			// First we get the converter that can do the job.
			TypeConverter converter;
			converter = TypeDescriptor.GetConverter(Dock.GetType());
			
			// Then we use it to convert the string.
			pnlDock.Dock = (DockStyle)converter.ConvertFromString(lstDockPanel.Text);
			txtDock.Dock = (DockStyle)converter.ConvertFromString(lstDockTextBox.Text);
		}
	}
}
