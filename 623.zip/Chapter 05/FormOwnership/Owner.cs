using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace FormOwnership
{
	/// <summary>
	/// Summary description for Owner.
	/// </summary>
	public class Owner : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Button cmdReleaseOwnership;
		internal System.Windows.Forms.Button cmdAddOwnership;
		private System.Windows.Forms.Label label1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Owner()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmdReleaseOwnership = new System.Windows.Forms.Button();
			this.cmdAddOwnership = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// cmdReleaseOwnership
			// 
			this.cmdReleaseOwnership.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmdReleaseOwnership.Location = new System.Drawing.Point(152, 196);
			this.cmdReleaseOwnership.Name = "cmdReleaseOwnership";
			this.cmdReleaseOwnership.Size = new System.Drawing.Size(128, 32);
			this.cmdReleaseOwnership.TabIndex = 3;
			this.cmdReleaseOwnership.Text = "Remove Ownership";
			this.cmdReleaseOwnership.Click += new System.EventHandler(this.cmdReleaseOwnership_Click);
			// 
			// cmdAddOwnership
			// 
			this.cmdAddOwnership.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmdAddOwnership.Location = new System.Drawing.Point(16, 196);
			this.cmdAddOwnership.Name = "cmdAddOwnership";
			this.cmdAddOwnership.Size = new System.Drawing.Size(120, 32);
			this.cmdAddOwnership.TabIndex = 2;
			this.cmdAddOwnership.Text = "Set Ownership";
			this.cmdAddOwnership.Click += new System.EventHandler(this.cmdAddOwnership_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(40, 36);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(216, 80);
			this.label1.TabIndex = 4;
			this.label1.Text = "To test form ownership, try minimizing this form when the second form is owned. T" +
				"hen try, minimizing it when the second form is not owned.";
			// 
			// Owner
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(292, 242);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.label1,
																		  this.cmdReleaseOwnership,
																		  this.cmdAddOwnership});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Owner";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Owner";
			this.Load += new System.EventHandler(this.Owner_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private OwnedForm frmOwned = new OwnedForm();

		private void Owner_Load(object sender, System.EventArgs e)
		{
			this.Show();
			frmOwned.Show();
		}

		private void cmdAddOwnership_Click(object sender, System.EventArgs e)
		{
			this.AddOwnedForm(frmOwned);
			frmOwned.lblState.Text = "I'm Owned";
		}

		private void cmdReleaseOwnership_Click(object sender, System.EventArgs e)
		{
			this.RemoveOwnedForm(frmOwned);
			frmOwned.lblState.Text = "I'm Free!";
		}

		[STAThread]
		static void Main() 
		{
			Application.Run(new Owner());
		}
	}
}
