using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace VisualInheritance
{
	/// <summary>
	/// Summary description for Ancestor.
	/// </summary>
	public class Ancestor : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.GroupBox GroupBox1;
		internal System.Windows.Forms.Button cmdNext;
		internal System.Windows.Forms.Panel Panel1;
		internal System.Windows.Forms.Label lblHeader;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Ancestor()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.GroupBox1 = new System.Windows.Forms.GroupBox();
			this.cmdNext = new System.Windows.Forms.Button();
			this.Panel1 = new System.Windows.Forms.Panel();
			this.lblHeader = new System.Windows.Forms.Label();
			this.Panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// GroupBox1
			// 
			this.GroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.GroupBox1.Location = new System.Drawing.Point(8, 225);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Size = new System.Drawing.Size(284, 4);
			this.GroupBox1.TabIndex = 5;
			this.GroupBox1.TabStop = false;
			this.GroupBox1.Text = "GroupBox1";
			// 
			// cmdNext
			// 
			this.cmdNext.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.cmdNext.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmdNext.Location = new System.Drawing.Point(232, 233);
			this.cmdNext.Name = "cmdNext";
			this.cmdNext.Size = new System.Drawing.Size(60, 28);
			this.cmdNext.TabIndex = 4;
			this.cmdNext.Text = "Next";
			this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
			// 
			// Panel1
			// 
			this.Panel1.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.Panel1.BackColor = System.Drawing.Color.White;
			this.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.lblHeader});
			this.Panel1.Location = new System.Drawing.Point(4, 5);
			this.Panel1.Name = "Panel1";
			this.Panel1.Size = new System.Drawing.Size(292, 68);
			this.Panel1.TabIndex = 3;
			// 
			// lblHeader
			// 
			this.lblHeader.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.lblHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblHeader.Location = new System.Drawing.Point(16, 16);
			this.lblHeader.Name = "lblHeader";
			this.lblHeader.Size = new System.Drawing.Size(262, 28);
			this.lblHeader.TabIndex = 0;
			this.lblHeader.Text = "Header Text";
			// 
			// Ancestor
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(300, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.GroupBox1,
																		  this.cmdNext,
																		  this.Panel1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Ancestor";
			this.Text = "Ancestor";
			this.Panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		protected virtual void cmdNext_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("Base Class Event");
		}

		public string HeaderText
		{
			get
			{
				return lblHeader.Text;
			}
			set
			{
				lblHeader.Text = value;
			}
		}

		
    
	}
}
