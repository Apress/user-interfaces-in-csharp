using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DynamicMenu
{
	public class DBPermissions
	{
		public enum State
		{
			Normal = 0,
			Disabled = 1,
			Hidden = 2
		}

		public enum Level
		{
			Admin,
			User
		}

		private static SqlConnection con = new SqlConnection("Data Source=localhost;"
			+ "Integrated Security=SSPI;Initial Catalog=Apress;");

		public static DataTable GetPermissions(Level userLevel)
		{
			con.Open();

			// Permissions isn't actually actually a table in our data source.
			// Instead, it's a view that combines the important information
			// from all three tables using a Join query.
			string selectPermissions = "SELECT * FROM Permissions ";

			switch (userLevel)
			{
				case Level.Admin:
					selectPermissions += "WHERE LevelName = 'Admin'";
					break;
				case Level.User:
					selectPermissions += "WHERE LevelName = 'User'";
					break;
			}

			SqlCommand cmd = new SqlCommand(selectPermissions, con);
			SqlDataAdapter adapter = new SqlDataAdapter(cmd);
			DataSet ds = new DataSet();
			adapter.Fill(ds, "Permissions");

			con.Close();

			return ds.Tables["Permissions"];
		}
	}

}
