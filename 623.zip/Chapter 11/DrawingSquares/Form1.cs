using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DrawingSquares
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.ContextMenu mnuForm;
		internal System.Windows.Forms.MenuItem mnuNewSquare;
		internal System.Windows.Forms.ContextMenu mnuLabel;
		internal System.Windows.Forms.MenuItem mnuColorChange;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mnuForm = new System.Windows.Forms.ContextMenu();
			this.mnuNewSquare = new System.Windows.Forms.MenuItem();
			this.mnuLabel = new System.Windows.Forms.ContextMenu();
			this.mnuColorChange = new System.Windows.Forms.MenuItem();
			// 
			// mnuForm
			// 
			this.mnuForm.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuNewSquare});
			// 
			// mnuNewSquare
			// 
			this.mnuNewSquare.Index = 0;
			this.mnuNewSquare.Text = "Create New Square";
			this.mnuNewSquare.Click += new System.EventHandler(this.mnuNewSquare_Click);
			// 
			// mnuLabel
			// 
			this.mnuLabel.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.mnuColorChange});
			// 
			// mnuColorChange
			// 
			this.mnuColorChange.Index = 0;
			this.mnuColorChange.Text = "Change Color";
			this.mnuColorChange.Click += new System.EventHandler(this.mnuColorChange_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(628, 426);
			this.ContextMenu = this.mnuForm;
			this.Name = "Form1";
			this.Text = "Form1";
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void mnuNewSquare_Click(object sender, System.EventArgs e)
		{
			// Create and configure the "square".
			Label newLabel = new Label();
			newLabel.Size = new Size(40, 40);
			newLabel.BorderStyle = BorderStyle.FixedSingle;

			// To determine where to place the label, you need to convert the 
			// current screen-based mouse coordinates into relative form coordinates.
			newLabel.Location = this.PointToClient(Control.MousePosition);

			// Attach a context menu to the label.
			newLabel.ContextMenu = mnuLabel;

			// Connect the label to all its event handlers.
			newLabel.MouseDown += new MouseEventHandler(lbl_MouseDown);
			newLabel.MouseMove += new MouseEventHandler(lbl_MouseMove);
			newLabel.MouseUp += new MouseEventHandler(lbl_MouseUp);

			// Add the label to the form.
			this.Controls.Add(newLabel);

		}


		// Keep track of when fake drag or resize mode is enabled.
		private bool isDragging = false;
		private bool isResizing = false;

		// Store the location where the user clicked on the control.
		private int clickOffsetX, clickOffsetY;

		private void lbl_MouseDown(object sender,
			System.Windows.Forms.MouseEventArgs e)
		{
			// Retrieve a reference to the active label.
			Control currentCtrl;
			currentCtrl = (Control)sender;

			if (e.Button == MouseButtons.Right)
			{
				// Show the context menu.
				currentCtrl.ContextMenu.Show(currentCtrl, new Point(e.X, e.Y));
			}
			else if (e.Button == MouseButtons.Left)
			{
				clickOffsetX = e.X;
				clickOffsetY = e.Y;

				if ((e.X + 5) > currentCtrl.Width && (e.Y + 5) > currentCtrl.Height)
				{
					// The mouse pointer is in the bottom right corner,
					// so resizing mode is appropriate.
					isResizing = true;
				}
				else
				{
					// The mouse is somewhere else, so dragging mode is
					// appropriate.
					isDragging = true;
				}
			}
		}

		private void lbl_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			// Retrieve a reference to the active label.
			Control currentCtrl;
			currentCtrl = (Control)sender;

			if (isDragging)
			{
				// Move the control.
				currentCtrl.Left += e.X - clickOffsetX;
				currentCtrl.Top += e.Y  - clickOffsetY;
			}
			else if (isResizing)
			{
				// Resize the control.
				currentCtrl.Width = e.X;
				currentCtrl.Height = e.Y;
			}
			else
			{
				// Change the pointer if the mouse is in the bottom corner.
				if ((e.X + 5) > currentCtrl.Width && (e.Y + 5) > currentCtrl.Height)
				{
					currentCtrl.Cursor = Cursors.SizeNWSE;
				}
				else
				{
					currentCtrl.Cursor = Cursors.Arrow;
				}
			}
		}
		private void lbl_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			isDragging = false;
			isResizing = false;
		}

		private void mnuColorChange_Click(object sender, System.EventArgs e)
		{
			// Show color dialog.
			ColorDialog dlgColor = new ColorDialog();
			dlgColor.ShowDialog();

			// Change label background.
			mnuLabel.SourceControl.BackColor = dlgColor.Color;

		}

		private void Form1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				this.ContextMenu.Show(this, new Point(e.X, e.Y));
			}
        
		}

	}
}
