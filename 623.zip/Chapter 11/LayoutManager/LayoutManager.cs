using System;
using System.Windows.Forms;

namespace LayoutManager
{
	public class SingleLineFlow
	{
		private Control container;
		private int margin;

		public SingleLineFlow(Control parent, int margin)
		{
			this.container = parent;
			this.margin = margin;

			// Attach the event handler.
			container.Layout += new LayoutEventHandler(UpdateLayout);

			// Refresh the layout.
			UpdateLayout(this, null);
		}

		public int Margin
		{
			get
			{
				return margin;
			}
			set
			{
				margin = value;
			}
		}

		// This is public so it can be triggered manually if needed.
		public void UpdateLayout(object sender,
			System.Windows.Forms.LayoutEventArgs e)
		{
			int y = 0;
			foreach (Control ctrl in container.Controls)
			{
				y += Margin;
				ctrl.Left = Margin;
				ctrl.Top = y;
				ctrl.Width = container.Width;
				ctrl.Height = Margin;
			}
		}

	}

}
