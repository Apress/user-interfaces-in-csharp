using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;


namespace SystemTrayApp
{
	public class App
	{
		// Define the system tray icon control.
		private NotifyIcon appIcon = new NotifyIcon();

		// Define the menu.
		private ContextMenu sysTrayMenu = new ContextMenu();
		private MenuItem displayFiles = new MenuItem("Display New Files");
		private MenuItem exitApp = new MenuItem("Exit");

		// Define the file system watcher, and a list to store filenames.
		private FileSystemWatcher watch = new FileSystemWatcher();
		private ArrayList newFiles = new ArrayList();

		public void Start()
		{
			// Configure the system tray icon.
			Icon ico = new Icon("icon.ico");
			appIcon.Icon = ico;
			appIcon.Text = "My .NET Application";


		   // Place the menu items in the menu.
		   sysTrayMenu.MenuItems.Add(displayFiles);
			sysTrayMenu.MenuItems.Add(exitApp);
			appIcon.ContextMenu = sysTrayMenu;

			// Show the system tray icon.
			appIcon.Visible = true;

			// Hook up the file watcher.
			watch.Path = "c:\\";
			watch.IncludeSubdirectories = true;
			watch.EnableRaisingEvents = true;

			// Attach event handlers.
			watch.Created += new FileSystemEventHandler(FileCreated);
			displayFiles.Click += new EventHandler(DisplayFiles);
			exitApp.Click += new EventHandler(ExitApp);

		}

		private void FileCreated(object sender, System.IO.FileSystemEventArgs e)
		{
			newFiles.Add(e.Name);
		}
		private void ExitApp(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void DisplayFiles(object sender, System.EventArgs e)
		{
			FileList frmFileList = new FileList();
			frmFileList.FillList(newFiles);
			frmFileList.Show();
		}




		public static void Main()
		{
			App app = new App();
			app.Start();

			// Because no forms are being displayed, you need this 
			// statement to stop the application from automatically ending.
			Application.Run();
		}

	}


}
