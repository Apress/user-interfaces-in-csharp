using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace GDI_Basics
{
	/// <summary>
	/// Summary description for PenCaps.
	/// </summary>
	public class PenCaps : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public PenCaps()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// PenCaps
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(424, 330);
			this.Name = "PenCaps";
			this.Text = "PenCaps";
			this.Resize += new System.EventHandler(this.PenCaps_Resize);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.PenCaps_Paint);

		}
		#endregion

		private void PenCaps_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Pen myPen = new Pen(Color.Blue, 10);
			int y  = 20;
			
			foreach (LineCap cap in System.Enum.GetValues(typeof(LineCap)))
			{
				myPen.StartCap = cap;
				myPen.EndCap = cap;
				e.Graphics.DrawLine(myPen, 20, y, 100, y);
				e.Graphics.DrawString(cap.ToString(), new Font("Tahoma", 8), Brushes.Black, 120, y - 10);
				y += 30;
			}
		}

		[STAThread]
		static void Main() 
		{
			Application.Run(new PenCaps());
		}

		private void PenCaps_Resize(object sender, System.EventArgs e)
		{
			this.Invalidate();
		}
	}
}
