using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;


namespace GDI_Basics
{
	/// <summary>
	/// Summary description for ControlPaint.
	/// </summary>
	public class ControlPaintForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ControlPaintForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// ControlPaint
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Name = "ControlPaint";
			this.Text = "ControlPaint";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ControlPaint_Paint);

		}
		#endregion

		private void ControlPaint_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			ControlPaint.DrawCheckBox(e.Graphics, new Rectangle(10, 10, 50, 50), ButtonState.Checked);
			ControlPaint.DrawCheckBox(e.Graphics, new Rectangle(70, 10, 30, 30), ButtonState.Normal);
			ControlPaint.DrawCheckBox(e.Graphics, new Rectangle(110, 10, 20, 20), ButtonState.Checked);
			
			ControlPaint.DrawButton(e.Graphics, new Rectangle(10, 80, 20, 20), ButtonState.Checked);
			ControlPaint.DrawButton(e.Graphics, new Rectangle(50, 80, 20, 20), ButtonState.Flat);
			ControlPaint.DrawButton(e.Graphics, new Rectangle(90, 80, 20, 20), ButtonState.Normal);
			ControlPaint.DrawFocusRectangle(e.Graphics, new Rectangle(130, 80, 20, 20));
			
			ControlPaint.DrawGrid(e.Graphics, new Rectangle(10, 120, 250, 50), new Size(5, 5), Color.Blue);
			ControlPaint.DrawScrollButton(e.Graphics, new Rectangle(10, 180, 20, 20), ScrollButton.Left, ButtonState.Normal);
			ControlPaint.DrawScrollButton(e.Graphics, new Rectangle(50, 180, 20, 20), ScrollButton.Max, ButtonState.Pushed);
			ControlPaint.DrawScrollButton(e.Graphics, new Rectangle(90, 180, 20, 20), ScrollButton.Up, ButtonState.Normal);
			
			ControlPaint.DrawMenuGlyph(e.Graphics, new Rectangle(10, 220, 20, 20), MenuGlyph.Arrow);
			ControlPaint.DrawMenuGlyph(e.Graphics, new Rectangle(50, 220, 20, 20), MenuGlyph.Checkmark);
			ControlPaint.DrawMenuGlyph(e.Graphics, new Rectangle(90, 220, 20, 20), MenuGlyph.Max);
		}

		[STAThread]
		static void Main() 
		{
			Application.Run(new ControlPaintForm());
		}

	}
}
