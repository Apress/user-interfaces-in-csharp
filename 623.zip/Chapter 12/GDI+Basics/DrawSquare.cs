using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace GDI_Basics
{
	/// <summary>
	/// Summary description for DrawSquare.
	/// </summary>
	public class DrawSquare : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.StatusBar StatusBar1;
		internal System.Windows.Forms.StatusBarPanel pnlSquares;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DrawSquare()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.StatusBar1 = new System.Windows.Forms.StatusBar();
			this.pnlSquares = new System.Windows.Forms.StatusBarPanel();
			((System.ComponentModel.ISupportInitialize)(this.pnlSquares)).BeginInit();
			this.SuspendLayout();
			// 
			// StatusBar1
			// 
			this.StatusBar1.Location = new System.Drawing.Point(0, 244);
			this.StatusBar1.Name = "StatusBar1";
			this.StatusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.pnlSquares});
			this.StatusBar1.ShowPanels = true;
			this.StatusBar1.Size = new System.Drawing.Size(292, 22);
			this.StatusBar1.SizingGrip = false;
			this.StatusBar1.TabIndex = 1;
			this.StatusBar1.Text = "statusBar1";
			// 
			// pnlSquares
			// 
			this.pnlSquares.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.pnlSquares.Width = 292;
			// 
			// DrawSquare
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.StatusBar1});
			this.Name = "DrawSquare";
			this.Text = "DrawSquare";
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.DrawSquare_MouseDown);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.DrawSquare_Paint);
			((System.ComponentModel.ISupportInitialize)(this.pnlSquares)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion


		// Store the squares that are painted on the form.
		ArrayList squares = new ArrayList();

		private void DrawSquare_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				// Add a square and update the screen.
				Rectangle square = new Rectangle(e.X, e.Y, 20, 20);
				squares.Add(square);
				this.Invalidate(square);
			}
			else if (e.Button == MouseButtons.Right)
			{
				// Search  for the clicked square.
				int squareNumber = 0;
				foreach (Rectangle square in squares)
				{
					squareNumber++;
					if (square.Contains(e.X, e.Y))
					{
						MessageBox.Show("Point inside square #" +
							squareNumber.ToString());
					}
				}
			}

		}

		private void DrawSquare_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Pen drawingPen = new Pen(Color.Red, 10);
			foreach (Rectangle square in squares)
			{
				e.Graphics.DrawRectangle(drawingPen, square);
			}

			pnlSquares.Text = " " + squares.Count.ToString() + " squares";

		}


		[STAThread]
		static void Main() 
		{
			Application.Run(new DrawSquare());
		}
	}
}
