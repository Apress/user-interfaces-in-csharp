using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace GDI_Basics
{
	/// <summary>
	/// Summary description for PenDashStyles.
	/// </summary>
	public class PenDashStyles : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public PenDashStyles()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// PenDashStyles
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(500, 398);
			this.Name = "PenDashStyles";
			this.Text = "PenDashStyles";
			this.Resize += new System.EventHandler(this.PenDashStyles_Resize);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.PenDashStyles_Paint);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new PenDashStyles());
		}

		private void PenDashStyles_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Pen myPen = new Pen(Color.Blue, 10);
			int y = 20;
			foreach (DashStyle dash in System.Enum.GetValues(typeof(DashStyle)))
			{
				myPen.DashStyle = dash;
				e.Graphics.DrawLine(myPen, 20, y, 100, y);
				e.Graphics.DrawString(dash.ToString(), new Font("Tahoma", 8), Brushes.Black, 120, y - 10);
				y += 30;
			}
			
			y += 10;
			myPen.StartCap = LineCap.Round;
			myPen.EndCap = LineCap.Round;
			
			foreach (DashStyle dash in System.Enum.GetValues(typeof(DashStyle)))
			{
				myPen.DashStyle = dash;
				e.Graphics.DrawLine(myPen, 20, y, 100, y);
				e.Graphics.DrawString(dash.ToString() + " (with round caps)", new Font("Tahoma", 8), Brushes.Black, 120, y - 10);
				y += 30;
			}
		}

		private void PenDashStyles_Resize(object sender, System.EventArgs e)
		{
			this.Invalidate();
		}
	}
}
