using System;
using System.IO;
using System.Windows.Forms;
using System.Windows.Forms.Design;
using System.ComponentModel.Design;
using System.ComponentModel;
using System.Drawing.Design;

namespace DirectoryTreeControl
{
	public class DirectoryTreeDesigner : ControlDesigner
	{
		private DesignerVerbCollection verbs = new DesignerVerbCollection();

		public DirectoryTreeDesigner()
		{
			verbs.Add(new DesignerVerb("Set Drive",
				new EventHandler(OnVerb)));
		}

		public override DesignerVerbCollection Verbs
		{
			get
			{
				return verbs;
			}
		}

		protected void OnVerb(object sender, EventArgs e)
		{
			// Show the form.
			SelectDrive frm = new SelectDrive();
			frm.DriveSelection = ((DirectoryTree)this.Control).Drive;
			frm.ShowDialog();

			// Adjust the associated control.
			((DirectoryTree)this.Control).Drive = frm.DriveSelection;

			// Notify the IDE that the Drive property has changed.
			PropertyDescriptorCollection properties;
			properties = TypeDescriptor.GetProperties(typeof(DirectoryTree));
			PropertyDescriptor changedProperty = properties.Find("Drive", false);
			this.RaiseComponentChanged(changedProperty, "", frm.DriveSelection);
		}

		protected override void PostFilterProperties(System.Collections.IDictionary 
			properties)
		{
			properties.Remove("Nodes");
		}

	}


}
