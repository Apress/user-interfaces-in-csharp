using System;
using System.Windows.Forms;
using System.Data;

namespace CustomTreeViewControl
{
	public class ProjectUserTree : TreeView
	{
		// Use an enumeration to represent the three types of nodes.
		public enum NodeType
		{
			Project,
			User
		}

		// Define a new type of higher-level event for node selection.
		public delegate void ItemSelectEventHandler(object sender,
			ItemSelectEventArgs e);

			public class ItemSelectEventArgs : EventArgs
			{
				public NodeType Type;
				public DataRow ItemData;
			}

		// Define the events that use this signature and event arguments.
		public event ItemSelectEventHandler UserSelect;
        public event ItemSelectEventHandler ProjectSelect;
		
		// Store references to the two main node branches.
		private TreeNode nodeProjects = new TreeNode("Projects", 0, 0);
		private TreeNode nodeUsers = new TreeNode("Users", 1, 1);

		// Add the main level of nodes when the control is instantiated.
		public ProjectUserTree() : base()
		{
			base.Nodes.Add(nodeProjects);
			base.Nodes.Add(nodeUsers);
		}

		// Provide a specialized method the client can use to add projects.
		// Store the corresponding DataRow.
		public void AddProject(DataRow project)
		{
			TreeNode nodeNew = new TreeNode(project["Name"].ToString(), 2, 3);
			nodeNew.Tag = project;
			nodeProjects.Nodes.Add(nodeNew);
		}

		// Provide a specialized method the client can use to add users.
		// Store the correspnding DataRow.
		public void AddUser(DataRow user)
		{
			TreeNode nodeNew = new TreeNode(user["Name"].ToString(), 2, 3);
			nodeNew.Tag = user;
			nodeUsers.Nodes.Add(nodeNew);
		}

		// When a node is selected, retrieve the DataRow and raise the event.
		protected override void OnAfterSelect(TreeViewEventArgs e)
		 {
			base.OnAfterSelect(e);

				 ItemSelectEventArgs arg = new ItemSelectEventArgs();
				 arg.ItemData = (DataRow)e.Node.Tag;

				 if (e.Node.Parent == nodeProjects)
				 {
					 arg.Type = NodeType.Project;
					 ProjectSelect(this, arg);
				 }
				 else if (e.Node.Parent == nodeUsers)
				 {
					 arg.Type = NodeType.User;
					 UserSelect(this, arg);
				 }

			 }
	}

}
