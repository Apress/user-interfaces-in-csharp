using System;
using System.Windows.Forms;

namespace CustomTreeViewControl
{


		public class ProjectTree : TreeView
		{
			// Use an enumeration to represent the three types of nodes.
			// Specific numbers correspond to the database field code.
			public enum StatusType
			{
				Unassigned = 101,
				InProgress = 102,
				Closed = 103
			}

			// Store references to the three main node branches.
			private TreeNode nodeUnassigned = new TreeNode("Unassigned", 0, 0);
			private TreeNode nodeInProgress = new TreeNode("In Progress", 1, 1);
			private TreeNode nodeClosed = new TreeNode("Closed", 2, 2);

			// Add the main level of nodes when the control is instantiated.
			public ProjectTree() : base()
			{
				base.Nodes.Add(nodeUnassigned);
				base.Nodes.Add(nodeInProgress);
				base.Nodes.Add(nodeClosed);
			}

			// Provide a specialized method the client can use to add nodes.
			public void AddProject(string name, StatusType status)
			{
				TreeNode nodeNew = new TreeNode(name, 3, 4);
				nodeNew.Tag = status;

				switch (status)
				{
					case StatusType.Unassigned:
						nodeUnassigned.Nodes.Add(nodeNew);
						break;
					case StatusType.InProgress:
						nodeInProgress.Nodes.Add(nodeNew);
						break;
					case StatusType.Closed:
						nodeClosed.Nodes.Add(nodeNew);
						break;
				}
			}
		}

	}

