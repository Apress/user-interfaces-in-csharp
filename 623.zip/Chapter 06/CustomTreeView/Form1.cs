using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using CustomTreeViewControl;

namespace CustomTreeView
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.ImageList imagesTree;
		private CustomTreeViewControl.ProjectTree tree;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.imagesTree = new System.Windows.Forms.ImageList(this.components);
			this.tree = new CustomTreeViewControl.ProjectTree();
			this.SuspendLayout();
			// 
			// imagesTree
			// 
			this.imagesTree.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imagesTree.ImageSize = new System.Drawing.Size(16, 16);
			this.imagesTree.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imagesTree.ImageStream")));
			this.imagesTree.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// tree
			// 
			this.tree.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.tree.ImageList = this.imagesTree;
			this.tree.Location = new System.Drawing.Point(8, 4);
			this.tree.Name = "tree";
			this.tree.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
																			 new System.Windows.Forms.TreeNode("Unassigned", 0, 0),
																			 new System.Windows.Forms.TreeNode("In Progress", 1, 1),
																			 new System.Windows.Forms.TreeNode("Closed", 2, 2)});
			this.tree.Scrollable = false;
			this.tree.Size = new System.Drawing.Size(320, 296);
			this.tree.TabIndex = 0;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(336, 310);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.tree});
			this.Name = "Form1";
			this.Text = "ProjectUserTree";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			tree.AddProject("Migration to .NET", ProjectTree.StatusType.InProgress);
			tree.AddProject("Revamp pricing site", ProjectTree.StatusType.Unassigned);
			tree.AddProject("Prepare L-DAP feasibility report", ProjectTree.StatusType.Unassigned);
			tree.AddProject("Update E201-G to Windows XP", ProjectTree.StatusType.Closed);
            tree.AddProject("Annual meeting", ProjectTree.StatusType.Closed);
		}
	}


}
