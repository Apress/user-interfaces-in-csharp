using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ToolBarExample
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.ContextMenu ContextMenu1;
		internal System.Windows.Forms.MenuItem MenuItem1;
		internal System.Windows.Forms.MenuItem MenuItem2;
		internal System.Windows.Forms.MenuItem MenuItem3;
		internal System.Windows.Forms.ImageList imagesToolBar;
		internal System.Windows.Forms.ImageList imagesLarge;
		internal System.Windows.Forms.ToolBar ToolBar4;
		internal System.Windows.Forms.ToolBarButton ToolBarButton13;
		internal System.Windows.Forms.ToolBarButton ToolBarButton16;
		internal System.Windows.Forms.ToolBar ToolBar3;
		internal System.Windows.Forms.ToolBarButton ToolBarButton8;
		internal System.Windows.Forms.ToolBarButton ToolBarButton9;
		internal System.Windows.Forms.ToolBarButton ToolBarButton12;
		internal System.Windows.Forms.ToolBar ToolBar2;
		internal System.Windows.Forms.ToolBarButton ToolBarButton4;
		internal System.Windows.Forms.ToolBarButton ToolBarButton5;
		internal System.Windows.Forms.ToolBarButton ToolBarButton6;
		internal System.Windows.Forms.ToolBarButton ToolBarButton7;
		internal System.Windows.Forms.ToolBar ToolBar1;
		internal System.Windows.Forms.ToolBarButton ToolBarButton1;
		internal System.Windows.Forms.ToolBarButton ToolBarButton2;
		internal System.Windows.Forms.ToolBarButton ToolBarButton3;
		internal System.Windows.Forms.ToolBarButton ToolBarButton10;
		internal System.Windows.Forms.Label Label4;
		internal System.Windows.Forms.Label Label3;
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.Label Label1;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.ContextMenu1 = new System.Windows.Forms.ContextMenu();
			this.MenuItem1 = new System.Windows.Forms.MenuItem();
			this.MenuItem2 = new System.Windows.Forms.MenuItem();
			this.MenuItem3 = new System.Windows.Forms.MenuItem();
			this.imagesToolBar = new System.Windows.Forms.ImageList(this.components);
			this.imagesLarge = new System.Windows.Forms.ImageList(this.components);
			this.ToolBar4 = new System.Windows.Forms.ToolBar();
			this.ToolBarButton13 = new System.Windows.Forms.ToolBarButton();
			this.ToolBarButton16 = new System.Windows.Forms.ToolBarButton();
			this.ToolBar3 = new System.Windows.Forms.ToolBar();
			this.ToolBarButton8 = new System.Windows.Forms.ToolBarButton();
			this.ToolBarButton9 = new System.Windows.Forms.ToolBarButton();
			this.ToolBarButton12 = new System.Windows.Forms.ToolBarButton();
			this.ToolBar2 = new System.Windows.Forms.ToolBar();
			this.ToolBarButton4 = new System.Windows.Forms.ToolBarButton();
			this.ToolBarButton5 = new System.Windows.Forms.ToolBarButton();
			this.ToolBarButton6 = new System.Windows.Forms.ToolBarButton();
			this.ToolBarButton7 = new System.Windows.Forms.ToolBarButton();
			this.ToolBar1 = new System.Windows.Forms.ToolBar();
			this.ToolBarButton1 = new System.Windows.Forms.ToolBarButton();
			this.ToolBarButton2 = new System.Windows.Forms.ToolBarButton();
			this.ToolBarButton3 = new System.Windows.Forms.ToolBarButton();
			this.ToolBarButton10 = new System.Windows.Forms.ToolBarButton();
			this.Label4 = new System.Windows.Forms.Label();
			this.Label3 = new System.Windows.Forms.Label();
			this.Label2 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// ContextMenu1
			// 
			this.ContextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.MenuItem1,
																						 this.MenuItem2,
																						 this.MenuItem3});
			// 
			// MenuItem1
			// 
			this.MenuItem1.Index = 0;
			this.MenuItem1.Text = "Menu 1";
			// 
			// MenuItem2
			// 
			this.MenuItem2.Index = 1;
			this.MenuItem2.Text = "Menu 2";
			// 
			// MenuItem3
			// 
			this.MenuItem3.Index = 2;
			this.MenuItem3.Text = "Menu 3";
			// 
			// imagesToolBar
			// 
			this.imagesToolBar.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imagesToolBar.ImageSize = new System.Drawing.Size(16, 16);
			this.imagesToolBar.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imagesToolBar.ImageStream")));
			this.imagesToolBar.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// imagesLarge
			// 
			this.imagesLarge.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imagesLarge.ImageSize = new System.Drawing.Size(32, 32);
			this.imagesLarge.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imagesLarge.ImageStream")));
			this.imagesLarge.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// ToolBar4
			// 
			this.ToolBar4.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this.ToolBar4.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						this.ToolBarButton13,
																						this.ToolBarButton16});
			this.ToolBar4.DropDownArrows = true;
			this.ToolBar4.ImageList = this.imagesToolBar;
			this.ToolBar4.Location = new System.Drawing.Point(0, 89);
			this.ToolBar4.Name = "ToolBar4";
			this.ToolBar4.ShowToolTips = true;
			this.ToolBar4.Size = new System.Drawing.Size(344, 25);
			this.ToolBar4.TabIndex = 9;
			this.ToolBar4.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right;
			// 
			// ToolBarButton13
			// 
			this.ToolBarButton13.DropDownMenu = this.ContextMenu1;
			this.ToolBarButton13.ImageIndex = 0;
			this.ToolBarButton13.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.ToolBarButton13.Text = "One";
			// 
			// ToolBarButton16
			// 
			this.ToolBarButton16.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// ToolBar3
			// 
			this.ToolBar3.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this.ToolBar3.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						this.ToolBarButton8,
																						this.ToolBarButton9,
																						this.ToolBarButton12});
			this.ToolBar3.DropDownArrows = true;
			this.ToolBar3.ImageList = this.imagesToolBar;
			this.ToolBar3.Location = new System.Drawing.Point(0, 64);
			this.ToolBar3.Name = "ToolBar3";
			this.ToolBar3.ShowToolTips = true;
			this.ToolBar3.Size = new System.Drawing.Size(344, 25);
			this.ToolBar3.TabIndex = 8;
			this.ToolBar3.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right;
			// 
			// ToolBarButton8
			// 
			this.ToolBarButton8.ImageIndex = 0;
			this.ToolBarButton8.Pushed = true;
			this.ToolBarButton8.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.ToolBarButton8.Text = "One";
			// 
			// ToolBarButton9
			// 
			this.ToolBarButton9.ImageIndex = 1;
			this.ToolBarButton9.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.ToolBarButton9.Text = "Two";
			// 
			// ToolBarButton12
			// 
			this.ToolBarButton12.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// ToolBar2
			// 
			this.ToolBar2.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this.ToolBar2.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						this.ToolBarButton4,
																						this.ToolBarButton5,
																						this.ToolBarButton6,
																						this.ToolBarButton7});
			this.ToolBar2.DropDownArrows = true;
			this.ToolBar2.ImageList = this.imagesToolBar;
			this.ToolBar2.Location = new System.Drawing.Point(0, 39);
			this.ToolBar2.Name = "ToolBar2";
			this.ToolBar2.ShowToolTips = true;
			this.ToolBar2.Size = new System.Drawing.Size(344, 25);
			this.ToolBar2.TabIndex = 7;
			this.ToolBar2.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right;
			// 
			// ToolBarButton4
			// 
			this.ToolBarButton4.ImageIndex = 0;
			this.ToolBarButton4.Text = "One";
			// 
			// ToolBarButton5
			// 
			this.ToolBarButton5.ImageIndex = 1;
			this.ToolBarButton5.Text = "Two";
			// 
			// ToolBarButton6
			// 
			this.ToolBarButton6.ImageIndex = 2;
			this.ToolBarButton6.Text = "Three";
			// 
			// ToolBarButton7
			// 
			this.ToolBarButton7.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// ToolBar1
			// 
			this.ToolBar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this.ToolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						this.ToolBarButton1,
																						this.ToolBarButton2,
																						this.ToolBarButton3,
																						this.ToolBarButton10});
			this.ToolBar1.DropDownArrows = true;
			this.ToolBar1.ImageList = this.imagesToolBar;
			this.ToolBar1.Name = "ToolBar1";
			this.ToolBar1.ShowToolTips = true;
			this.ToolBar1.Size = new System.Drawing.Size(344, 39);
			this.ToolBar1.TabIndex = 6;
			// 
			// ToolBarButton1
			// 
			this.ToolBarButton1.ImageIndex = 0;
			this.ToolBarButton1.Text = "One";
			// 
			// ToolBarButton2
			// 
			this.ToolBarButton2.ImageIndex = 1;
			this.ToolBarButton2.Text = "Two";
			// 
			// ToolBarButton3
			// 
			this.ToolBarButton3.ImageIndex = 2;
			this.ToolBarButton3.Text = "Three";
			// 
			// ToolBarButton10
			// 
			this.ToolBarButton10.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// Label4
			// 
			this.Label4.ForeColor = System.Drawing.Color.Navy;
			this.Label4.Location = new System.Drawing.Point(104, 92);
			this.Label4.Name = "Label4";
			this.Label4.Size = new System.Drawing.Size(112, 16);
			this.Label4.TabIndex = 13;
			this.Label4.Text = "Drop-Down Button";
			// 
			// Label3
			// 
			this.Label3.ForeColor = System.Drawing.Color.Navy;
			this.Label3.Location = new System.Drawing.Point(136, 68);
			this.Label3.Name = "Label3";
			this.Label3.Size = new System.Drawing.Size(88, 16);
			this.Label3.TabIndex = 12;
			this.Label3.Text = "Toggle Buttons";
			// 
			// Label2
			// 
			this.Label2.ForeColor = System.Drawing.Color.Navy;
			this.Label2.Location = new System.Drawing.Point(192, 40);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(72, 16);
			this.Label2.TabIndex = 11;
			this.Label2.Text = "Text on Right";
			// 
			// Label1
			// 
			this.Label1.ForeColor = System.Drawing.Color.Navy;
			this.Label1.Location = new System.Drawing.Point(128, 12);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(64, 16);
			this.Label1.TabIndex = 10;
			this.Label1.Text = "Flat Buttons";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(344, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Label4,
																		  this.Label3,
																		  this.Label2,
																		  this.Label1,
																		  this.ToolBar4,
																		  this.ToolBar3,
																		  this.ToolBar2,
																		  this.ToolBar1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
	}
}
