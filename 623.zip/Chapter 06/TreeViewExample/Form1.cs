using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace TreeViewExample
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.TreeView treeFood;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.treeFood = new System.Windows.Forms.TreeView();
			this.SuspendLayout();
			// 
			// treeFood
			// 
			this.treeFood.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.treeFood.ImageIndex = -1;
			this.treeFood.Location = new System.Drawing.Point(4, 5);
			this.treeFood.Name = "treeFood";
			this.treeFood.SelectedImageIndex = -1;
			this.treeFood.Size = new System.Drawing.Size(284, 256);
			this.treeFood.TabIndex = 1;
			this.treeFood.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeFood_AfterSelect);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.treeFood});
			this.Name = "Form1";
			this.Text = "TreeView Example";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			TreeNode node;
			
			node = treeFood.Nodes.Add("Fruits");
			node.Nodes.Add("Apple");
			node.Nodes.Add("Peach");
            
			node = treeFood.Nodes.Add("Vegetables");
			node.Nodes.Add("Tomato");
			node.Nodes.Add("Eggplant");
		}

		private void treeFood_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			if (e.Action == TreeViewAction.ByMouse)
			{
				MessageBox.Show(e.Node.FullPath);
			}
		}
	}
}
