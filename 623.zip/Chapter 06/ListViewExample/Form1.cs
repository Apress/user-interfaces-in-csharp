using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ListViewExample
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.GroupBox GroupBox1;
		internal System.Windows.Forms.RadioButton optLargeIcon;
		internal System.Windows.Forms.RadioButton optList;
		internal System.Windows.Forms.RadioButton optDetails;
		internal System.Windows.Forms.RadioButton optSmallIcon;
		internal System.Windows.Forms.Button cmdFillList;
		internal System.Windows.Forms.ListView listAuthors;
		internal System.Windows.Forms.ImageList imagesLarge;
		internal System.Windows.Forms.ImageList imagesSmall;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.GroupBox1 = new System.Windows.Forms.GroupBox();
			this.optLargeIcon = new System.Windows.Forms.RadioButton();
			this.optList = new System.Windows.Forms.RadioButton();
			this.optDetails = new System.Windows.Forms.RadioButton();
			this.optSmallIcon = new System.Windows.Forms.RadioButton();
			this.cmdFillList = new System.Windows.Forms.Button();
			this.listAuthors = new System.Windows.Forms.ListView();
			this.imagesLarge = new System.Windows.Forms.ImageList(this.components);
			this.imagesSmall = new System.Windows.Forms.ImageList(this.components);
			this.GroupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// GroupBox1
			// 
			this.GroupBox1.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.GroupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.optLargeIcon,
																					this.optList,
																					this.optDetails,
																					this.optSmallIcon});
			this.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.GroupBox1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.GroupBox1.Location = new System.Drawing.Point(276, 12);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Size = new System.Drawing.Size(104, 132);
			this.GroupBox1.TabIndex = 5;
			this.GroupBox1.TabStop = false;
			this.GroupBox1.Text = "View";
			// 
			// optLargeIcon
			// 
			this.optLargeIcon.Checked = true;
			this.optLargeIcon.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.optLargeIcon.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.optLargeIcon.Location = new System.Drawing.Point(16, 48);
			this.optLargeIcon.Name = "optLargeIcon";
			this.optLargeIcon.Size = new System.Drawing.Size(76, 16);
			this.optLargeIcon.TabIndex = 0;
			this.optLargeIcon.TabStop = true;
			this.optLargeIcon.Text = "LargeIcon";
			this.optLargeIcon.CheckedChanged += new System.EventHandler(this.NewView);
			// 
			// optList
			// 
			this.optList.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.optList.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.optList.Location = new System.Drawing.Point(16, 96);
			this.optList.Name = "optList";
			this.optList.Size = new System.Drawing.Size(56, 16);
			this.optList.TabIndex = 0;
			this.optList.Text = "List";
			this.optList.CheckedChanged += new System.EventHandler(this.NewView);
			// 
			// optDetails
			// 
			this.optDetails.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.optDetails.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.optDetails.Location = new System.Drawing.Point(16, 72);
			this.optDetails.Name = "optDetails";
			this.optDetails.Size = new System.Drawing.Size(72, 16);
			this.optDetails.TabIndex = 0;
			this.optDetails.Text = "Details";
			this.optDetails.CheckedChanged += new System.EventHandler(this.NewView);
			// 
			// optSmallIcon
			// 
			this.optSmallIcon.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.optSmallIcon.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.optSmallIcon.Location = new System.Drawing.Point(16, 24);
			this.optSmallIcon.Name = "optSmallIcon";
			this.optSmallIcon.Size = new System.Drawing.Size(72, 16);
			this.optSmallIcon.TabIndex = 0;
			this.optSmallIcon.Text = "SmallIcon";
			this.optSmallIcon.CheckedChanged += new System.EventHandler(this.NewView);
			// 
			// cmdFillList
			// 
			this.cmdFillList.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.cmdFillList.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmdFillList.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cmdFillList.Location = new System.Drawing.Point(276, 152);
			this.cmdFillList.Name = "cmdFillList";
			this.cmdFillList.Size = new System.Drawing.Size(104, 24);
			this.cmdFillList.TabIndex = 4;
			this.cmdFillList.Text = "Fill List";
			this.cmdFillList.Click += new System.EventHandler(this.cmdFillList_Click);
			// 
			// listAuthors
			// 
			this.listAuthors.Activation = System.Windows.Forms.ItemActivation.OneClick;
			this.listAuthors.AllowColumnReorder = true;
			this.listAuthors.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.listAuthors.GridLines = true;
			this.listAuthors.HoverSelection = true;
			this.listAuthors.Location = new System.Drawing.Point(8, 8);
			this.listAuthors.Name = "listAuthors";
			this.listAuthors.Size = new System.Drawing.Size(260, 332);
			this.listAuthors.Sorting = System.Windows.Forms.SortOrder.Ascending;
			this.listAuthors.TabIndex = 3;
			this.listAuthors.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listAuthors_ColumnClick);
			// 
			// imagesLarge
			// 
			this.imagesLarge.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imagesLarge.ImageSize = new System.Drawing.Size(32, 32);
			this.imagesLarge.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imagesLarge.ImageStream")));
			this.imagesLarge.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// imagesSmall
			// 
			this.imagesSmall.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imagesSmall.ImageSize = new System.Drawing.Size(16, 16);
			this.imagesSmall.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imagesSmall.ImageStream")));
			this.imagesSmall.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(388, 349);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.GroupBox1,
																		  this.cmdFillList,
																		  this.listAuthors});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "ListView Example";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.GroupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void cmdFillList_Click(object sender, System.EventArgs e)
		{
			DataTable dt = StoreDB.GetProducts();

			// Suspending automatic refreshes as items are added/removed.
			listAuthors.BeginUpdate();

			listAuthors.SmallImageList = imagesSmall;
			listAuthors.LargeImageList = imagesLarge;
			foreach (DataRow dr in dt.Rows)
			{
				ListViewItem listItem = new ListViewItem(dr["ModelName"].ToString());
				listItem.ImageIndex = 0;

				// Add sub-items for Details view.
				listItem.SubItems.Add(dr["ProductID"].ToString());
				listItem.SubItems.Add(dr["Description"].ToString());

				listAuthors.Items.Add(listItem);
			}

			// Add column headers for Details view.
			listAuthors.Columns.Add("Product", 100, HorizontalAlignment.Left);
			listAuthors.Columns.Add("ID", 100, HorizontalAlignment.Left);
			listAuthors.Columns.Add("Description", 100, HorizontalAlignment.Left);

			// Re-enable the display.
			listAuthors.EndUpdate();

		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			optLargeIcon.Tag = View.LargeIcon;
			optSmallIcon.Tag = View.SmallIcon;
			optDetails.Tag = View.Details;
			optList.Tag = View.List;
			 cmdFillList_Click(null, null);
		}

		private void NewView(object sender, System.EventArgs e)
		{
			// Set the current view mode based on the number in the tag value of the
			// selected radio button.

			listAuthors.View = (View)(((Control)sender).Tag);

			// Display the current view style.
			this.Text = "Using View: " + listAuthors.View.ToString();
		}

		private void listAuthors_ColumnClick(object sender, System.Windows.Forms.ColumnClickEventArgs e)
		{
			// Specify an alphabetic sort based on the column that was clicked.
			listAuthors.ListViewItemSorter = new CompareListViewItems(e.Column, true);

			// Perform the sort.
			listAuthors.Sort();
		}

	}

	public class CompareListViewItems : IComparer
	{
		// This index identifies the column that is used for sorting
		public readonly int Column;

		// Is the sort alphabetic or number?
		public readonly bool Alphabetic;

		public CompareListViewItems(int columnIndex, bool alphabetic)
		{
			this.Column = columnIndex;
			this.Alphabetic = alphabetic;
		}

		public int Compare(object x, object y)
		{
			// Convert the items that must be compared into ListViewItem objects.
			string listX = ((ListViewItem)x).SubItems[Column].Text;
			string listY = ((ListViewItem)y).SubItems[Column].Text;

			// Sort using the specified column and specified sorting type.
			if (Alphabetic)
			{
				return listX.CompareTo(listY);
				
			}
			else
			{
				if (int.Parse(listX) > int.Parse(listY))
				{
					return 1;
				}
				else if (int.Parse(listX) == int.Parse(listY))
				{
					return 0;
				}
				else
				{
					return -1;
				}
			}
		}
	}


	public class StoreDB
	{
		public static DataTable GetProducts()
		{
			DataSet dsStore = new DataSet();
			dsStore.ReadXmlSchema(Application.StartupPath + "\\store.xsd");
			dsStore.ReadXml(Application.StartupPath + "\\store.xml");
			return dsStore.Tables["Products"];
		}
	}
}
