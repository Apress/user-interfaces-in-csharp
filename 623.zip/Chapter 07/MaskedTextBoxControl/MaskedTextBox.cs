using System;
using System.Windows.Forms;

namespace MaskedTextBoxControl
{
	public class MaskedTextBox : TextBox
	{
		private string mask;
		public string Mask
		{
			get
			{
				return mask;
			}
			set
			{
				mask = value;
				this.Text = "";
			}
		}

		protected override void OnKeyPress(KeyPressEventArgs e)
		{
			if (Mask != "")
			{
				// Suppress the typed character.
				e.Handled = true;

				string newText = this.Text;

				// Loop through the mask, adding fixed characters as needed.
				// If the next allowed character matches what the user has
				// typed in (a number or letter), that is added to the end.
				bool finished = false;
				for (int i = this.SelectionStart; i < mask.Length; i++)
				{
					switch (mask[i].ToString())
					{
						case "#" :
							// Allow the keypress as long as it is a number.
							if (Char.IsDigit(e.KeyChar))
							{
								newText += e.KeyChar.ToString();
								finished = true;
								break;
							}
							else
							{
								// Invalid entry; exit and don't change the text.
								return;
							}
						case "." :
							// Allow the keypress as long as it is a letter.
							if (Char.IsLetter(e.KeyChar))
							{
								newText += e.KeyChar.ToString();
								finished = true;
								break;
							}
							else
							{
								// Invalid entry; exit and don't change the text.
								return;
							}
						default :
							// Insert the mask character.
							newText += mask[i];
							break;
					}
					if (finished)
					{ break; }
				}

				// Update the text.
				this.Text = newText;
				this.SelectionStart = this.Text.Length;
			}
	}    
  
        protected override void OnKeyDown(KeyEventArgs e)
		{
			// Stop special characters.
			e.Handled = true;
		}

}

}
