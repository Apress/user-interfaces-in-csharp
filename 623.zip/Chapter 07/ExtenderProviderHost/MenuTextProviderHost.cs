using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ExtenderProviderHost
{
	/// <summary>
	/// Summary description for MenuTextProviderHost.
	/// </summary>
	public class MenuTextProviderHost : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.MainMenu mnuMain;
		internal System.Windows.Forms.MenuItem MenuItem1;
		internal System.Windows.Forms.MenuItem mnuNew;
		internal System.Windows.Forms.MenuItem mnuOpen;
		internal System.Windows.Forms.MenuItem mnuSave;
		private ExtenderProviderControls.MenuTextProvider menuTextProvider1;
		internal System.Windows.Forms.GroupBox GroupBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MenuTextProviderHost()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mnuMain = new System.Windows.Forms.MainMenu();
			this.MenuItem1 = new System.Windows.Forms.MenuItem();
			this.mnuNew = new System.Windows.Forms.MenuItem();
			this.mnuOpen = new System.Windows.Forms.MenuItem();
			this.mnuSave = new System.Windows.Forms.MenuItem();
			this.menuTextProvider1 = new ExtenderProviderControls.MenuTextProvider();
			this.GroupBox1 = new System.Windows.Forms.GroupBox();
			this.SuspendLayout();
			// 
			// mnuMain
			// 
			this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.MenuItem1});
			// 
			// MenuItem1
			// 
			this.MenuItem1.Index = 0;
			this.MenuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuNew,
																					  this.mnuOpen,
																					  this.mnuSave});
			this.MenuItem1.Text = "File";
			// 
			// mnuNew
			// 
			this.mnuNew.Index = 0;
			this.mnuNew.Text = "New";
			// 
			// mnuOpen
			// 
			this.mnuOpen.Index = 1;
			this.mnuOpen.Text = "Open";
			// 
			// mnuSave
			// 
			this.mnuSave.Index = 2;
			this.mnuSave.Text = "Save";
			// 
			// menuTextProvider1
			// 
			this.menuTextProvider1.Location = new System.Drawing.Point(0, 244);
			this.menuTextProvider1.Name = "menuTextProvider1";
			this.menuTextProvider1.Size = new System.Drawing.Size(292, 22);
			this.menuTextProvider1.TabIndex = 0;
			this.menuTextProvider1.Text = "menuTextProvider1";
			// 
			// GroupBox1
			// 
			this.GroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.GroupBox1.Location = new System.Drawing.Point(0, 240);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Size = new System.Drawing.Size(292, 4);
			this.GroupBox1.TabIndex = 2;
			this.GroupBox1.TabStop = false;
			this.GroupBox1.Text = "GroupBox1";
			// 
			// MenuTextProviderHost
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.GroupBox1,
																		  this.menuTextProvider1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Menu = this.mnuMain;
			this.Name = "MenuTextProviderHost";
			this.Text = "MenuTextProviderHost";
			this.Load += new System.EventHandler(this.MenuTextProviderHost_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void MenuTextProviderHost_Load(object sender, System.EventArgs e)
		{
			menuTextProvider1.SetHelpText(mnuNew, " Create a new document and abandon the current one.");
		}

		static void Main() 
		{
			Application.Run(new MenuTextProviderHost());
		}
	}
}
