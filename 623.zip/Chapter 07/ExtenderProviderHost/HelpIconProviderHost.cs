using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ExtenderProviderHost
{
	/// <summary>
	/// Summary description for HelpIconProviderHost.
	/// </summary>
	public class HelpIconProviderHost : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.TextBox TextBox2;
		internal System.Windows.Forms.TextBox TextBox1;
		private ExtenderProviderControls.HelpIconProvider helpIconProvider1;
		private System.ComponentModel.IContainer components;

		public HelpIconProviderHost()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.TextBox2 = new System.Windows.Forms.TextBox();
			this.TextBox1 = new System.Windows.Forms.TextBox();
			this.helpIconProvider1 = new ExtenderProviderControls.HelpIconProvider(this.components);
			this.SuspendLayout();
			// 
			// TextBox2
			// 
			this.TextBox2.Location = new System.Drawing.Point(24, 48);
			this.TextBox2.Name = "TextBox2";
			this.TextBox2.Size = new System.Drawing.Size(148, 20);
			this.TextBox2.TabIndex = 3;
			this.TextBox2.Text = "";
			// 
			// TextBox1
			// 
			this.TextBox1.Location = new System.Drawing.Point(24, 16);
			this.TextBox1.Name = "TextBox1";
			this.TextBox1.Size = new System.Drawing.Size(104, 20);
			this.TextBox1.TabIndex = 2;
			this.TextBox1.Text = "";
			// 
			// helpIconProvider1
			// 
			this.helpIconProvider1.HelpFile = null;
			// 
			// HelpIconProviderHost
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 150);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.TextBox2,
																		  this.TextBox1});
			this.Name = "HelpIconProviderHost";
			this.Text = "HelpIconProviderHost";
			this.Load += new System.EventHandler(this.HelpIconProviderHost_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void HelpIconProviderHost_Load(object sender, System.EventArgs e)
		{
			helpIconProvider1.HelpFile = "myhelp.hlp";
			helpIconProvider1.SetHelpID(TextBox1, "10001");
			helpIconProvider1.SetHelpID(TextBox2, "10002");
			helpIconProvider1.SetHelpID(TextBox1,"");
		}

		
		static void Main() 
		{
			Application.Run(new HelpIconProviderHost());
		}
	}
}
