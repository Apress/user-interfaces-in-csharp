using System;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections;

namespace ExtenderProviderControls
{
	[ProvideProperty("HelpText", typeof(string))]
	public class MenuTextProvider : StatusBar, IExtenderProvider
	{
		public bool CanExtend(object extendee)
		{
			if (extendee.GetType() == typeof(MenuItem))
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		private Hashtable helpText = new Hashtable();

		public void SetHelpText(object extendee, string value)
		{
			// Specifying an empty value removes the extension.
			if (value == "")
			{
				helpText.Remove(extendee);
				MenuItem mnu = (MenuItem)extendee;
				mnu.Select -= new EventHandler(MenuSelect);
			}
			else
			{
				helpText[extendee] = value;
				MenuItem mnu = (MenuItem)extendee;
				mnu.Select += new EventHandler(MenuSelect);
			}
		}

		public string GetHelpText(object extendee)
		{
			if (helpText[extendee] != null)
			{
				return helpText[extendee].ToString();
			}
			else
			{
				return string.Empty;
			}
			}

			private void MenuSelect(object sender, System.EventArgs e)
			{
				this.Text = helpText[sender].ToString();
			}

	}


}
