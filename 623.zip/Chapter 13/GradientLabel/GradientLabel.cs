using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Drawing.Design;

namespace GradientLabel
{
	/// <summary>
	/// Summary description for GradientLabel.
	/// </summary>
	public class GradientLabel : System.Windows.Forms.UserControl
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public GradientLabel()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// GradientLabel
			// 
			this.Name = "GradientLabel";
			this.Size = new System.Drawing.Size(372, 128);
			this.Load += new System.EventHandler(this.GradientLabel_Load);
			gradient.GradientChanged += new EventHandler(GradientChanged);

		}
		#endregion



		private string text;
		private GradientFill gradient = new GradientFill();

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		public GradientFill GradientFill
		{
			get
			{
				return gradient;
			}
			set
			{
				gradient = value;
				gradient.GradientChanged += new EventHandler(GradientChanged);
				this.Invalidate();
			}
		}


		private void GradientLabel_Load(object sender, System.EventArgs e)
		{
			this.ResizeRedraw=true;
		}

		[Browsable(true),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)] 
		public override string Text
		{
			get
			{
				return text;
			}
			set
			{
				text = value;
				this.Invalidate();
			}
		}

		protected override void OnPaintBackground(
			System.Windows.Forms.PaintEventArgs e)
		{
			LinearGradientBrush brush = new LinearGradientBrush(e.ClipRectangle, gradient.ColorA,
									 gradient.ColorB, gradient.GradientFillStyle);

			// Draw the gradient background.
			e.Graphics.FillRectangle(brush, e.ClipRectangle);
		}

		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			base.OnPaint(e);

			// Draw the label text.
			e.Graphics.DrawString(text, this.Font, new SolidBrush(this.ForeColor), 0, 0);
		}

		private void GradientChanged(object sender, EventArgs e)
		{
			this.Invalidate();
		}

	}




	[TypeConverter(typeof(ExpandableObjectConverter)), 
	Editor(typeof(GradientFillEditor), typeof(UITypeEditor))]
	public class GradientFill
	{
		private Color colorA = Color.LightBlue;
		private Color colorB = Color.Purple;
		private LinearGradientMode gradientStyle= LinearGradientMode.ForwardDiagonal;
    
		public event EventHandler GradientChanged;

		public Color ColorA
		{
			get
			{
				return colorA;
			}
			set
			{
				colorA = value;
				OnGradientChanged(new EventArgs());
			}
		}

		public Color ColorB
		{
			get
			{
				return colorB;
			}
			set
			{
				colorB = value;
				OnGradientChanged(new EventArgs());
			}
		}

		[System.ComponentModel.RefreshProperties(RefreshProperties.Repaint)]
		public LinearGradientMode GradientFillStyle
		{
			get
			{
				return gradientStyle;
			}
			set
			{
				gradientStyle = value;
				OnGradientChanged(new EventArgs());
			}
		}

		private void OnGradientChanged(EventArgs e)
		{
			if (GradientChanged != null)
			{
				GradientChanged(this, e);
			}
		}
	}


	public class GradientFillEditor : UITypeEditor
	{


		public override bool GetPaintValueSupported(
			System.ComponentModel.ITypeDescriptorContext context)
		{
			return true;
		}

		public override void PaintValue(
			System.Drawing.Design.PaintValueEventArgs e)
		{
			GradientFill fill = (GradientFill)e.Value;
			LinearGradientBrush brush = new LinearGradientBrush(e.Bounds,
				fill.ColorA, fill.ColorB, fill.GradientFillStyle);

			// Paint the thumbnail.
			e.Graphics.FillRectangle(brush, e.Bounds);
		}
	}

}
