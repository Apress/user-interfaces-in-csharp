using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace DrawingShapes
{
	public class Shape : System.Windows.Forms.UserControl
	{
		// The types of shapes supported by this control.
		public enum ShapeType
		{
			Rectangle,
			Ellipse,
			Triangle
		}

		private ShapeType shape = ShapeType.Rectangle;
		private GraphicsPath path = null;

		public ShapeType Type
		{
			get
			{
				return shape;
			}
			set
			{
				shape = value;
				RefreshPath();
				this.Invalidate();
			}
		}

		// Create the corresponding GraphicsPath for the shape, and apply
		// it to the control by setting the Region property.
		private void RefreshPath()
		{
			path = new GraphicsPath();
			switch (shape)
			{
				case ShapeType.Rectangle:
					path.AddRectangle(this.ClientRectangle);
					break;
				case ShapeType.Ellipse:
					path.AddEllipse(this.ClientRectangle);
					break;
				case ShapeType.Triangle:
					Point pt1 = new Point(this.Width / 2, 0);
					Point pt2 = new Point(0, this.Height);
					Point pt3 = new Point(this.Width, this.Height);
					path.AddPolygon(new Point[] {pt1, pt2, pt3});
					break;
			}
			this.Region = new Region(path);
		}

		protected override void OnResize(System.EventArgs e)
		{
			base.OnResize(e);
			RefreshPath();
			this.Invalidate();
		}

		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			base.OnPaint(e);
			if (path != null)
			{
				e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				e.Graphics.FillPath(new SolidBrush(this.BackColor), path);
				e.Graphics.DrawPath(new Pen(this.ForeColor, 4), path);
			}
		}

	}

}
