using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace SimpleChart
{
	/// <summary>
	/// Summary description for SimpleChart.
	/// </summary>
	public class SimpleChart : System.Windows.Forms.UserControl
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public SimpleChart()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// SimpleChart
			// 
			this.Name = "SimpleChart";
			this.Size = new System.Drawing.Size(372, 228);
			this.Resize += new System.EventHandler(this.SimpleChart_Resize);
			

		}
		#endregion

		private BarItemCollection bars = new BarItemCollection();

		public BarItemCollection Bars
		{
			get
			{
				return bars;
			}
			set
			{
				bars = value;
				RebuildChart();
			}
		}

		private int barWidth;
		decimal maxValue;

		public void RebuildChart()
		{
			if (bars.Count==0)
			{
				return;
			}

			// Find out how much space a single bar can occupy.
			barWidth = (int)(this.Width / bars.Count);

			// Set the maximum value on the chart.
			maxValue = 0;
			foreach (BarItem bar in bars)
			{
				if (bar.Value > maxValue)
				{
					maxValue = bar.Value;
				}
			}

			this.Invalidate();
		}

		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			base.OnPaint(e);

			if (bars.Count == 0)
			{
				return;
			}

			int x = 0;
			int baseLine = this.Height;
			Font textFont = new Font("Tahoma", 8);

			// Draw each item.
			foreach (BarItem bar in bars)
			{
				int height = (int)(bar.Value / maxValue * this.Height);
				int top = this.Height - height;

				// Draw bar (two rectangles are used for a shadowed effect),
				// along with an outline.
				e.Graphics.FillRectangle(Brushes.LightBlue, x + 4, top, 
					barWidth - 7, height);
				e.Graphics.DrawRectangle(new Pen(Color.White, 4), x + 4, top, 
					barWidth - 4, height);
				e.Graphics.FillRectangle(Brushes.SteelBlue, x + 8, top + 4, 
					barWidth - 9, height - 5);

				// Draw title.
				e.Graphics.DrawString(bar.ShortForm, textFont, Brushes.White,
					x + 15, top + 5);

				x += barWidth;
			}

			// Draw the grid.
			e.Graphics.DrawLine(Pens.Black, 0, this.Height - 1, this.Width,
				this.Height - 1);
			e.Graphics.DrawLine(Pens.Black, 0, 0, 0, this.Height);
		}

		private void SimpleChart_Resize(object sender, System.EventArgs e)
		{
			RebuildChart();
			this.Invalidate();
		}


	}
}
