using System;
using System.Collections;

namespace SimpleChart
{
	/// <summary>
	/// Summary description for BarItem.
	/// </summary>
	public class BarItem
	{
		public string ShortForm;
		public decimal Value;

		public BarItem(string shortForm, decimal value)
		{
			this.ShortForm = shortForm;
			this.Value = value;
		}
	}

	public class BarItemCollection : CollectionBase
	{
		public void Add(BarItem item)
		{
			this.List.Add(item);
		}

		public void Remove(int index)
		{
			// Check to see if there is an item at the supplied index.
			if ((index > Count - 1) || (index < 0 ))
		    {
			   throw new System.IndexOutOfRangeException();
		    }
			else
			{
				this.List.RemoveAt(index);
			}
		}

		public BarItem Item(int index)
		{
			// The appropriate item is retrieved from the List object and 
			// explicitly cast to the BarItem type.
			return (BarItem)this.List[index];
		}
	}

}
