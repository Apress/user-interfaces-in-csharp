using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace GradientLabelHost
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private GradientLabel.GradientLabel gradientLabel1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.gradientLabel1 = new GradientLabel.GradientLabel();
			this.SuspendLayout();
			// 
			// gradientLabel1
			// 
			this.gradientLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gradientLabel1.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.gradientLabel1.ForeColor = System.Drawing.Color.White;
			this.gradientLabel1.GradientFill.ColorA = System.Drawing.SystemColors.Info;
			this.gradientLabel1.GradientFill.ColorB = System.Drawing.Color.DarkViolet;
			this.gradientLabel1.GradientFill.GradientFillStyle = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
			this.gradientLabel1.Name = "gradientLabel1";
			this.gradientLabel1.Size = new System.Drawing.Size(596, 118);
			this.gradientLabel1.TabIndex = 0;
			this.gradientLabel1.Text = "Gradient Label Test";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(596, 118);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.gradientLabel1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
	}
}
