using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace HotTrackButtonHost
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private HotTrackButton.HotTrackButton hotTrackButton1;
		internal HotTrackButton.HotTrackButton hotTrackButton2;
		internal HotTrackButton.HotTrackButton HotTrackButton3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.hotTrackButton1 = new HotTrackButton.HotTrackButton();
			this.hotTrackButton2 = new HotTrackButton.HotTrackButton();
			this.HotTrackButton3 = new HotTrackButton.HotTrackButton();
			this.SuspendLayout();
			// 
			// hotTrackButton1
			// 
			this.hotTrackButton1.Image = ((System.Drawing.Bitmap)(resources.GetObject("hotTrackButton1.Image")));
			this.hotTrackButton1.Location = new System.Drawing.Point(28, 128);
			this.hotTrackButton1.Name = "hotTrackButton1";
			this.hotTrackButton1.Size = new System.Drawing.Size(168, 36);
			this.hotTrackButton1.TabIndex = 0;
			this.hotTrackButton1.Text = "Large HotTrackButton";
			// 
			// hotTrackButton2
			// 
			this.hotTrackButton2.BackColor = System.Drawing.SystemColors.Control;
			this.hotTrackButton2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.hotTrackButton2.ForeColor = System.Drawing.Color.Black;
			this.hotTrackButton2.Image = ((System.Drawing.Bitmap)(resources.GetObject("hotTrackButton2.Image")));
			this.hotTrackButton2.Location = new System.Drawing.Point(32, 24);
			this.hotTrackButton2.Name = "hotTrackButton2";
			this.hotTrackButton2.Size = new System.Drawing.Size(168, 20);
			this.hotTrackButton2.TabIndex = 1;
			this.hotTrackButton2.Text = "Ordinary HotTrackButton";
			// 
			// HotTrackButton3
			// 
			this.HotTrackButton3.BackColor = System.Drawing.SystemColors.Control;
			this.HotTrackButton3.Enabled = false;
			this.HotTrackButton3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.HotTrackButton3.ForeColor = System.Drawing.Color.Black;
			this.HotTrackButton3.Image = ((System.Drawing.Bitmap)(resources.GetObject("HotTrackButton3.Image")));
			this.HotTrackButton3.Location = new System.Drawing.Point(32, 68);
			this.HotTrackButton3.Name = "HotTrackButton3";
			this.HotTrackButton3.Size = new System.Drawing.Size(168, 28);
			this.HotTrackButton3.TabIndex = 3;
			this.HotTrackButton3.Text = "Disabled HotTrackButton";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.HotTrackButton3,
																		  this.hotTrackButton2,
																		  this.hotTrackButton1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
	}
}
