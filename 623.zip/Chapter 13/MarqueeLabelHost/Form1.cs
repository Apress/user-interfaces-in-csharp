using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace MarqueeLabelHost
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.GroupBox GroupBox1;
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.TrackBar tbInterval;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.TrackBar tbAmount;
		private MarqueeLabel.MarqueeLabel marqueeLabel1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.GroupBox1 = new System.Windows.Forms.GroupBox();
			this.Label2 = new System.Windows.Forms.Label();
			this.tbInterval = new System.Windows.Forms.TrackBar();
			this.Label1 = new System.Windows.Forms.Label();
			this.tbAmount = new System.Windows.Forms.TrackBar();
			this.marqueeLabel1 = new MarqueeLabel.MarqueeLabel();
			this.GroupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.tbInterval)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.tbAmount)).BeginInit();
			this.SuspendLayout();
			// 
			// GroupBox1
			// 
			this.GroupBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.GroupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.Label2,
																					this.tbInterval,
																					this.Label1,
																					this.tbAmount});
			this.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.GroupBox1.Location = new System.Drawing.Point(24, 176);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Size = new System.Drawing.Size(336, 132);
			this.GroupBox1.TabIndex = 4;
			this.GroupBox1.TabStop = false;
			// 
			// Label2
			// 
			this.Label2.Location = new System.Drawing.Point(12, 76);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(80, 23);
			this.Label2.TabIndex = 6;
			this.Label2.Text = "Scroll Interval:";
			// 
			// tbInterval
			// 
			this.tbInterval.Location = new System.Drawing.Point(96, 72);
			this.tbInterval.Maximum = 500;
			this.tbInterval.Minimum = 10;
			this.tbInterval.Name = "tbInterval";
			this.tbInterval.Size = new System.Drawing.Size(228, 45);
			this.tbInterval.TabIndex = 5;
			this.tbInterval.TickFrequency = 10;
			this.tbInterval.Value = 100;
			this.tbInterval.Scroll += new System.EventHandler(this.tbInterval_Scroll);
			// 
			// Label1
			// 
			this.Label1.Location = new System.Drawing.Point(12, 20);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(80, 23);
			this.Label1.TabIndex = 4;
			this.Label1.Text = "Scroll Amount:";
			// 
			// tbAmount
			// 
			this.tbAmount.Location = new System.Drawing.Point(96, 16);
			this.tbAmount.Maximum = 20;
			this.tbAmount.Name = "tbAmount";
			this.tbAmount.Size = new System.Drawing.Size(228, 45);
			this.tbAmount.TabIndex = 3;
			this.tbAmount.Value = 1;
			this.tbAmount.Scroll += new System.EventHandler(this.tbAmount_Scroll);
			// 
			// marqueeLabel1
			// 
			this.marqueeLabel1.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.marqueeLabel1.Font = new System.Drawing.Font("Verdana", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.marqueeLabel1.ForeColor = System.Drawing.Color.Navy;
			this.marqueeLabel1.Location = new System.Drawing.Point(0, 12);
			this.marqueeLabel1.Name = "marqueeLabel1";
			this.marqueeLabel1.ScrollTimeInterval = 100;
			this.marqueeLabel1.Size = new System.Drawing.Size(384, 156);
			this.marqueeLabel1.TabIndex = 5;
			this.marqueeLabel1.Tag = "";
			this.marqueeLabel1.Text = "This scrolls!";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(380, 318);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.marqueeLabel1,
																		  this.GroupBox1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "Form1";
			this.GroupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.tbInterval)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.tbAmount)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void tbInterval_Scroll(object sender, System.EventArgs e)
		{
			marqueeLabel1.ScrollTimeInterval = tbInterval.Value;
		}

		private void tbAmount_Scroll(object sender, System.EventArgs e)
		{
			marqueeLabel1.ScrollPixelAmount = tbAmount.Value;
		}
	}
}
