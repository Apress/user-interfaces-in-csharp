using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using SimpleChart;

namespace SimpleChartHost
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private SimpleChart.SimpleChart simpleChart1;
		internal System.Windows.Forms.Label Label1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.simpleChart1 = new SimpleChart.SimpleChart();
			this.Label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// simpleChart1
			// 
			this.simpleChart1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.simpleChart1.Location = new System.Drawing.Point(8, 12);
			this.simpleChart1.Name = "simpleChart1";
			this.simpleChart1.Size = new System.Drawing.Size(272, 188);
			this.simpleChart1.TabIndex = 0;
			// 
			// Label1
			// 
			this.Label1.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.Label1.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Label1.Location = new System.Drawing.Point(28, 216);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(252, 36);
			this.Label1.TabIndex = 2;
			this.Label1.Text = "Annual Sales";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Label1,
																		  this.simpleChart1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			simpleChart1.Bars.Add(new BarItem("1999", 10));
			simpleChart1.Bars.Add(new BarItem("2000", 20));
			simpleChart1.Bars.Add(new BarItem("2001", 5));
			simpleChart1.Bars.Add(new BarItem("2002", 27));
			simpleChart1.RebuildChart();

		}
	}
}
