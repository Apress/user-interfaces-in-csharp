using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace HotTrackButton
{
	/// <summary>
	/// Summary description for HotTrackButton.
	/// </summary>
	public class HotTrackButton : Control
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public HotTrackButton()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion


		public enum State
		{
			Normal,
			MouseOver,
			Pushed
		}

		private State state = State.Normal;

		private Image image;
		private Rectangle bounds;

		public Image Image
		{
			get
			{
				return image;
			}
			set
			{
				image = value;
				bounds = new Rectangle(0, 0, image.Width + 5, image.Height + 5);
				this.Invalidate();
			}
		}

		// You must override this property to invalidate the display and
		// provide automatic refresh when the property is changed.
		public override string Text
		{
			get
			{
				return base.Text;
			}
			set
			{
				base.Text = value;
				this.Invalidate();
			}
		}
		protected override void OnMouseMove(System.Windows.Forms.MouseEventArgs e)
		{
			base.OnMouseMove(e);

			// Check if the mouse pointer is over the button.
			// If the mouse moves off the button surface, it will be deactivated,
			// even if the button is being held in a pressed position.
			// The code repaints the button only if needed.
			if (bounds.Contains(e.X, e.Y))
			{
				if (state == State.Normal)
				{
					state = State.MouseOver;
					this.Invalidate(bounds);
				}
			}
			else
			{
				if (state != State.Normal)
				{
					state = State.Normal;
					this.Invalidate(bounds);
				}
			}
		}

		protected override void OnMouseLeave(System.EventArgs e)
		{
			// Reset the button appearance. This will also deactivate the button
			// if it has been pressed but not released.
			// The code repaints the button only if needed.
			if (state != State.Normal)
			{
				state = State.Normal;
				this.Invalidate(bounds);
			}
		}

		protected override void OnMouseDown(System.Windows.Forms.MouseEventArgs e)
		{
			// Change the button to a pushed state, provided the mouse pointer is
			// over the image and the Left mouse button has been clicked 
			if (bounds.Contains(e.X, e.Y) && 
				(e.Button & MouseButtons.Left) == MouseButtons.Left)
			{
				state = State.Pushed;
				this.Invalidate(bounds);
			}
		}

		protected override void OnMouseUp(System.Windows.Forms.MouseEventArgs e)
		{
			// Change the button to a normal state and repaint if needed.
			if (!((e.Button & MouseButtons.Left) == MouseButtons.Left))
			{
				state = State.Normal;

				if (bounds.Contains(e.X, e.Y))
				{
					state = State.MouseOver;
					}
				else
				{
					state = State.Normal;
				}

				this.Invalidate(bounds);
			}
		}


		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			if (image == null)
			{
				// Draw the text without the image.
				e.Graphics.DrawString(this.Text, this.Font,
					new SolidBrush(this.ForeColor), 10, 0);
			}
			else
			{
				if (!this.Enabled)
				{
					// Paint the picture in a disabled state.
					ControlPaint.DrawImageDisabled(e.Graphics, image, 2, 2,
						this.BackColor);
				}
				else
				{
					// Paint the image according to the button state.
					switch (state)
					{
						case State.Normal:
							e.Graphics.DrawImage(image, 2, 2);
							break;
						case State.MouseOver:
							ControlPaint.DrawBorder3D(e.Graphics, bounds, 
								Border3DStyle.Raised, Border3DSide.All);
							e.Graphics.DrawImage(image, 2, 2);
							break;
						case State.Pushed:
							ControlPaint.DrawBorder3D(e.Graphics, bounds, 
								Border3DStyle.Sunken, Border3DSide.All);
							e.Graphics.DrawImage(image, 3, 3);
							break;
					}
				}

				// Paint the caption text next to the image.
				e.Graphics.DrawString(this.Text, this.Font,
					new SolidBrush(this.ForeColor), bounds.Width + 3,
					(bounds.Height - this.Font.Height) / 2);
			}

		}

		protected override void OnClick(System.EventArgs e)
		{
			// Only propagate the click to the client if it was detected over the image.
			if (state == State.Pushed)
			{
				base.OnClick(e);
			}
		}


	}
}
