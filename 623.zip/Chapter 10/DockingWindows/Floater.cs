using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace DockingWindows
{
	/// <summary>
	/// Summary description for Floater.
	/// </summary>
	public class Floater : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.PictureBox PictureBox2;
		internal System.Windows.Forms.Button Button3;
		internal System.Windows.Forms.Button Button2;
		internal System.Windows.Forms.Button Button1;
		internal System.Windows.Forms.Timer tmrDock;
		private System.ComponentModel.IContainer components;

		public Floater()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.PictureBox2 = new System.Windows.Forms.PictureBox();
			this.Button3 = new System.Windows.Forms.Button();
			this.Button2 = new System.Windows.Forms.Button();
			this.Button1 = new System.Windows.Forms.Button();
			this.tmrDock = new System.Windows.Forms.Timer(this.components);
			this.SuspendLayout();
			// 
			// PictureBox2
			// 
			this.PictureBox2.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.PictureBox2.Location = new System.Drawing.Point(1, -3);
			this.PictureBox2.Name = "PictureBox2";
			this.PictureBox2.Size = new System.Drawing.Size(134, 172);
			this.PictureBox2.TabIndex = 2;
			this.PictureBox2.TabStop = false;
			
			// 
			// Button3
			// 
			this.Button3.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Button3.Location = new System.Drawing.Point(14, 56);
			this.Button3.Name = "Button3";
			this.Button3.Size = new System.Drawing.Size(108, 20);
			this.Button3.TabIndex = 7;
			this.Button3.Text = "Controls";
			// 
			// Button2
			// 
			this.Button2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Button2.Location = new System.Drawing.Point(14, 36);
			this.Button2.Name = "Button2";
			this.Button2.Size = new System.Drawing.Size(108, 20);
			this.Button2.TabIndex = 6;
			this.Button2.Text = "Dockable";
			// 
			// Button1
			// 
			this.Button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Button1.Location = new System.Drawing.Point(14, 16);
			this.Button1.Name = "Button1";
			this.Button1.Size = new System.Drawing.Size(108, 20);
			this.Button1.TabIndex = 5;
			this.Button1.Text = "Sample";
			// 
			// tmrDock
			// 
			this.tmrDock.Interval = 10;
			this.tmrDock.Tick += new System.EventHandler(this.tmrDock_Tick);
			// 
			// Floater
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(136, 166);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Button3,
																		  this.Button2,
																		  this.Button1,
																		  this.PictureBox2});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "Floater";
			this.Text = "Floater";
			this.Move += new System.EventHandler(this.Floater_Move);
			this.ResumeLayout(false);

		}
		#endregion


		private Point dockTestAt;

		private void Floater_Move(object sender, System.EventArgs e)
		{
			// Determine the current location in parent form coordinates.
			Point mouseAt = this.Owner.PointToClient(this.Location);

			// Determine if the floated is close enough to dock.
			if (mouseAt.X < 5 && mouseAt.X > -5)
			{
				if ((Control.MouseButtons & MouseButtons.Left) == MouseButtons.Left)
				{
					dockTestAt = mouseAt;

					// Show the dock focus rectangle.
					((MDIMain)this.Owner).DrawDockRectangle = true;

					// Reset the timer to poll for the MouseUp event.
					tmrDock.Enabled = false;
					tmrDock.Enabled = true;
				}
			}

		}

		private void tmrDock_Tick(object sender, System.EventArgs e)
		{
			if (dockTestAt.X == this.Owner.PointToClient(this.Location).X 
				&& dockTestAt.Y == this.Owner.PointToClient(this.Location).Y)
			{
				if (Control.MouseButtons == MouseButtons.None)
				{
					// Dock in place.
					tmrDock.Enabled = false;
					((MDIMain)this.Owner).AddToDock(this);
				}
			}
			else
			{
				// Mouse has moved. Disable this dock attempt.
				tmrDock.Enabled = false;
				((MDIMain)this.Owner).DrawDockRectangle = false;
			}

		}


	}
}
