using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Drawing.Drawing2D;

namespace DockingWindows
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MDIMain : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Panel pnlDock;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MDIMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pnlDock = new System.Windows.Forms.Panel();
			this.SuspendLayout();
			// 
			// pnlDock
			// 
			this.pnlDock.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left);
			this.pnlDock.BackColor = System.Drawing.SystemColors.AppWorkspace;
			this.pnlDock.Name = "pnlDock";
			this.pnlDock.Size = new System.Drawing.Size(148, 302);
			this.pnlDock.TabIndex = 2;
			this.pnlDock.Visible = false;
			this.pnlDock.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlDock_Paint);
			// 
			// MDIMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(534, 304);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.pnlDock});
			this.IsMdiContainer = true;
			this.Name = "MDIMain";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MDIMain());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			Floater frmFloat = new Floater();
			frmFloat.Owner = this;
			frmFloat.Show();

		}


		public bool DrawDockRectangle
		{
			get
			{
				return pnlDock.Visible;
			}
			set
			{
				pnlDock.Visible = value;
			}
		}

		public void AddToDock(Form frm)
		{
			// Allow the form to be contained in a container control.
			frm.TopLevel = false;
			pnlDock.Controls.Add(frm);

			// Don't let the form be dragged off.
			frm.WindowState = FormWindowState.Maximized;
		}

		private void pnlDock_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			HatchBrush dockCueBrush = new HatchBrush(HatchStyle.LightDownwardDiagonal, 
				Color.White, Color.Gray);
			Pen dockCuePen = new Pen(dockCueBrush, 10);
			e.Graphics.DrawRectangle(dockCuePen, 
				new Rectangle(0, 0, pnlDock.Width, pnlDock.Height));

		}

	}
}
