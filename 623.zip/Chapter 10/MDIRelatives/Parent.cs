using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace MDIRelatives
{
	/// <summary>
	/// Summary description for Parent.
	/// </summary>
	public class Parent : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.MainMenu MainMenu1;
		internal System.Windows.Forms.MenuItem MenuItem1;
		internal System.Windows.Forms.MenuItem mnuCascade;
		internal System.Windows.Forms.MenuItem mnuTileV;
		internal System.Windows.Forms.MenuItem mnuTileH;
		internal System.Windows.Forms.MenuItem mnuMinimizeAll;
		internal System.Windows.Forms.ImageList imgButtons;
		internal System.Windows.Forms.ToolBar ToolBar1;
		internal System.Windows.Forms.ToolBarButton cmdNew;
		internal System.Windows.Forms.ToolBarButton cmdClose;
		private System.ComponentModel.IContainer components;

		public Parent()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Parent));
			this.MainMenu1 = new System.Windows.Forms.MainMenu();
			this.MenuItem1 = new System.Windows.Forms.MenuItem();
			this.mnuCascade = new System.Windows.Forms.MenuItem();
			this.mnuTileV = new System.Windows.Forms.MenuItem();
			this.mnuTileH = new System.Windows.Forms.MenuItem();
			this.mnuMinimizeAll = new System.Windows.Forms.MenuItem();
			this.imgButtons = new System.Windows.Forms.ImageList(this.components);
			this.ToolBar1 = new System.Windows.Forms.ToolBar();
			this.cmdNew = new System.Windows.Forms.ToolBarButton();
			this.cmdClose = new System.Windows.Forms.ToolBarButton();
			this.SuspendLayout();
			// 
			// MainMenu1
			// 
			this.MainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.MenuItem1});
			// 
			// MenuItem1
			// 
			this.MenuItem1.Index = 0;
			this.MenuItem1.MdiList = true;
			this.MenuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuCascade,
																					  this.mnuTileV,
																					  this.mnuTileH,
																					  this.mnuMinimizeAll});
			this.MenuItem1.Text = "Window";
			// 
			// mnuCascade
			// 
			this.mnuCascade.Index = 0;
			this.mnuCascade.Text = "Cascase";
			this.mnuCascade.Click += new System.EventHandler(this.mnuCascade_Click);
			// 
			// mnuTileV
			// 
			this.mnuTileV.Index = 1;
			this.mnuTileV.Text = "Tile Vertical";
			this.mnuTileV.Click += new System.EventHandler(this.mnuTileV_Click);
			// 
			// mnuTileH
			// 
			this.mnuTileH.Index = 2;
			this.mnuTileH.Text = "Tile Horizontal";
			this.mnuTileH.Click += new System.EventHandler(this.mnuTileH_Click);
			// 
			// mnuMinimizeAll
			// 
			this.mnuMinimizeAll.Index = 3;
			this.mnuMinimizeAll.Text = "Minimize All";
			this.mnuMinimizeAll.Click += new System.EventHandler(this.mnuMinimizeAll_Click);
			// 
			// imgButtons
			// 
			this.imgButtons.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imgButtons.ImageSize = new System.Drawing.Size(16, 16);
			this.imgButtons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgButtons.ImageStream")));
			this.imgButtons.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// ToolBar1
			// 
			this.ToolBar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this.ToolBar1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.ToolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						this.cmdNew,
																						this.cmdClose});
			this.ToolBar1.DropDownArrows = true;
			this.ToolBar1.ImageList = this.imgButtons;
			this.ToolBar1.Name = "ToolBar1";
			this.ToolBar1.ShowToolTips = true;
			this.ToolBar1.Size = new System.Drawing.Size(292, 41);
			this.ToolBar1.TabIndex = 4;
			this.ToolBar1.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.ToolBar1_ButtonClick);
			// 
			// cmdNew
			// 
			this.cmdNew.ImageIndex = 0;
			this.cmdNew.Text = "New";
			// 
			// cmdClose
			// 
			this.cmdClose.ImageIndex = 1;
			this.cmdClose.Text = "Close";
			// 
			// Parent
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.ToolBar1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.IsMdiContainer = true;
			this.Menu = this.MainMenu1;
			this.Name = "Parent";
			this.Text = "Parent";
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new Parent());
		}

		private string synchronizedText = "text";
		private int mdiCount = 0;

		private void ToolBar1_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			// Determine which button was clicked.
			if (e.Button == cmdNew)
			{
				// Show a new ChildForm.
				Child frmChild = new Child();
				frmChild.MdiParent = this;
				frmChild.RefreshText(synchronizedText);

				mdiCount++;
				frmChild.Text = "MDI Child # " + mdiCount.ToString();

				frmChild.Show();
			}
			else if (e.Button == cmdClose)
			{
				// Close the active child.
				this.ActiveMdiChild.Close();
			}

		}

		public void RefreshChildren(Child sender, string text)
		{
			// Store text for use when creating a child form, or if needed later.
			synchronizedText = text;

			// Update children.
			foreach (Child frm in this.MdiChildren)
			{
				if (frm != sender)
				{
					frm.RefreshText(text);
				}
			}
		}

		private void mnuMinimizeAll_Click(object sender, System.EventArgs e)
		{
			foreach (Form frm in this.MdiChildren)
			{
				frm.WindowState = FormWindowState.Minimized;
			}

		}

		private void mnuTileH_Click(object sender, System.EventArgs e)
		{
			this.LayoutMdi(MdiLayout.TileHorizontal);
		}

		private void mnuTileV_Click(object sender, System.EventArgs e)
		{
			this.LayoutMdi(MdiLayout.TileVertical);
		}

		private void mnuCascade_Click(object sender, System.EventArgs e)
		{
			this.LayoutMdi(MdiLayout.Cascade);
		}


	}
}
