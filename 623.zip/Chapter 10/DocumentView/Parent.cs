using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace DocumentView
{
	/// <summary>
	/// Summary description for Parent.
	/// </summary>
	public class Parent : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.ImageList imgButtons;
		internal System.Windows.Forms.ToolBar ToolBar1;
		internal System.Windows.Forms.ToolBarButton cmdNew;
		internal System.Windows.Forms.ToolBarButton cmdOpen;
		internal System.Windows.Forms.ToolBarButton cmdClose;
		internal System.Windows.Forms.ToolBarButton cmdSave;
		internal System.Windows.Forms.ToolBarButton ToolBarButton1;
		internal System.Windows.Forms.ToolBarButton cmdPreview;
		private System.ComponentModel.IContainer components;

		public Parent()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Parent));
			this.imgButtons = new System.Windows.Forms.ImageList(this.components);
			this.ToolBar1 = new System.Windows.Forms.ToolBar();
			this.cmdNew = new System.Windows.Forms.ToolBarButton();
			this.cmdOpen = new System.Windows.Forms.ToolBarButton();
			this.cmdClose = new System.Windows.Forms.ToolBarButton();
			this.cmdSave = new System.Windows.Forms.ToolBarButton();
			this.ToolBarButton1 = new System.Windows.Forms.ToolBarButton();
			this.cmdPreview = new System.Windows.Forms.ToolBarButton();
			this.SuspendLayout();
			// 
			// imgButtons
			// 
			this.imgButtons.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imgButtons.ImageSize = new System.Drawing.Size(16, 16);
			this.imgButtons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgButtons.ImageStream")));
			this.imgButtons.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// ToolBar1
			// 
			this.ToolBar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this.ToolBar1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.ToolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						this.cmdNew,
																						this.cmdOpen,
																						this.cmdClose,
																						this.cmdSave,
																						this.ToolBarButton1,
																						this.cmdPreview});
			this.ToolBar1.DropDownArrows = true;
			this.ToolBar1.ImageList = this.imgButtons;
			this.ToolBar1.Name = "ToolBar1";
			this.ToolBar1.ShowToolTips = true;
			this.ToolBar1.Size = new System.Drawing.Size(480, 41);
			this.ToolBar1.TabIndex = 4;
			this.ToolBar1.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.ToolBar1_ButtonClick);
			// 
			// cmdNew
			// 
			this.cmdNew.ImageIndex = 3;
			this.cmdNew.Text = "New";
			// 
			// cmdOpen
			// 
			this.cmdOpen.ImageIndex = 0;
			this.cmdOpen.Text = "Open";
			// 
			// cmdClose
			// 
			this.cmdClose.ImageIndex = 1;
			this.cmdClose.Text = "Close";
			// 
			// cmdSave
			// 
			this.cmdSave.ImageIndex = 2;
			this.cmdSave.Text = "Save";
			// 
			// ToolBarButton1
			// 
			this.ToolBarButton1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// cmdPreview
			// 
			this.cmdPreview.ImageIndex = 4;
			this.cmdPreview.Text = "Preview";
			// 
			// Parent
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(480, 354);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.ToolBar1});
			this.IsMdiContainer = true;
			this.Name = "Parent";
			this.Text = "Parent";
			this.ResumeLayout(false);

		}
		#endregion



		
		private string lastDir = "C:\\Temp";


		private void ToolBar1_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			if (e.Button == cmdOpen)
			{
				OpenFileDialog dlgOpen = new OpenFileDialog();
				dlgOpen.InitialDirectory = lastDir;
				dlgOpen.Filter = "Order Files (*.ord)|*.ord";
                
				// Show the open dialog.
				if (dlgOpen.ShowDialog() == DialogResult.OK)
				{
					Order doc = new Order();
					
					try
					{
						doc.Open(dlgOpen.FileName);
					}
					catch (Exception err)
					{
						// All exceptions bubble up to this level.
						MessageBox.Show(err.ToString());
						return;
					}
					
					// Create the child form for the selected file.
					Child frmChild = new Child(doc, Child.ViewType.ItemGrid);
					frmChild.MdiParent = this;
					frmChild.Show();
				}
			}
			else if (e.Button == cmdNew)
			{
				// Create a new order.
				Order doc = new Order();
				Child frmChild = new Child(doc, Child.ViewType.ItemGrid);
				frmChild.MdiParent = this;
				frmChild.Show();
			}
			else if (e.Button == cmdSave)
			{
				// Save the current order.
				if (this.ActiveMdiChild != null)
				{
					SaveFileDialog dlgSave = new SaveFileDialog();
					Order doc = ((Child)this.ActiveMdiChild).Document;
					dlgSave.FileName = doc.LastFileName;
					dlgSave.Filter = "Order Files (*.ord)|*.ord";

					if (dlgSave.ShowDialog() == DialogResult.OK)
					{
	                    try
						{
	                        doc.Save(dlgSave.FileName);
							this.ActiveMdiChild.Text = dlgSave.FileName;
						}
						catch (Exception err)
						{
							// All exceptions bubble up to this level.
							MessageBox.Show(err.ToString());
							return;
						}
					}
				}
			}
			else if (e.Button == cmdClose)
			{
	            if (this.ActiveMdiChild != null)
				{
	                this.ActiveMdiChild.Close();
				}
			}
			else if (e.Button == cmdPreview)
			{
	            // Launch a print preview child for the active order.
				if (this.ActiveMdiChild != null)
				{
	                Order doc = ((Child)this.ActiveMdiChild).Document;
	
					Child frmChild = new Child(doc, Child.ViewType.PrintPreview);
					frmChild.MdiParent = this;
					frmChild.Show();
				}
			}

		}

		[STAThread]
		static void Main() 
		{
			Application.Run(new Parent());
		}
	}

}
