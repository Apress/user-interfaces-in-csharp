using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Drawing.Printing;

namespace DocumentView
{
	/// <summary>
	/// Summary description for OrderPrintPreview.
	/// </summary>
	public class OrderPrintPreview : System.Windows.Forms.UserControl
	{
		internal System.Windows.Forms.PrintPreviewControl Preview;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public OrderPrintPreview()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Preview = new System.Windows.Forms.PrintPreviewControl();
			this.SuspendLayout();
			// 
			// Preview
			// 
			this.Preview.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.Preview.AutoZoom = false;
			this.Preview.Location = new System.Drawing.Point(4, 2);
			this.Preview.Name = "Preview";
			this.Preview.Size = new System.Drawing.Size(372, 204);
			this.Preview.TabIndex = 1;
			this.Preview.Zoom = 1;
			// 
			// OrderPrintPreview
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Preview});
			this.Name = "OrderPrintPreview";
			this.Size = new System.Drawing.Size(380, 208);
			this.ResumeLayout(false);

		}
		#endregion



		
		public Order Document;
		private PrintDocument printDoc = new PrintDocument();

		public OrderPrintPreview(Order document)
		{
			// This is required to make sure the controls that were added at
			// design-time are actually rendered.
			InitializeComponent();

			// Store a reference to the document, attach the document event handlers,
			// and refresh the display.
			this.Document = document;
			this.Document.DocumentChanged += new EventHandler(RefreshList);
			this.printDoc.PrintPage += new PrintPageEventHandler(PrintDoc);

			RefreshList(this, null);
		}

		private void RefreshList(object sender, System.EventArgs e)
		{
			// Setting this property starts the preview,
			// even if the PrintDoc document is already assigned.
			Preview.Document = printDoc;
		}

		// Tracks placement while printing.
		private int itemNumber;

		// The print font.
		private Font printFont = new Font("Tahoma", 14, FontStyle.Bold);

		private void PrintDoc(object sender,
			System.Drawing.Printing.PrintPageEventArgs e)
		{

			// Tracks the line position on the page.
			int y = 70;

			// Step through the items and write them to the page.
			OrderItem item;
			Product itemProduct;
			
			for (itemNumber = itemNumber; itemNumber < Document.Count; itemNumber++)
			{
				item = Document.Item(itemNumber);
				e.Graphics.DrawString(item.ID.ToString(), printFont, 
					Brushes.Black, 70, y);
				itemProduct = PriceList.GetItem(item.ID);
				e.Graphics.DrawString(itemProduct.Name, printFont,
					Brushes.Black, 120, y);
				e.Graphics.DrawString(itemProduct.Price.ToString(), printFont,
					Brushes.Black, 350, y);
				
				// Check if more pages are required.
				if ((y + 30) > e.MarginBounds.Height &&
					itemNumber < (Document.Count - 1))
				{
					e.HasMorePages = true;
					return;
				}
				
				// Move to the next line.
				y += 20;
			}

			// Printing is finished.
			e.HasMorePages = false;
			itemNumber = 0;
		}

	}
}
