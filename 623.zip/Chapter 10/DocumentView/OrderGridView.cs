using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace DocumentView
{
	/// <summary>
	/// Summary description for OrderGridView.
	/// </summary>
	public class OrderGridView : System.Windows.Forms.UserControl
	{
		internal System.Windows.Forms.Button cmdRemove;
		internal System.Windows.Forms.Button cmdAdd;
		internal System.Windows.Forms.ListView list;
		internal System.Windows.Forms.ColumnHeader ColumnHeader1;
		internal System.Windows.Forms.ColumnHeader ColumnHeader2;
		internal System.Windows.Forms.ColumnHeader ColumnHeader3;
		internal System.Windows.Forms.ColumnHeader ColumnHeader4;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public OrderGridView()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmdRemove = new System.Windows.Forms.Button();
			this.cmdAdd = new System.Windows.Forms.Button();
			this.list = new System.Windows.Forms.ListView();
			this.ColumnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.ColumnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.ColumnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.ColumnHeader4 = new System.Windows.Forms.ColumnHeader();
			this.SuspendLayout();
			// 
			// cmdRemove
			// 
			this.cmdRemove.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.cmdRemove.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmdRemove.Location = new System.Drawing.Point(280, 36);
			this.cmdRemove.Name = "cmdRemove";
			this.cmdRemove.Size = new System.Drawing.Size(112, 28);
			this.cmdRemove.TabIndex = 5;
			this.cmdRemove.Text = "Remove Item";
			this.cmdRemove.CursorChanged += new System.EventHandler(this.cmdRemove_Click);
			// 
			// cmdAdd
			// 
			this.cmdAdd.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.cmdAdd.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmdAdd.Location = new System.Drawing.Point(280, 4);
			this.cmdAdd.Name = "cmdAdd";
			this.cmdAdd.Size = new System.Drawing.Size(112, 28);
			this.cmdAdd.TabIndex = 4;
			this.cmdAdd.Text = "Add Random Item";
			this.cmdAdd.Click += new System.EventHandler(this.cmdAdd_Click);
			// 
			// list
			// 
			this.list.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.list.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																				   this.ColumnHeader1,
																				   this.ColumnHeader2,
																				   this.ColumnHeader3,
																				   this.ColumnHeader4});
			this.list.FullRowSelect = true;
			this.list.Location = new System.Drawing.Point(4, 4);
			this.list.MultiSelect = false;
			this.list.Name = "list";
			this.list.Size = new System.Drawing.Size(264, 136);
			this.list.TabIndex = 3;
			this.list.View = System.Windows.Forms.View.Details;
			// 
			// ColumnHeader1
			// 
			this.ColumnHeader1.Text = "ID";
			this.ColumnHeader1.Width = 30;
			// 
			// ColumnHeader2
			// 
			this.ColumnHeader2.Text = "Name";
			this.ColumnHeader2.Width = 100;
			// 
			// ColumnHeader3
			// 
			this.ColumnHeader3.Text = "Price";
			this.ColumnHeader3.Width = 50;
			// 
			// ColumnHeader4
			// 
			this.ColumnHeader4.Text = "Description";
			this.ColumnHeader4.Width = 200;
			// 
			// OrderGridView
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.cmdRemove,
																		  this.cmdAdd,
																		  this.list});
			this.Name = "OrderGridView";
			this.Size = new System.Drawing.Size(396, 144);
			this.ResumeLayout(false);

		}
		#endregion




		
		public Order Document;

		public OrderGridView(Order document)
		{
			// This is required to make sure the controls that were added at
			// design-time are actually rendered.
			InitializeComponent();

			// Store a reference to the document, attach the event handler,
			// and refresh the display.
			this.Document = document;
			this.Document.DocumentChanged += new EventHandler(RefreshList);
			RefreshList(this, null);
		}

		private void RefreshList(object sender, System.EventArgs e)
		{
			// Update the ListView control with the new document contents.
			if (list != null)
			{
				// For best performance, disable refreshes while updating the list.
				list.SuspendLayout();

				list.Items.Clear();

				// Step through the list of items in the document.
				Product itemProduct;
				ListViewItem itemDisplay;
				foreach (OrderItem item in this.Document)
				{
					itemDisplay = list.Items.Add(item.ID.ToString());
					itemProduct = PriceList.GetItem(item.ID);
					itemDisplay.SubItems.Add(itemProduct.Name);
					itemDisplay.SubItems.Add(itemProduct.Price.ToString());
					itemDisplay.SubItems.Add(itemProduct.Description);
				}

				list.ResumeLayout();
			}
		}

		// Triggered when the Add button is clicked.
		private void cmdAdd_Click(object sender, System.EventArgs e)
		{
			// Add a random item.
			Random randomItem = new Random();
			Document.Add(new OrderItem(randomItem.Next(1, 4)));
		}

		// Triggered when the Remove button is clicked.
		private void cmdRemove_Click(object sender, System.EventArgs e)
		{
			// Remove the current item.
			// The ListView Is configured for single-selection only.
			Document.Remove(list.SelectedIndices[0]);
		}


	}
}
