using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace DocumentView
{
	/// <summary>
	/// Summary description for Child.
	/// </summary>
	public class Child : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Child()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.Size = new System.Drawing.Size(300,300);
			this.Text = "Child";
		}
		#endregion



		
		public enum ViewType
		{
			ItemGrid,
			PrintPreview
		}

		public Order Document;

		public Child(Order doc, ViewType viewType)
		{
			// This is required to make sure the controls that were added at
			// design-time are actually rendered.
			InitializeComponent();

			// Configure the title.
			this.Text = doc.LastFileName;
			this.Document = doc;

			// Create a reference for the view.
			// This reference can accomodate any type of control.
			Control view = null;

			// Instantiate the appropriate view.
			switch (viewType)
			{
				case ViewType.ItemGrid:
					view = new OrderGridView(doc);
					break;
				case ViewType.PrintPreview:
					view = new OrderPrintPreview(doc);
					break;
			}

			// Add the view to the form.
			view.Dock = DockStyle.Fill;
			this.Controls.Add(view);
		}
	}
}
