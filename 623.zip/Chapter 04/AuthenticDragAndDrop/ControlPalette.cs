using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace AuthenticDragAndDrop
{
	/// <summary>
	/// Summary description for ControlPalette.
	/// </summary>
	public class ControlPalette : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.ImageList images;
		internal System.Windows.Forms.Label lblPictureThree;
		internal System.Windows.Forms.Label lblPictureTwo;
		internal System.Windows.Forms.Label lblPictureOne;
		private System.ComponentModel.IContainer components;

		public ControlPalette()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ControlPalette));
			this.images = new System.Windows.Forms.ImageList(this.components);
			this.lblPictureThree = new System.Windows.Forms.Label();
			this.lblPictureTwo = new System.Windows.Forms.Label();
			this.lblPictureOne = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// images
			// 
			this.images.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.images.ImageSize = new System.Drawing.Size(16, 16);
			this.images.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("images.ImageStream")));
			this.images.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// lblPictureThree
			// 
			this.lblPictureThree.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblPictureThree.Image = ((System.Drawing.Bitmap)(resources.GetObject("lblPictureThree.Image")));
			this.lblPictureThree.ImageIndex = 2;
			this.lblPictureThree.ImageList = this.images;
			this.lblPictureThree.Location = new System.Drawing.Point(8, 112);
			this.lblPictureThree.Name = "lblPictureThree";
			this.lblPictureThree.Size = new System.Drawing.Size(56, 48);
			this.lblPictureThree.TabIndex = 3;
			this.lblPictureThree.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lbl_MouseDown);
			// 
			// lblPictureTwo
			// 
			this.lblPictureTwo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblPictureTwo.Image = ((System.Drawing.Bitmap)(resources.GetObject("lblPictureTwo.Image")));
			this.lblPictureTwo.ImageIndex = 1;
			this.lblPictureTwo.ImageList = this.images;
			this.lblPictureTwo.Location = new System.Drawing.Point(8, 60);
			this.lblPictureTwo.Name = "lblPictureTwo";
			this.lblPictureTwo.Size = new System.Drawing.Size(56, 48);
			this.lblPictureTwo.TabIndex = 2;
			this.lblPictureTwo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lbl_MouseDown);
			// 
			// lblPictureOne
			// 
			this.lblPictureOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblPictureOne.Image = ((System.Drawing.Bitmap)(resources.GetObject("lblPictureOne.Image")));
			this.lblPictureOne.ImageIndex = 0;
			this.lblPictureOne.ImageList = this.images;
			this.lblPictureOne.Location = new System.Drawing.Point(8, 8);
			this.lblPictureOne.Name = "lblPictureOne";
			this.lblPictureOne.Size = new System.Drawing.Size(56, 48);
			this.lblPictureOne.TabIndex = 1;
			this.lblPictureOne.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lbl_MouseDown);
			// 
			// ControlPalette
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(76, 174);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblPictureThree,
																		  this.lblPictureTwo,
																		  this.lblPictureOne});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.Name = "ControlPalette";
			this.Text = "Pictures";
			this.ResumeLayout(false);

		}
		#endregion

		private void lbl_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			Label lbl = (Label)sender;
			lbl.DoDragDrop(lbl.Image, DragDropEffects.Copy);
		}
	}
}
