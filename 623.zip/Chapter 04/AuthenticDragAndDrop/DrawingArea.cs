using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace AuthenticDragAndDrop
{
	/// <summary>
	/// Summary description for DrawingArea.
	/// </summary>
	public class DrawingArea : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.PictureBox picDrawingArea;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DrawingArea()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.picDrawingArea = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// picDrawingArea
			// 
			this.picDrawingArea.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.picDrawingArea.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.picDrawingArea.Location = new System.Drawing.Point(8, 4);
			this.picDrawingArea.Name = "picDrawingArea";
			this.picDrawingArea.Size = new System.Drawing.Size(368, 280);
			this.picDrawingArea.TabIndex = 1;
			this.picDrawingArea.TabStop = false;
			this.picDrawingArea.DragEnter += new System.Windows.Forms.DragEventHandler(this.picDrawingArea_DragEnter);
			this.picDrawingArea.DragDrop += new System.Windows.Forms.DragEventHandler(this.picDrawingArea_DragDrop);
			// 
			// DrawingArea
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(384, 294);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.picDrawingArea});
			this.Name = "DrawingArea";
			this.Text = "DrawingArea";
			this.Load += new System.EventHandler(this.DrawingArea_Load);
			this.ResumeLayout(false);

		}
		#endregion
		
		[STAThread]
		static void Main() 
		{
			Application.Run(new DrawingArea());
		}

		private void DrawingArea_Load(object sender, System.EventArgs e)
		{
			ControlPalette frmTool = new ControlPalette();
			this.AddOwnedForm(frmTool);
			frmTool.Show();
			picDrawingArea.AllowDrop = true;
		}

		private void picDrawingArea_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.Bitmap))
			{
				e.Effect = DragDropEffects.Copy;
			}
			else
			{
				e.Effect = DragDropEffects.None;
			}
		}

		private void picDrawingArea_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
		{
			Graphics g = picDrawingArea.CreateGraphics();
            g.DrawImage((Image)e.Data.GetData(DataFormats.Bitmap), 
                new Point(e.X - this.Left - 12, e.Y - this.Top - 30));

		}
	}
}
