using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Validation
{
	/// <summary>
	/// Summary description for ErrorProviderValidation.
	/// </summary>
	public class ErrorProviderValidation : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Label Label3;
		internal System.Windows.Forms.TextBox txtEmail;
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.TextBox txtFirstName;
		internal System.Windows.Forms.TextBox txtLastName;
		internal System.Windows.Forms.Button Button1;
		internal System.Windows.Forms.ErrorProvider errProvider;
		internal System.Windows.Forms.GroupBox grpValidation;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ErrorProviderValidation()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.grpValidation = new System.Windows.Forms.GroupBox();
			this.Label3 = new System.Windows.Forms.Label();
			this.txtEmail = new System.Windows.Forms.TextBox();
			this.Label2 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.txtFirstName = new System.Windows.Forms.TextBox();
			this.txtLastName = new System.Windows.Forms.TextBox();
			this.Button1 = new System.Windows.Forms.Button();
			this.errProvider = new System.Windows.Forms.ErrorProvider();
			this.grpValidation.SuspendLayout();
			this.SuspendLayout();
			// 
			// grpValidation
			// 
			this.grpValidation.Controls.AddRange(new System.Windows.Forms.Control[] {
																						this.Label3,
																						this.txtEmail,
																						this.Label2,
																						this.Label1,
																						this.txtFirstName,
																						this.txtLastName});
			this.grpValidation.Location = new System.Drawing.Point(8, 8);
			this.grpValidation.Name = "grpValidation";
			this.grpValidation.Size = new System.Drawing.Size(368, 124);
			this.grpValidation.TabIndex = 13;
			this.grpValidation.TabStop = false;
			// 
			// Label3
			// 
			this.Label3.Location = new System.Drawing.Point(16, 88);
			this.Label3.Name = "Label3";
			this.Label3.Size = new System.Drawing.Size(64, 16);
			this.Label3.TabIndex = 10;
			this.Label3.Text = "Email:";
			// 
			// txtEmail
			// 
			this.txtEmail.Location = new System.Drawing.Point(84, 84);
			this.txtEmail.Name = "txtEmail";
			this.txtEmail.Size = new System.Drawing.Size(152, 21);
			this.txtEmail.TabIndex = 9;
			this.txtEmail.Text = "";
			this.txtEmail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEmail_KeyPress);
			// 
			// Label2
			// 
			this.Label2.Location = new System.Drawing.Point(16, 52);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(64, 16);
			this.Label2.TabIndex = 8;
			this.Label2.Text = "Last Name:";
			// 
			// Label1
			// 
			this.Label1.Location = new System.Drawing.Point(16, 28);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(64, 16);
			this.Label1.TabIndex = 7;
			this.Label1.Text = "First Name:";
			// 
			// txtFirstName
			// 
			this.txtFirstName.Location = new System.Drawing.Point(84, 24);
			this.txtFirstName.Name = "txtFirstName";
			this.txtFirstName.Size = new System.Drawing.Size(152, 21);
			this.txtFirstName.TabIndex = 4;
			this.txtFirstName.Text = "";
			this.txtFirstName.Validating += new System.ComponentModel.CancelEventHandler(this.txtName_Validating);
			// 
			// txtLastName
			// 
			this.txtLastName.Location = new System.Drawing.Point(84, 48);
			this.txtLastName.Name = "txtLastName";
			this.txtLastName.Size = new System.Drawing.Size(152, 21);
			this.txtLastName.TabIndex = 5;
			this.txtLastName.Text = "";
			this.txtLastName.Validating += new System.ComponentModel.CancelEventHandler(this.txtName_Validating);
			// 
			// Button1
			// 
			this.Button1.Location = new System.Drawing.Point(152, 204);
			this.Button1.Name = "Button1";
			this.Button1.Size = new System.Drawing.Size(76, 24);
			this.Button1.TabIndex = 12;
			this.Button1.Text = "OK";
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			// 
			// errProvider
			// 
			this.errProvider.DataMember = null;
			// 
			// ErrorProviderValidation
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(388, 242);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.grpValidation,
																		  this.Button1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "ErrorProviderValidation";
			this.Text = "ErrorProviderValidation";
			this.grpValidation.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new ErrorProviderValidation());
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			bool invalidInput = false;
			
			foreach (Control ctrl in this.grpValidation.Controls)
			{
				if (errProvider.GetError(ctrl) != "")
				{
					invalidInput = true;
					break;
				}
			}
            
			if (invalidInput)
			{
				MessageBox.Show("You still have invalid input.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
			else
			{
				this.Close();
			}
        
		}

		private void txtName_Validating(object sender, System.ComponentModel.CancelEventArgs e)
		{
			Control ctrl = (Control)sender;
			if (ctrl.Text == "")
			{
				errProvider.SetError(ctrl, "You must enter a first and last name.");
			}
			else
			{
				errProvider.SetError(ctrl, "");
			}
		}

		private void txtEmail_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			System.Text.RegularExpressions.Regex regex;
            regex = new System.Text.RegularExpressions.Regex(@"\S+@\S+\.\S+");

			Control ctrl = (Control)sender;
			if (regex.IsMatch(ctrl.Text))
			{
				errProvider.SetError(ctrl, "");
			}
			else
			{
				errProvider.SetError(ctrl, "Not a valid email.");
			}

		}
	
	}
}
