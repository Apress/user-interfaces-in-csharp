using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Validation
{
	/// <summary>
	/// Summary description for SimpleValidation.
	/// </summary>
	public class SimpleValidation : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.GroupBox GroupBox1;
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.TextBox txtFirstName;
		internal System.Windows.Forms.TextBox txtLastName;
		internal System.Windows.Forms.Button Button1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public SimpleValidation()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.GroupBox1 = new System.Windows.Forms.GroupBox();
			this.Label2 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.txtFirstName = new System.Windows.Forms.TextBox();
			this.txtLastName = new System.Windows.Forms.TextBox();
			this.Button1 = new System.Windows.Forms.Button();
			this.GroupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// GroupBox1
			// 
			this.GroupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.Label2,
																					this.Label1,
																					this.txtFirstName,
																					this.txtLastName});
			this.GroupBox1.Location = new System.Drawing.Point(8, 12);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Size = new System.Drawing.Size(368, 88);
			this.GroupBox1.TabIndex = 11;
			this.GroupBox1.TabStop = false;
			// 
			// Label2
			// 
			this.Label2.Location = new System.Drawing.Point(16, 52);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(64, 16);
			this.Label2.TabIndex = 8;
			this.Label2.Text = "Last Name:";
			// 
			// Label1
			// 
			this.Label1.Location = new System.Drawing.Point(16, 28);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(64, 16);
			this.Label1.TabIndex = 7;
			this.Label1.Text = "First Name:";
			// 
			// txtFirstName
			// 
			this.txtFirstName.Location = new System.Drawing.Point(84, 24);
			this.txtFirstName.Name = "txtFirstName";
			this.txtFirstName.Size = new System.Drawing.Size(152, 21);
			this.txtFirstName.TabIndex = 4;
			this.txtFirstName.Text = "";
			this.txtFirstName.Validating += new System.ComponentModel.CancelEventHandler(this.txtName_Validating);
			// 
			// txtLastName
			// 
			this.txtLastName.Location = new System.Drawing.Point(84, 48);
			this.txtLastName.Name = "txtLastName";
			this.txtLastName.Size = new System.Drawing.Size(152, 21);
			this.txtLastName.TabIndex = 5;
			this.txtLastName.Text = "";
			this.txtLastName.Validating += new System.ComponentModel.CancelEventHandler(this.txtName_Validating);
			// 
			// Button1
			// 
			this.Button1.Location = new System.Drawing.Point(152, 208);
			this.Button1.Name = "Button1";
			this.Button1.Size = new System.Drawing.Size(76, 24);
			this.Button1.TabIndex = 10;
			this.Button1.Text = "OK";
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			// 
			// SimpleValidation
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(384, 242);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.GroupBox1,
																		  this.Button1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "SimpleValidation";
			this.Text = "SimpleValidation";
			this.GroupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		[STAThread]
		static void Main() 
		{
			Application.Run(new SimpleValidation());
		}

		private void txtName_Validating(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if (((TextBox)sender).Text == "")
			{
				MessageBox.Show("You must enter a first and last name.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				e.Cancel = true;
			}
        }
	}
}
