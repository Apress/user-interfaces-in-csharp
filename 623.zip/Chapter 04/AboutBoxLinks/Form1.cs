using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace AboutBoxLinks
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.LinkLabel lnkBuy;
		internal System.Windows.Forms.LinkLabel lnkWebSite;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lnkBuy = new System.Windows.Forms.LinkLabel();
			this.lnkWebSite = new System.Windows.Forms.LinkLabel();
			this.SuspendLayout();
			// 
			// lnkBuy
			// 
			this.lnkBuy.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lnkBuy.LinkArea = new System.Windows.Forms.LinkArea(0, 0);
			this.lnkBuy.Location = new System.Drawing.Point(26, 79);
			this.lnkBuy.Name = "lnkBuy";
			this.lnkBuy.Size = new System.Drawing.Size(244, 48);
			this.lnkBuy.TabIndex = 5;
			this.lnkBuy.Text = "Buy it at Amazon.com or Barnes and Noble.";
			this.lnkBuy.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkWebSite_LinkClicked);
			// 
			// lnkWebSite
			// 
			this.lnkWebSite.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lnkWebSite.LinkArea = new System.Windows.Forms.LinkArea(0, 0);
			this.lnkWebSite.Location = new System.Drawing.Point(26, 35);
			this.lnkWebSite.Name = "lnkWebSite";
			this.lnkWebSite.Size = new System.Drawing.Size(248, 36);
			this.lnkWebSite.TabIndex = 4;
			this.lnkWebSite.Text = "See www.prosetech.com for more information.";
			this.lnkWebSite.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkWebSite_LinkClicked);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(300, 162);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lnkBuy,
																		  this.lnkWebSite});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "Link Examples";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			lnkBuy.Links.Add(10, 10, "http://www.amazon.com");
			lnkBuy.Links.Add(24, 16, "http://www.bn.com");
			lnkWebSite.Links.Add(4, 17, "http://www.prosetech.com");
		}

		private void lnkWebSite_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			e.Link.Visited = true;
			System.Diagnostics.Process.Start((string)e.Link.LinkData);

		}
	}
}
