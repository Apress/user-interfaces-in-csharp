using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace OwnerDrawnMenu
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.ImageList imgMenu;
		internal System.Windows.Forms.MainMenu mainMenu1;
		internal System.Windows.Forms.MenuItem mnuFile;
		internal System.Windows.Forms.MenuItem mnuNew;
		internal System.Windows.Forms.MenuItem mnuOpen;
		internal System.Windows.Forms.MenuItem mnuSave;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.imgMenu = new System.Windows.Forms.ImageList(this.components);
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.mnuFile = new System.Windows.Forms.MenuItem();
			this.mnuNew = new System.Windows.Forms.MenuItem();
			this.mnuOpen = new System.Windows.Forms.MenuItem();
			this.mnuSave = new System.Windows.Forms.MenuItem();
			// 
			// imgMenu
			// 
			this.imgMenu.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imgMenu.ImageSize = new System.Drawing.Size(16, 16);
			this.imgMenu.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgMenu.ImageStream")));
			this.imgMenu.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuFile});
			// 
			// mnuFile
			// 
			this.mnuFile.Index = 0;
			this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuNew,
																					this.mnuOpen,
																					this.mnuSave});
			this.mnuFile.Text = "File";
			// 
			// mnuNew
			// 
			this.mnuNew.Index = 0;
			this.mnuNew.OwnerDraw = true;
			this.mnuNew.Text = "New";
			this.mnuNew.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.mnu_DrawItem);
			this.mnuNew.MeasureItem += new System.Windows.Forms.MeasureItemEventHandler(this.mnu_MeasureItem);
			// 
			// mnuOpen
			// 
			this.mnuOpen.Index = 1;
			this.mnuOpen.OwnerDraw = true;
			this.mnuOpen.Text = "Open";
			this.mnuOpen.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.mnu_DrawItem);
			this.mnuOpen.MeasureItem += new System.Windows.Forms.MeasureItemEventHandler(this.mnu_MeasureItem);
			// 
			// mnuSave
			// 
			this.mnuSave.Index = 2;
			this.mnuSave.OwnerDraw = true;
			this.mnuSave.Text = "Save";
			this.mnuSave.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.mnu_DrawItem);
			this.mnuSave.MeasureItem += new System.Windows.Forms.MeasureItemEventHandler(this.mnu_MeasureItem);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Owner-Drawn Menu";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void mnu_MeasureItem(object sender, System.Windows.Forms.MeasureItemEventArgs e)
		{
			// Retrieve current item.
			MenuItem mnuItem = (MenuItem)sender;

			Font menuFont = new Font("Tahoma", 8);

			// Measure size needed to display text.
			// We add 30 pixels to the width to allow a generous spacing for the image.
			e.ItemHeight = (int)e.Graphics.MeasureString(mnuItem.Text, menuFont).Height + 5;
            e.ItemWidth = (int)e.Graphics.MeasureString(mnuItem.Text, menuFont).Width + 30;
		}

		private void mnu_DrawItem(object sender, System.Windows.Forms.DrawItemEventArgs e)
		{
			// Retrieve current item.
			MenuItem mnuItem = (MenuItem)sender;
		    
			// This defaults to the highlighted background if selected.
			e.DrawBackground();
						
			// Retrieve the image from an ImageList control.
			Image menuImage = imgMenu.Images[mnuItem.Index];
			
			// Draw the image.
			e.Graphics.DrawImage(menuImage, e.Bounds.Left + 3, e.Bounds.Top + 2);
			
			// Draw the text with the supplied colors and in the set region.
			e.Graphics.DrawString(mnuItem.Text, e.Font, new SolidBrush(e.ForeColor), e.Bounds.Left + 25, e.Bounds.Top + 3);
		}
	}
}
