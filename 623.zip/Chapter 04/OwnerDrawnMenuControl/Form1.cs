using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Drawing.Text;

namespace OwnerDrawnMenuControl
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.MainMenu mainMenu1;
		internal System.Windows.Forms.MenuItem mnuFile;
		internal System.Windows.Forms.MenuItem mnuFonts;
		internal System.Windows.Forms.ImageList imgMenu;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.mnuFile = new System.Windows.Forms.MenuItem();
			this.mnuFonts = new System.Windows.Forms.MenuItem();
			this.imgMenu = new System.Windows.Forms.ImageList(this.components);
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuFile});
			// 
			// mnuFile
			// 
			this.mnuFile.Index = 0;
			this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuFonts});
			this.mnuFile.Text = "File";
			// 
			// mnuFonts
			// 
			this.mnuFonts.Index = 0;
			this.mnuFonts.Text = "Fonts";
			// 
			// imgMenu
			// 
			this.imgMenu.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imgMenu.ImageSize = new System.Drawing.Size(16, 16);
			this.imgMenu.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgMenu.ImageStream")));
			this.imgMenu.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "MenuControlClient";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			mnuFile.MenuItems.Add(new ImageMenuItem("New", imgMenu.Images[0]));
			mnuFile.MenuItems.Add(new ImageMenuItem("Open", imgMenu.Images[1]));
			mnuFile.MenuItems.Add(new ImageMenuItem("Save", imgMenu.Images[2]));
			
			InstalledFontCollection fonts = new InstalledFontCollection();
			
			foreach (FontFamily family in fonts.Families)
			{
				try
				{
					mnuFonts.MenuItems.Add(new ImageMenuItem(family.Name,
												   new Font(family, 10), null, Color.CornflowerBlue));
				}
				catch
				{
					// Catch invalid fonts/styles and ignore them.
				}
			}

		}
	}
}
