using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Text;

namespace OwnerDrawnMenuControl
{
	public class ImageMenuItem : MenuItem
	{
		private Font font;
		private Color foreColor;
		private Image image;
        
		public Font Font
		{
			get
			{
				return font;
			}
			set
			{
				font = value;
			}
		}
		
		public Image Image
		{
			get
			{
				return image;
			}
			set
			{
				image = value;
			}
		}

		public Color ForeColor
		{
			get
			{
				return foreColor;
			}
			set
			{
				foreColor = value;
			}
		}
		
		public ImageMenuItem(string text, Font font, Image image, Color foreColor) : base(text)
		{
			this.Font = font;
			this.Image = image;
			this.ForeColor = foreColor;
			this.OwnerDraw = true;
		}
	
		public ImageMenuItem(string text, Image image) : base(text)
		{
			// Choose a suitable default color and font.
			this.Font = new Font("Tahoma", 8);
			this.Image = image;
			this.ForeColor = SystemColors.MenuText;
			this.OwnerDraw = true;
		}
		
		protected override void OnMeasureItem(System.Windows.Forms.MeasureItemEventArgs e)
		{
			base.OnMeasureItem(e);
            
			// Measure size needed to display text.
			e.ItemHeight = (int)e.Graphics.MeasureString(this.Text, this.Font).Height + 5;
			e.ItemWidth = (int)e.Graphics.MeasureString(this.Text, this.Font).Width + 30;
		}
        
		protected override void OnDrawItem(System.Windows.Forms.DrawItemEventArgs e)
		{
			base.OnDrawItem(e);

			// Determine whether disabled text is needed.
			Color textColor;
			if (this.Enabled == false)
			{
				textColor = SystemColors.GrayText;
			}
			else
			{
				e.DrawBackground();
				if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
				{
					textColor = SystemColors.HighlightText;
				}
				else
				{
					textColor = this.ForeColor;
				}
			}
	

			// Draw the image.
			if (Image != null)
			{
				if (this.Enabled == false)
				{
					ControlPaint.DrawImageDisabled(e.Graphics, Image,
						e.Bounds.Left + 3, e.Bounds.Top + 2, SystemColors.Menu);
				}
				else
				{
					e.Graphics.DrawImage(Image, e.Bounds.Left + 3, e.Bounds.Top + 2);
				}
			}
			
			// Draw the text with the supplied colors and in the set region.
			e.Graphics.DrawString(this.Text, this.Font, new SolidBrush(textColor),
				e.Bounds.Left + 25, e.Bounds.Top + 3);

		}
	}
		 
}
