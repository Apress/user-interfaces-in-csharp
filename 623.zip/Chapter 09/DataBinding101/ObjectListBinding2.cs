using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace DataBinding101
{
	/// <summary>
	/// Summary description for ObjectListBinding2.
	/// </summary>
	public class ObjectListBinding2 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.ListBox lstCity;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ObjectListBinding2()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lstCity = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// lstCity
			// 
			this.lstCity.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.lstCity.IntegralHeight = false;
			this.lstCity.Location = new System.Drawing.Point(4, 9);
			this.lstCity.Name = "lstCity";
			this.lstCity.Size = new System.Drawing.Size(248, 216);
			this.lstCity.TabIndex = 3;
			// 
			// ObjectListBinding2
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(260, 234);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lstCity});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "ObjectListBinding2";
			this.Text = "ObjectListBinding2";
			this.Load += new System.EventHandler(this.ObjectListBinding2_Load);
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new ObjectListBinding2());
		}

		private void ObjectListBinding2_Load(object sender, System.EventArgs e)
		{
			City2[] cityChoices = {new City2("Seattle", "U.S.A."), 
									 new City2("New York", "U.S.A."), new City2("Tokyo", "Japan"), 
									 new City2("Montreal", "Canada")};

			lstCity.DataSource = cityChoices;

		}
	
	}

	public class City2
	{
		private string name;
		private string country;

		public string Name
		{
			get
			{
				return name;
			}
			set
			{
				name = value;
			}
		}

		public string Country
		{
			get
			{
				return country;
			}
			set
			{
				country = value;
			}
		}

		public City2(string name, string country)
		{
			this.Name = name;
			this.Country = country;
		}

		public override string ToString()
		{
			return Name + ", " + Country;
		}

	}

}
