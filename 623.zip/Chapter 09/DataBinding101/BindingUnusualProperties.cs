using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing.Text;

namespace DataBinding101
{
	/// <summary>
	/// Summary description for BindingUnusualProperties.
	/// </summary>
	public class BindingUnusualProperties : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.ListBox lstFonts;
		internal System.Windows.Forms.Label lblSampleText;
		internal System.Windows.Forms.ListBox lstColors;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public BindingUnusualProperties()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Label2 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.lstFonts = new System.Windows.Forms.ListBox();
			this.lblSampleText = new System.Windows.Forms.Label();
			this.lstColors = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// Label2
			// 
			this.Label2.Location = new System.Drawing.Point(210, 13);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(140, 12);
			this.Label2.TabIndex = 9;
			this.Label2.Text = "Choose a Font:";
			// 
			// Label1
			// 
			this.Label1.Location = new System.Drawing.Point(14, 13);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(140, 12);
			this.Label1.TabIndex = 8;
			this.Label1.Text = "Choose a Color:";
			// 
			// lstFonts
			// 
			this.lstFonts.Location = new System.Drawing.Point(210, 29);
			this.lstFonts.Name = "lstFonts";
			this.lstFonts.Size = new System.Drawing.Size(180, 134);
			this.lstFonts.TabIndex = 7;
			// 
			// lblSampleText
			// 
			this.lblSampleText.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.lblSampleText.Location = new System.Drawing.Point(18, 185);
			this.lblSampleText.Name = "lblSampleText";
			this.lblSampleText.Size = new System.Drawing.Size(372, 96);
			this.lblSampleText.TabIndex = 6;
			this.lblSampleText.Text = "Click an item in one of the lists above to change the font or color of this text." +
				" Once the initial conditions are set up (i.e., the binding), this operation happ" +
				"ens automatically.";
			// 
			// lstColors
			// 
			this.lstColors.Location = new System.Drawing.Point(14, 29);
			this.lstColors.Name = "lstColors";
			this.lstColors.Size = new System.Drawing.Size(176, 134);
			this.lstColors.TabIndex = 5;
			// 
			// BindingUnusualProperties
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(404, 294);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Label2,
																		  this.Label1,
																		  this.lstFonts,
																		  this.lblSampleText,
																		  this.lstColors});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "BindingUnusualProperties";
			this.Text = "Binding Unusual Properties";
			this.Load += new System.EventHandler(this.BindingUnusualProperties_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void BindingUnusualProperties_Load(object sender, System.EventArgs e)
		{
			// These are our final data sources: two ArrayList objects.
			ArrayList fontObjList = new ArrayList();
			ArrayList colorObjList = new ArrayList();

			// The InstalledFonts collection allows us to enumerate installed fonts.
			// Each FontFamily needs to be converted to a genuine Font object
			// before it is suitable for data binding to the Control.Font property.
			InstalledFontCollection InstalledFonts = new InstalledFontCollection();
			foreach (FontFamily family in InstalledFonts.Families)
			{
				try
				{
					fontObjList.Add(new Font(family, 12));
				}
				catch
				{
					// We end up here if the font could not be created
					// with the default style.
				}
			}

			// In order to retrieve the list of colors, we need to first retrieve
			// the strings for the KnownColor enumeration, and then convert each one
			// into a suitable color object.
			string[] colorNames;
			colorNames = System.Enum.GetNames(typeof(KnownColor));
			TypeConverter cnvrt = TypeDescriptor.GetConverter(typeof(KnownColor));

			foreach (string colorName in colorNames)
			{
				colorObjList.Add(Color.FromKnownColor((KnownColor)cnvrt.ConvertFromString(colorName)));
			}

			// We can now bind both our list controls.
			lstColors.DataSource = colorObjList;
			lstColors.DisplayMember = "Name";
			lstFonts.DataSource = fontObjList;
			lstFonts.DisplayMember = "Name";

			// The label is bound to both data sources.
			lblSampleText.DataBindings.Add("ForeColor", colorObjList, "");
			lblSampleText.DataBindings.Add("Font", fontObjList, "");

		}

		
		[STAThread]
		static void Main() 
		{
			Application.Run(new BindingUnusualProperties());
		}
	}
}
