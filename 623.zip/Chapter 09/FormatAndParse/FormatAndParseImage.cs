using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace FormatAndParse
{
	/// <summary>
	/// Summary description for FormatAndParseImage.
	/// </summary>
	public class FormatAndParseImage : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.GroupBox GroupBox1;
		internal System.Windows.Forms.PictureBox picProduct;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.Label lblStatus;
		internal System.Windows.Forms.ComboBox cboModelName;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FormatAndParseImage()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.GroupBox1 = new System.Windows.Forms.GroupBox();
			this.picProduct = new System.Windows.Forms.PictureBox();
			this.Label1 = new System.Windows.Forms.Label();
			this.lblStatus = new System.Windows.Forms.Label();
			this.cboModelName = new System.Windows.Forms.ComboBox();
			this.GroupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// GroupBox1
			// 
			this.GroupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.picProduct});
			this.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.GroupBox1.Location = new System.Drawing.Point(12, 52);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Size = new System.Drawing.Size(352, 128);
			this.GroupBox1.TabIndex = 22;
			this.GroupBox1.TabStop = false;
			this.GroupBox1.Text = "Display Value for ProductImage";
			// 
			// picProduct
			// 
			this.picProduct.Location = new System.Drawing.Point(16, 24);
			this.picProduct.Name = "picProduct";
			this.picProduct.Size = new System.Drawing.Size(128, 88);
			this.picProduct.TabIndex = 18;
			this.picProduct.TabStop = false;
			// 
			// Label1
			// 
			this.Label1.Location = new System.Drawing.Point(20, 20);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(64, 16);
			this.Label1.TabIndex = 21;
			this.Label1.Text = "Product:";
			// 
			// lblStatus
			// 
			this.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.lblStatus.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.lblStatus.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.lblStatus.Location = new System.Drawing.Point(0, 218);
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Size = new System.Drawing.Size(388, 24);
			this.lblStatus.TabIndex = 20;
			// 
			// cboModelName
			// 
			this.cboModelName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboModelName.Location = new System.Drawing.Point(84, 16);
			this.cboModelName.Name = "cboModelName";
			this.cboModelName.Size = new System.Drawing.Size(248, 21);
			this.cboModelName.TabIndex = 19;
			// 
			// FormatAndParseImage
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(388, 242);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.GroupBox1,
																		  this.Label1,
																		  this.lblStatus,
																		  this.cboModelName});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "FormatAndParseImage";
			this.Text = "FormatAndParseImage";
			this.Load += new System.EventHandler(this.FormatAndParseImage_Load);
			this.GroupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void FormatAndParseImage_Load(object sender, System.EventArgs e)
		{
			DataSet dsStore = new DataSet();
			dsStore.ReadXmlSchema(Application.StartupPath + "\\store.xsd");
			dsStore.ReadXml(Application.StartupPath + "\\store.xml");
			
			cboModelName.DataSource = dsStore.Tables["Products"];
			cboModelName.DisplayMember = "ModelName";

			Binding pictureBinding = new Binding("Image", dsStore.Tables["Products"], 
				"ProductImage");
			pictureBinding.Format += new ConvertEventHandler(FileToImage);
			pictureBinding.Parse += new ConvertEventHandler(ImageToFile);

			picProduct.DataBindings.Add(pictureBinding);

		}

		private void FileToImage(object sender, ConvertEventArgs e)
		{
			if (e.DesiredType == typeof(Image))
			{
				// Store the filename.
				picProduct.Tag = e.Value;

				// Look up the corresponding file, and create an Image object.
				e.Value = Image.FromFile(Application.StartupPath + "\\" + e.Value);
			}
		}

		private void ImageToFile(object sender, ConvertEventArgs e)
		{
			if (e.DesiredType == typeof(string))
			{
				// Substitute the filename.
				e.Value = picProduct.Tag;
			}
		}
		[STAThread]
		static void Main() 
		{
			Application.Run(new FormatAndParseImage());
		}	
	}
}
