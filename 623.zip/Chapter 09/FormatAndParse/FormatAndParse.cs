using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;


namespace FormatAndParse
{
	/// <summary>
	/// Summary description for FormatAndParse.
	/// </summary>
	public class FormatAndParse : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.GroupBox GroupBox1;
		internal System.Windows.Forms.TextBox txtUnitCost;
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.Label lblStatus;
		internal System.Windows.Forms.ComboBox cboModelName;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FormatAndParse()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.GroupBox1 = new System.Windows.Forms.GroupBox();
			this.txtUnitCost = new System.Windows.Forms.TextBox();
			this.Label2 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.lblStatus = new System.Windows.Forms.Label();
			this.cboModelName = new System.Windows.Forms.ComboBox();
			this.GroupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// GroupBox1
			// 
			this.GroupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.txtUnitCost,
																					this.Label2});
			this.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.GroupBox1.Location = new System.Drawing.Point(12, 34);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Size = new System.Drawing.Size(352, 136);
			this.GroupBox1.TabIndex = 22;
			this.GroupBox1.TabStop = false;
			// 
			// txtUnitCost
			// 
			this.txtUnitCost.Location = new System.Drawing.Point(150, 35);
			this.txtUnitCost.Name = "txtUnitCost";
			this.txtUnitCost.Size = new System.Drawing.Size(128, 21);
			this.txtUnitCost.TabIndex = 14;
			this.txtUnitCost.Text = "";
			// 
			// Label2
			// 
			this.Label2.Location = new System.Drawing.Point(16, 40);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(128, 16);
			this.Label2.TabIndex = 17;
			this.Label2.Text = "Display Value for Price:";
			// 
			// Label1
			// 
			this.Label1.Location = new System.Drawing.Point(14, 10);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(64, 16);
			this.Label1.TabIndex = 21;
			this.Label1.Text = "Product:";
			// 
			// lblStatus
			// 
			this.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.lblStatus.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.lblStatus.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.lblStatus.Location = new System.Drawing.Point(0, 198);
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Size = new System.Drawing.Size(372, 24);
			this.lblStatus.TabIndex = 20;
			// 
			// cboModelName
			// 
			this.cboModelName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboModelName.Location = new System.Drawing.Point(78, 8);
			this.cboModelName.Name = "cboModelName";
			this.cboModelName.Size = new System.Drawing.Size(248, 21);
			this.cboModelName.TabIndex = 19;
			// 
			// FormatAndParse
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(372, 222);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.GroupBox1,
																		  this.Label1,
																		  this.lblStatus,
																		  this.cboModelName});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "FormatAndParse";
			this.Text = "FormatAndParse";
			this.Load += new System.EventHandler(this.FormatAndParse_Load);
			this.GroupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void FormatAndParse_Load(object sender, System.EventArgs e)
		{
			DataSet dsStore = new DataSet();
			dsStore.ReadXmlSchema(Application.StartupPath + "\\store.xsd");
			dsStore.ReadXml(Application.StartupPath + "\\store.xml");

			cboModelName.DataSource = dsStore.Tables["Products"];
			cboModelName.DisplayMember = "ModelName";

			// Create the binding.
			Binding costBinding = new Binding("Text", dsStore.Tables["Products"], 
				"UnitCost");

			// Connect the methods for formatting and parsing data.
			costBinding.Format += new ConvertEventHandler(DecimalToCurrencyString);
			costBinding.Parse += new ConvertEventHandler(CurrencyStringToDecimal);

			// Add the binding.
			txtUnitCost.DataBindings.Add(costBinding);

		}
		private void DecimalToCurrencyString(object sender, ConvertEventArgs e)
		{
			if (e.DesiredType == typeof(string))
			{
				// Use the ToString method to format the value as currency ("c").
				e.Value = ((decimal)e.Value).ToString("c");
			}
		}

		private void CurrencyStringToDecimal(object sender, ConvertEventArgs e)
		{
			if (e.DesiredType == typeof(decimal))
			{
				// Convert the string back to decimal using the shared Parse method.
				e.Value = Decimal.Parse(e.Value.ToString(),
					System.Globalization.NumberStyles.Currency, null);
			}
		}
		private void TableChanged(object sender, System.Data.DataColumnChangeEventArgs e)
		{
			lblStatus.Text = "Detected change. Column " + e.Column.ColumnName;
			lblStatus.Text += " updated to " + e.ProposedValue.ToString() + ".";
		}

		[STAThread]
		static void Main() 
		{
			Application.Run(new FormatAndParse());
		}	
	}
}
