using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace TreeViewDataBinding
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Panel Panel2;
		internal System.Windows.Forms.Panel Panel3;
		internal System.Windows.Forms.Label lblInfo;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.Splitter Splitter1;
		internal System.Windows.Forms.TreeView treeDB;
		internal System.Windows.Forms.Panel Panel1;
		internal System.Windows.Forms.Button cmdClose;
		internal System.Windows.Forms.GroupBox GroupBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Panel2 = new System.Windows.Forms.Panel();
			this.Panel3 = new System.Windows.Forms.Panel();
			this.lblInfo = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.Splitter1 = new System.Windows.Forms.Splitter();
			this.treeDB = new System.Windows.Forms.TreeView();
			this.Panel1 = new System.Windows.Forms.Panel();
			this.cmdClose = new System.Windows.Forms.Button();
			this.GroupBox1 = new System.Windows.Forms.GroupBox();
			this.Panel2.SuspendLayout();
			this.Panel3.SuspendLayout();
			this.Panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// Panel2
			// 
			this.Panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.Panel3,
																				 this.Splitter1,
																				 this.treeDB});
			this.Panel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.Panel2.Location = new System.Drawing.Point(5, 5);
			this.Panel2.Name = "Panel2";
			this.Panel2.Size = new System.Drawing.Size(446, 264);
			this.Panel2.TabIndex = 8;
			// 
			// Panel3
			// 
			this.Panel3.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.lblInfo,
																				 this.Label1});
			this.Panel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.Panel3.Location = new System.Drawing.Point(239, 0);
			this.Panel3.Name = "Panel3";
			this.Panel3.Size = new System.Drawing.Size(207, 264);
			this.Panel3.TabIndex = 7;
			// 
			// lblInfo
			// 
			this.lblInfo.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.lblInfo.BackColor = System.Drawing.SystemColors.Window;
			this.lblInfo.Location = new System.Drawing.Point(16, 12);
			this.lblInfo.Name = "lblInfo";
			this.lblInfo.Size = new System.Drawing.Size(176, 240);
			this.lblInfo.TabIndex = 1;
			// 
			// Label1
			// 
			this.Label1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.Label1.BackColor = System.Drawing.SystemColors.Window;
			this.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.Label1.Location = new System.Drawing.Point(4, 0);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(200, 264);
			this.Label1.TabIndex = 2;
			// 
			// Splitter1
			// 
			this.Splitter1.Location = new System.Drawing.Point(236, 0);
			this.Splitter1.Name = "Splitter1";
			this.Splitter1.Size = new System.Drawing.Size(3, 264);
			this.Splitter1.TabIndex = 6;
			this.Splitter1.TabStop = false;
			// 
			// treeDB
			// 
			this.treeDB.Dock = System.Windows.Forms.DockStyle.Left;
			this.treeDB.ImageIndex = -1;
			this.treeDB.Name = "treeDB";
			this.treeDB.SelectedImageIndex = -1;
			this.treeDB.Size = new System.Drawing.Size(236, 264);
			this.treeDB.TabIndex = 4;
			this.treeDB.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeDB_AfterSelect);
			this.treeDB.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeDB_BeforeExpand);
			// 
			// Panel1
			// 
			this.Panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.cmdClose,
																				 this.GroupBox1});
			this.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.Panel1.Location = new System.Drawing.Point(5, 269);
			this.Panel1.Name = "Panel1";
			this.Panel1.Size = new System.Drawing.Size(446, 36);
			this.Panel1.TabIndex = 7;
			// 
			// cmdClose
			// 
			this.cmdClose.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.cmdClose.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmdClose.Location = new System.Drawing.Point(372, 12);
			this.cmdClose.Name = "cmdClose";
			this.cmdClose.Size = new System.Drawing.Size(72, 24);
			this.cmdClose.TabIndex = 4;
			this.cmdClose.Text = "Close";
			this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
			// 
			// GroupBox1
			// 
			this.GroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Size = new System.Drawing.Size(444, 8);
			this.GroupBox1.TabIndex = 5;
			this.GroupBox1.TabStop = false;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(456, 310);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Panel2,
																		  this.Panel1});
			this.DockPadding.All = 5;
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Panel2.ResumeLayout(false);
			this.Panel3.ResumeLayout(false);
			this.Panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private ProductDatabase DataClass = new ProductDatabase();

		private void Form1_Load(object sender, System.EventArgs e)
		{
			TreeNode nodeParent;

			foreach (DataRow row in DataClass.GetCategories().Rows)
			{
				// Add the category node.
				nodeParent = treeDB.Nodes.Add(row[ProductDatabase.CategoryField.Name].ToString());
				nodeParent.ImageIndex = 0;

				// Store the disconnected category information.
				nodeParent.Tag = row;

				// Add a "dummy" node.
				nodeParent.Nodes.Add("*");
			}
		
		}

		private void treeDB_BeforeExpand(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			TreeNode nodeSelected, nodeChild;
			nodeSelected = e.Node;

			if (nodeSelected.Nodes[0].Text == "*")
			{
				// This is a dummy node.
				nodeSelected.Nodes.Clear();

				foreach (DataRow row in
					DataClass.GetProductsInCategory((DataRow)nodeSelected.Tag))
				{
					nodeChild = nodeSelected.Nodes.Add(row[ProductDatabase.ProductField.Name].ToString());

					// Store the disconnected product information.
					nodeChild.Tag = row;
					nodeChild.ImageIndex = 1;
					nodeChild.SelectedImageIndex = 1;
				}
			}

		}

		private void treeDB_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			 lblInfo.Text = DataClass.GetDisplayText((DataRow)e.Node.Tag);
		}

		private void cmdClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}


	public class ProductDatabase
	{
		public class Tables
		{
			public const string Product = "Products";
			public const string Category = "Categories";
		}

		public class ProductField
		{
			public const string Name = "ModelName";
			public const string Description = "Description";
		}

		public class CategoryField
		{
			public const string Name = "CategoryName";
		}

		private DataSet dsStore;
		DataRelation relCategoryProduct;

		public ProductDatabase()
		{
			dsStore = new DataSet();

			dsStore.ReadXmlSchema(Application.StartupPath + "\\store.xsd");
			dsStore.ReadXml(Application.StartupPath + "\\store.xml");

			// Define the relation.
			relCategoryProduct = new DataRelation("Prod_Cat", 
				dsStore.Tables["Categories"].Columns["CategoryID"], 
				dsStore.Tables["Products"].Columns["CategoryID"]);
			dsStore.Relations.Add(relCategoryProduct);
		}

		public DataTable GetCategories()
		{
			return dsStore.Tables["Categories"];
		}

		public DataRow[] GetProductsInCategory(DataRow rowParent)
		{
			return rowParent.GetChildRows(relCategoryProduct);
		}

		public string GetDisplayText(DataRow row)
		{
			string text = "";

			switch (row.Table.TableName)
			{
				case Tables.Product:
					text = "ID: " + row[0] + "\n";
					text += "Name: " + row[ProductField.Name] + "\n\n";
					text += row[ProductField.Description];
					break;
			}
			return text;
		}

	}

}
