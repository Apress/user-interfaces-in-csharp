using System;
using System.Drawing;
using System.Windows.Forms;

public class DataGridPriceIconColumn : DataGridColumnStyle
{
	public decimal NicePrice;

	public DataGridPriceIconColumn(decimal nicePrice)
	{
		this.NicePrice = nicePrice;
	}

	protected override void Abort(int rowNum)
	{
		// Do nothing.
	}

	protected override bool Commit(CurrencyManager dataSource, int rowNum)
	{
		return true;
	}

	protected override void Edit(CurrencyManager source,
		int rowNum, System.Drawing.Rectangle bounds,
		bool readOnly, string instantText, bool cellIsVisible)
	{
		// Do nothing.
	}

	protected override void Edit(CurrencyManager source,
		int rowNum, System.Drawing.Rectangle bounds, bool readOnly)
	{
		// Do nothing.
	}

	protected override void Edit(CurrencyManager source,
							int rowNum, System.Drawing.Rectangle bounds,
							bool readOnly, string instantText)
	{
		// Do nothing.
	}
	protected override int GetMinimumHeight()
	{
		return 20;
	}

	protected override int GetPreferredHeight(System.Drawing.Graphics g,
		object value)
	{
		return 20;
	}

	protected override System.Drawing.Size GetPreferredSize(
		System.Drawing.Graphics g, object value)
	{
		return new Size(100, 20);
	}

	protected override void Paint(System.Drawing.Graphics g,
		System.Drawing.Rectangle bounds, CurrencyManager source, int rowNum,
		System.Drawing.Brush backBrush, System.Drawing.Brush foreBrush,
		bool alignToRight)
	{
		// Clear the cell.
		g.FillRegion(backBrush, new Region(bounds));

		decimal price = (decimal)this.GetColumnValueAtRow(source, rowNum);
		Icon priceIcon;
		if (price < NicePrice)
		{
			priceIcon = new Icon(Application.StartupPath + "\\happy2.ico");

			// Draw the optional "nice price" icon.
			g.DrawIcon(priceIcon, new Rectangle(bounds.X, bounds.Y, 16, 16));
		}

		// Draw the text.
		g.DrawString(price.ToString("C"), new Font("Tahoma", (float)8.25), 
			Brushes.Black, bounds.X + 20, bounds.Y + 2);
	}

	protected override void Paint(System.Drawing.Graphics g,
		System.Drawing.Rectangle bounds, CurrencyManager source,
		int rowNum, bool alignToRight)
	{
		this.Paint(g, bounds, source, rowNum, Brushes.White, Brushes.Black,
			alignToRight);
	}

	protected override void Paint(System.Drawing.Graphics g,
		System.Drawing.Rectangle bounds, CurrencyManager source, int rowNum)
	{
		this.Paint(g, bounds, source, rowNum, Brushes.White, Brushes.Black, false);
	}

}

