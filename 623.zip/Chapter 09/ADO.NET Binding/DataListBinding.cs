using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ADO.NET_Binding
{
	/// <summary>
	/// Summary description for DataListBinding.
	/// </summary>
	public class DataListBinding : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.ListBox lstName;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DataListBinding()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lstName = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// lstName
			// 
			this.lstName.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.lstName.IntegralHeight = false;
			this.lstName.Location = new System.Drawing.Point(8, 8);
			this.lstName.Name = "lstName";
			this.lstName.Size = new System.Drawing.Size(232, 184);
			this.lstName.TabIndex = 1;
			// 
			// DataListBinding
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(248, 202);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lstName});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "DataListBinding";
			this.Text = "DataListBinding";
			this.Load += new System.EventHandler(this.DataListBinding_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void DataListBinding_Load(object sender, System.EventArgs e)
		{
			DataSet dsStore = new DataSet();
			dsStore.ReadXmlSchema(Application.StartupPath + "\\store.xsd");
			dsStore.ReadXml(Application.StartupPath + "\\store.xml");

			lstName.DataSource = dsStore.Tables["Products"];
			lstName.DisplayMember = "ModelName";

		}

		[STAThread]
		static void Main() 
		{
			Application.Run(new DataListBinding());
		}
	}
}
