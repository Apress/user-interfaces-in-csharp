using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ADO.NET_Binding
{
	/// <summary>
	/// Summary description for MultipleControlBinding.
	/// </summary>
	public class MultipleControlBinding : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.GroupBox GroupBox1;
		internal System.Windows.Forms.Label lblDescription;
		internal System.Windows.Forms.Label lblUnitCost;
		internal System.Windows.Forms.Label lblModelNumber;
		internal System.Windows.Forms.Button cmdNext;
		internal System.Windows.Forms.Button cmdPrev;
		internal System.Windows.Forms.ComboBox cboModelName;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MultipleControlBinding()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.GroupBox1 = new System.Windows.Forms.GroupBox();
			this.lblDescription = new System.Windows.Forms.Label();
			this.lblUnitCost = new System.Windows.Forms.Label();
			this.lblModelNumber = new System.Windows.Forms.Label();
			this.cmdNext = new System.Windows.Forms.Button();
			this.cmdPrev = new System.Windows.Forms.Button();
			this.cboModelName = new System.Windows.Forms.ComboBox();
			this.GroupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// GroupBox1
			// 
			this.GroupBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.GroupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.lblDescription,
																					this.lblUnitCost,
																					this.lblModelNumber});
			this.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.GroupBox1.Location = new System.Drawing.Point(18, 47);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Size = new System.Drawing.Size(312, 168);
			this.GroupBox1.TabIndex = 10;
			this.GroupBox1.TabStop = false;
			// 
			// lblDescription
			// 
			this.lblDescription.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.lblDescription.Location = new System.Drawing.Point(8, 58);
			this.lblDescription.Name = "lblDescription";
			this.lblDescription.Size = new System.Drawing.Size(296, 98);
			this.lblDescription.TabIndex = 6;
			// 
			// lblUnitCost
			// 
			this.lblUnitCost.Location = new System.Drawing.Point(168, 16);
			this.lblUnitCost.Name = "lblUnitCost";
			this.lblUnitCost.Size = new System.Drawing.Size(136, 32);
			this.lblUnitCost.TabIndex = 5;
			// 
			// lblModelNumber
			// 
			this.lblModelNumber.Location = new System.Drawing.Point(8, 16);
			this.lblModelNumber.Name = "lblModelNumber";
			this.lblModelNumber.Size = new System.Drawing.Size(140, 32);
			this.lblModelNumber.TabIndex = 4;
			// 
			// cmdNext
			// 
			this.cmdNext.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.cmdNext.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmdNext.Location = new System.Drawing.Point(238, 227);
			this.cmdNext.Name = "cmdNext";
			this.cmdNext.Size = new System.Drawing.Size(92, 28);
			this.cmdNext.TabIndex = 9;
			this.cmdNext.Text = "Next >>";
			this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
			// 
			// cmdPrev
			// 
			this.cmdPrev.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.cmdPrev.Enabled = false;
			this.cmdPrev.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmdPrev.Location = new System.Drawing.Point(18, 227);
			this.cmdPrev.Name = "cmdPrev";
			this.cmdPrev.Size = new System.Drawing.Size(92, 28);
			this.cmdPrev.TabIndex = 8;
			this.cmdPrev.Text = "<< Prev";
			this.cmdPrev.Click += new System.EventHandler(this.cmdPrev_Click);
			// 
			// cboModelName
			// 
			this.cboModelName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboModelName.Location = new System.Drawing.Point(14, 11);
			this.cboModelName.Name = "cboModelName";
			this.cboModelName.Size = new System.Drawing.Size(316, 21);
			this.cboModelName.TabIndex = 7;
			// 
			// MultipleControlBinding
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(344, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.GroupBox1,
																		  this.cmdNext,
																		  this.cmdPrev,
																		  this.cboModelName});
			this.Name = "MultipleControlBinding";
			this.Text = "Manual Navigation Control";
			this.Load += new System.EventHandler(this.MultipleControlBinding_Load);
			this.GroupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion


		private BindingManagerBase storeBinding;

		private void MultipleControlBinding_Load(object sender, System.EventArgs e)
		{
			DataSet dsStore = new DataSet();

			dsStore.ReadXmlSchema(Application.StartupPath + "\\store.xsd");
			dsStore.ReadXml(Application.StartupPath + "\\store.xml");

			cboModelName.DataSource = dsStore.Tables["Products"];
			cboModelName.DisplayMember = "ModelName";

			lblModelNumber.DataBindings.Add("Text", 
				dsStore.Tables["Products"], "ModelNumber");
			lblUnitCost.DataBindings.Add("Text", 
				dsStore.Tables["Products"], "UnitCost");
			lblDescription.DataBindings.Add("Text", 
				dsStore.Tables["Products"], "Description");

			storeBinding = this.BindingContext[dsStore.Tables["Products"]];
			storeBinding.PositionChanged += new EventHandler(Binding_PositionChanged);
		}

		[STAThread]
		static void Main() 
		{
			Application.Run(new MultipleControlBinding());
		}

		private void cmdNext_Click(object sender, System.EventArgs e)
		{
			    storeBinding.Position++;
		}

		private void cmdPrev_Click(object sender, System.EventArgs e)
		{
			    storeBinding.Position--;
		}

		private void Binding_PositionChanged(object sender, System.EventArgs e)
		{
			if (storeBinding.Position == storeBinding.Count - 1)
			{
				cmdNext.Enabled = false;
			}
			else
			{
				cmdNext.Enabled = true;
			}

			if (storeBinding.Position == 0)
			{
				cmdPrev.Enabled = false;
			}
			else
			{
				cmdPrev.Enabled = true;
			}
		}

	}
}
