using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ADO.NET_Binding
{
	/// <summary>
	/// Summary description for Unsynchronized.
	/// </summary>
	public class Unsynchronized : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.GroupBox grp;
		internal System.Windows.Forms.ListBox lstProduct;
		internal System.Windows.Forms.GroupBox grpCategory;
		internal System.Windows.Forms.ListBox lstCategory;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Unsynchronized()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.grp = new System.Windows.Forms.GroupBox();
			this.lstProduct = new System.Windows.Forms.ListBox();
			this.grpCategory = new System.Windows.Forms.GroupBox();
			this.lstCategory = new System.Windows.Forms.ListBox();
			this.grp.SuspendLayout();
			this.grpCategory.SuspendLayout();
			this.SuspendLayout();
			// 
			// grp
			// 
			this.grp.Controls.AddRange(new System.Windows.Forms.Control[] {
																			  this.lstProduct});
			this.grp.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.grp.Location = new System.Drawing.Point(6, 137);
			this.grp.Name = "grp";
			this.grp.Size = new System.Drawing.Size(280, 136);
			this.grp.TabIndex = 5;
			this.grp.TabStop = false;
			// 
			// lstProduct
			// 
			this.lstProduct.Location = new System.Drawing.Point(16, 24);
			this.lstProduct.Name = "lstProduct";
			this.lstProduct.Size = new System.Drawing.Size(248, 95);
			this.lstProduct.TabIndex = 1;
			// 
			// grpCategory
			// 
			this.grpCategory.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.lstCategory});
			this.grpCategory.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.grpCategory.Location = new System.Drawing.Point(6, 0);
			this.grpCategory.Name = "grpCategory";
			this.grpCategory.Size = new System.Drawing.Size(280, 136);
			this.grpCategory.TabIndex = 4;
			this.grpCategory.TabStop = false;
			// 
			// lstCategory
			// 
			this.lstCategory.Location = new System.Drawing.Point(16, 24);
			this.lstCategory.Name = "lstCategory";
			this.lstCategory.Size = new System.Drawing.Size(248, 95);
			this.lstCategory.TabIndex = 0;
			// 
			// Unsynchronized
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(300, 290);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.grp,
																		  this.grpCategory});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Unsynchronized";
			this.Text = "Unsynchronized";
			this.Load += new System.EventHandler(this.Unsynchronized_Load);
			this.grp.ResumeLayout(false);
			this.grpCategory.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void Unsynchronized_Load(object sender, System.EventArgs e)
		{
			// Make sure all the controls in this group box have a different binding.
			grpCategory.BindingContext = new BindingContext();

			DataSet dsStore = new DataSet();
			dsStore.ReadXmlSchema(Application.StartupPath + "\\store.xsd");
			dsStore.ReadXml(Application.StartupPath + "\\store.xml");
	
            lstCategory.DataSource = dsStore.Tables["Categories"];
			lstCategory.DisplayMember = "CategoryName";
			
			lstProduct.DataSource = dsStore.Tables["Categories"];
			lstProduct.DisplayMember = "CategoryName";
		}

		[STAThread]
		static void Main() 
		{
			Application.Run(new Unsynchronized());
		}
	}
}
