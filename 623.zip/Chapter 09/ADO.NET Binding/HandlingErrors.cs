using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ADO.NET_Binding
{
	/// <summary>
	/// Summary description for HandlingErrors.
	/// </summary>
	public class HandlingErrors : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Label lblErrorSummary;
		internal System.Windows.Forms.Button cmdNext;
		internal System.Windows.Forms.Button cmdPrev;
		internal System.Windows.Forms.Label Label4;
		internal System.Windows.Forms.GroupBox GroupBox1;
		internal System.Windows.Forms.Label Label3;
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.TextBox txtModelName;
		internal System.Windows.Forms.TextBox txtDescription;
		internal System.Windows.Forms.TextBox txtUnitCost;
		internal System.Windows.Forms.TextBox txtModelNumber;
		internal System.Windows.Forms.ComboBox cboModelName;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public HandlingErrors()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblErrorSummary = new System.Windows.Forms.Label();
			this.cmdNext = new System.Windows.Forms.Button();
			this.cmdPrev = new System.Windows.Forms.Button();
			this.Label4 = new System.Windows.Forms.Label();
			this.GroupBox1 = new System.Windows.Forms.GroupBox();
			this.Label3 = new System.Windows.Forms.Label();
			this.Label2 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.txtModelName = new System.Windows.Forms.TextBox();
			this.txtDescription = new System.Windows.Forms.TextBox();
			this.txtUnitCost = new System.Windows.Forms.TextBox();
			this.txtModelNumber = new System.Windows.Forms.TextBox();
			this.cboModelName = new System.Windows.Forms.ComboBox();
			this.GroupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// lblErrorSummary
			// 
			this.lblErrorSummary.ForeColor = System.Drawing.Color.Red;
			this.lblErrorSummary.Location = new System.Drawing.Point(26, 296);
			this.lblErrorSummary.Name = "lblErrorSummary";
			this.lblErrorSummary.Size = new System.Drawing.Size(328, 40);
			this.lblErrorSummary.TabIndex = 29;
			// 
			// cmdNext
			// 
			this.cmdNext.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.cmdNext.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmdNext.Location = new System.Drawing.Point(322, 348);
			this.cmdNext.Name = "cmdNext";
			this.cmdNext.Size = new System.Drawing.Size(92, 28);
			this.cmdNext.TabIndex = 28;
			this.cmdNext.Text = "Next >>";
			this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
			// 
			// cmdPrev
			// 
			this.cmdPrev.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.cmdPrev.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmdPrev.Location = new System.Drawing.Point(18, 348);
			this.cmdPrev.Name = "cmdPrev";
			this.cmdPrev.Size = new System.Drawing.Size(92, 28);
			this.cmdPrev.TabIndex = 27;
			this.cmdPrev.Text = "<< Prev";
			this.cmdPrev.Click += new System.EventHandler(this.cmdPrev_Click);
			// 
			// Label4
			// 
			this.Label4.Location = new System.Drawing.Point(14, 16);
			this.Label4.Name = "Label4";
			this.Label4.Size = new System.Drawing.Size(88, 16);
			this.Label4.TabIndex = 26;
			this.Label4.Text = "Select a Record:";
			// 
			// GroupBox1
			// 
			this.GroupBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.GroupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.Label3,
																					this.Label2,
																					this.Label1,
																					this.txtModelName,
																					this.txtDescription,
																					this.txtUnitCost,
																					this.txtModelNumber});
			this.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.GroupBox1.Location = new System.Drawing.Point(14, 48);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Size = new System.Drawing.Size(400, 228);
			this.GroupBox1.TabIndex = 25;
			this.GroupBox1.TabStop = false;
			// 
			// Label3
			// 
			this.Label3.Location = new System.Drawing.Point(220, 56);
			this.Label3.Name = "Label3";
			this.Label3.Size = new System.Drawing.Size(36, 16);
			this.Label3.TabIndex = 18;
			this.Label3.Text = "Cost:";
			// 
			// Label2
			// 
			this.Label2.Location = new System.Drawing.Point(16, 56);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(52, 16);
			this.Label2.TabIndex = 17;
			this.Label2.Text = "Model:";
			// 
			// Label1
			// 
			this.Label1.Location = new System.Drawing.Point(16, 28);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(52, 16);
			this.Label1.TabIndex = 16;
			this.Label1.Text = "Name:";
			// 
			// txtModelName
			// 
			this.txtModelName.Location = new System.Drawing.Point(68, 24);
			this.txtModelName.Name = "txtModelName";
			this.txtModelName.Size = new System.Drawing.Size(316, 21);
			this.txtModelName.TabIndex = 15;
			this.txtModelName.Text = "";
			// 
			// txtDescription
			// 
			this.txtDescription.Location = new System.Drawing.Point(12, 92);
			this.txtDescription.Multiline = true;
			this.txtDescription.Name = "txtDescription";
			this.txtDescription.Size = new System.Drawing.Size(372, 116);
			this.txtDescription.TabIndex = 14;
			this.txtDescription.Text = "";
			// 
			// txtUnitCost
			// 
			this.txtUnitCost.Location = new System.Drawing.Point(256, 52);
			this.txtUnitCost.Name = "txtUnitCost";
			this.txtUnitCost.Size = new System.Drawing.Size(128, 21);
			this.txtUnitCost.TabIndex = 13;
			this.txtUnitCost.Text = "";
			// 
			// txtModelNumber
			// 
			this.txtModelNumber.Location = new System.Drawing.Point(68, 52);
			this.txtModelNumber.Name = "txtModelNumber";
			this.txtModelNumber.Size = new System.Drawing.Size(136, 21);
			this.txtModelNumber.TabIndex = 12;
			this.txtModelNumber.Text = "";
			// 
			// cboModelName
			// 
			this.cboModelName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboModelName.Location = new System.Drawing.Point(106, 10);
			this.cboModelName.Name = "cboModelName";
			this.cboModelName.Size = new System.Drawing.Size(308, 21);
			this.cboModelName.TabIndex = 24;
			// 
			// HandlingErrors
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(428, 386);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblErrorSummary,
																		  this.cmdNext,
																		  this.cmdPrev,
																		  this.Label4,
																		  this.GroupBox1,
																		  this.cboModelName});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "HandlingErrors";
			this.Text = "HandlingErrors";
			this.Load += new System.EventHandler(this.HandlingErrors_Load);
			this.GroupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion



		[STAThread]
		static void Main() 
		{
			Application.Run(new HandlingErrors());
		}

		private BindingManagerBase storeBinding;
		private int currentPage;
		private bool errFlag;

		private void HandlingErrors_Load(object sender, System.EventArgs e)
		{
			DataSet dsStore = new DataSet();

			dsStore.ReadXmlSchema(Application.StartupPath + "\\store.xsd");
			dsStore.ReadXml(Application.StartupPath + "\\store.xml");
			
			cboModelName.DataSource = dsStore.Tables["Products"];
			cboModelName.DisplayMember = "ModelName";
			
			txtModelName.DataBindings.Add("Text", dsStore.Tables["Products"], "ModelName");
			txtModelNumber.DataBindings.Add("Text", dsStore.Tables["Products"], "ModelNumber");
			txtUnitCost.DataBindings.Add("Text", dsStore.Tables["Products"], "UnitCost");
			txtDescription.DataBindings.Add("Text", dsStore.Tables["Products"], "Description");
			
			storeBinding = this.BindingContext[dsStore.Tables["Products"]];

			storeBinding.PositionChanged += new EventHandler(Binding_PositionChanged);
			dsStore.Tables["Products"].ColumnChanged += new
				DataColumnChangeEventHandler(TableChanging);

		}


		private void Binding_PositionChanged(object sender, System.EventArgs e)
		{
			if (errFlag)
			{
				// Reset the page.
				storeBinding.Position = currentPage;
			}
			else
			{
				// Allow the page to change and update the currentPage variable.
				currentPage = storeBinding.Position;
			}
		}
		private void TableChanging(object sender, System.Data.DataColumnChangeEventArgs e)
		{
			string errors = DBStore.ValidateProduct(e.Row);

			if (errors == "")
			{
				errFlag = false;
			}
			else
			{
				errFlag = true;
			}

			lblErrorSummary.Text = errors;
		}

		private void cmdNext_Click(object sender, System.EventArgs e)
		{
			storeBinding.Position++
		}

		private void cmdPrev_Click(object sender, System.EventArgs e)
		{
			storeBinding.Position--
		}

	}


	public class DBStore
	{
		public static string ValidateProduct(DataRow row)
		{
			string errors = "";

			if (((decimal)row["UnitCost"]) <= 0)
			{
				errors += "* UnitCost value too low\n";
			}

			if (row["ModelNumber"].ToString() == "")
			{
				errors += "* You must specify a ModelNumber\n";
			}

			if (row["ModelName"].ToString() == "")
			{
				errors += "* You must specify a ModelName\n";
			}

			return errors;
		}
	}
}
