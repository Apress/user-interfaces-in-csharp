using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace EventTracker
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.GroupBox GroupBox1;
		internal System.Windows.Forms.Label Label4;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.PictureBox pic;
		internal System.Windows.Forms.TextBox txt;
		internal System.Windows.Forms.Button cmd;
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.Label Label3;
		internal System.Windows.Forms.ListBox lstLog;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.GroupBox1 = new System.Windows.Forms.GroupBox();
			this.Label4 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.pic = new System.Windows.Forms.PictureBox();
			this.txt = new System.Windows.Forms.TextBox();
			this.cmd = new System.Windows.Forms.Button();
			this.Label2 = new System.Windows.Forms.Label();
			this.Label3 = new System.Windows.Forms.Label();
			this.lstLog = new System.Windows.Forms.ListBox();
			this.GroupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// GroupBox1
			// 
			this.GroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.GroupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.Label4,
																					this.Label1,
																					this.pic,
																					this.txt,
																					this.cmd,
																					this.Label2});
			this.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.GroupBox1.Location = new System.Drawing.Point(8, 5);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Size = new System.Drawing.Size(384, 148);
			this.GroupBox1.TabIndex = 9;
			this.GroupBox1.TabStop = false;
			// 
			// Label4
			// 
			this.Label4.Location = new System.Drawing.Point(92, 108);
			this.Label4.Name = "Label4";
			this.Label4.Size = new System.Drawing.Size(56, 16);
			this.Label4.TabIndex = 5;
			this.Label4.Text = "And here:";
			// 
			// Label1
			// 
			this.Label1.Location = new System.Drawing.Point(6, 24);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(144, 16);
			this.Label1.TabIndex = 2;
			this.Label1.Text = "Test keyboard events here:";
			// 
			// pic
			// 
			this.pic.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pic.Location = new System.Drawing.Point(156, 48);
			this.pic.Name = "pic";
			this.pic.Size = new System.Drawing.Size(192, 48);
			this.pic.TabIndex = 3;
			this.pic.TabStop = false;
			this.pic.Click += new System.EventHandler(this.pic_Click);
			this.pic.MouseEnter += new System.EventHandler(this.pic_MouseEnter);
			this.pic.MouseHover += new System.EventHandler(this.pic_MouseHover);
			this.pic.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pic_MouseUp);
			this.pic.DoubleClick += new System.EventHandler(this.pic_DoubleClick);
			this.pic.MouseLeave += new System.EventHandler(this.pic_MouseLeave);
			this.pic.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pic_MouseDown);
			// 
			// txt
			// 
			this.txt.Location = new System.Drawing.Point(156, 20);
			this.txt.Name = "txt";
			this.txt.Size = new System.Drawing.Size(192, 21);
			this.txt.TabIndex = 1;
			this.txt.Text = "";
			this.txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_KeyDown);
			this.txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_KeyPress);
			this.txt.TextChanged += new System.EventHandler(this.txt_TextChanged);
			this.txt.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_KeyUp);
			// 
			// cmd
			// 
			this.cmd.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmd.Location = new System.Drawing.Point(156, 100);
			this.cmd.Name = "cmd";
			this.cmd.Size = new System.Drawing.Size(88, 28);
			this.cmd.TabIndex = 4;
			this.cmd.Text = "Button1";
			this.cmd.Click += new System.EventHandler(this.pic_Click);
			this.cmd.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pic_MouseUp);
			this.cmd.MouseEnter += new System.EventHandler(this.pic_MouseEnter);
			this.cmd.MouseHover += new System.EventHandler(this.pic_MouseHover);
			this.cmd.MouseLeave += new System.EventHandler(this.pic_MouseLeave);
			this.cmd.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pic_MouseDown);
			// 
			// Label2
			// 
			this.Label2.Location = new System.Drawing.Point(20, 52);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(128, 16);
			this.Label2.TabIndex = 2;
			this.Label2.Text = "Test mouse events here:";
			// 
			// Label3
			// 
			this.Label3.Location = new System.Drawing.Point(24, 105);
			this.Label3.Name = "Label3";
			this.Label3.Size = new System.Drawing.Size(64, 24);
			this.Label3.TabIndex = 8;
			this.Label3.Text = "Label3";
			// 
			// lstLog
			// 
			this.lstLog.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.lstLog.IntegralHeight = false;
			this.lstLog.Location = new System.Drawing.Point(8, 161);
			this.lstLog.Name = "lstLog";
			this.lstLog.Size = new System.Drawing.Size(384, 212);
			this.lstLog.TabIndex = 7;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(400, 378);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.GroupBox1,
																		  this.Label3,
																		  this.lstLog});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "Event Tracker";
			this.GroupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion


		private void Log(String data)
		{
			lstLog.Items.Add(data);
			int itemsPerPage = (int)(lstLog.Height / lstLog.ItemHeight);
			lstLog.TopIndex = lstLog.Items.Count - itemsPerPage;
		}
																									

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void txt_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			Log("Key Down: " + e.KeyCode.ToString() + e.KeyValue.ToString());
		}

		private void txt_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			Log("Key Press: " + e.KeyChar.ToString());
		}

		private void txt_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			Log("Key Up: " + e.KeyCode.ToString() + e.KeyValue.ToString() + " Text is: " + txt.Text);
		}

		private void txt_TextChanged(object sender, System.EventArgs e)
		{
			Log("Changed: " + " Text is: " + txt.Text);
		}

		private void pic_MouseEnter(object sender, System.EventArgs e)
		{
			Log("Mouse Enter");
		}

		private void pic_MouseHover(object sender, System.EventArgs e)
		{
			Log("Mouse Hover");
		}

		private void pic_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			Log("Mouse Down: X=" + e.X.ToString() + "Y=" + e.Y.ToString() + " Button=" + e.Button.ToString());
		}

		private void pic_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			Log("Mouse Down: X=" + e.X.ToString() + "Y=" + e.Y.ToString() + " Button=" + e.Button.ToString());
		}

		private void pic_Click(object sender, System.EventArgs e)
		{
			Log("Click");
		}

		private void pic_DoubleClick(object sender, System.EventArgs e)
		{
			Log("Double Click");
		}

		private void pic_MouseLeave(object sender, System.EventArgs e)
		{
			Log("Mouse Leave");
		}
	}
}
