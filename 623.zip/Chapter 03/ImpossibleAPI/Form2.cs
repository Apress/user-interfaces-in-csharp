using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ImpossibleAPI
{
	/// <summary>
	/// Summary description for Form2.
	/// </summary>
	public class Form2 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Button Button3;
		internal System.Windows.Forms.Button Button2;
		internal System.Windows.Forms.Button Button1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form2()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Button3 = new System.Windows.Forms.Button();
			this.Button2 = new System.Windows.Forms.Button();
			this.Button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// Button3
			// 
			this.Button3.Location = new System.Drawing.Point(124, 60);
			this.Button3.Name = "Button3";
			this.Button3.Size = new System.Drawing.Size(88, 32);
			this.Button3.TabIndex = 5;
			this.Button3.Text = "Become Child of Parent2";
			this.Button3.Click += new System.EventHandler(this.Button3_Click);
			// 
			// Button2
			// 
			this.Button2.Location = new System.Drawing.Point(16, 60);
			this.Button2.Name = "Button2";
			this.Button2.Size = new System.Drawing.Size(88, 32);
			this.Button2.TabIndex = 4;
			this.Button2.Text = "Become Child of Parent1";
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			// 
			// Button1
			// 
			this.Button1.Location = new System.Drawing.Point(16, 16);
			this.Button1.Name = "Button1";
			this.Button1.Size = new System.Drawing.Size(88, 32);
			this.Button1.TabIndex = 3;
			this.Button1.Text = "Become Parent";
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			// 
			// Form2
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(292, 150);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Button3,
																		  this.Button2,
																		  this.Button1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form2";
			this.Text = "Form2";
			this.ResumeLayout(false);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			this.Hide();
			this.MdiParent = null;
			this.IsMdiContainer = true;
			this.Show();
		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
			this.Hide();
			this.IsMdiContainer = false;
			this.MdiParent = Global.Main2;
			this.Show();
		}

		private void Button3_Click(object sender, System.EventArgs e)
		{
			this.Hide();
			this.IsMdiContainer = false;
			this.MdiParent = Global.Main1;
			this.Show();
		}
	}
}
