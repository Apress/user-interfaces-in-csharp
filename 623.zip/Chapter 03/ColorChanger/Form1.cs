using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ColorChanger
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Label lblSaturation;
		internal System.Windows.Forms.Label lblHue;
		internal System.Windows.Forms.Label lblBrightness;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.ListBox lstColors;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblSaturation = new System.Windows.Forms.Label();
			this.lblHue = new System.Windows.Forms.Label();
			this.lblBrightness = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.lstColors = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// lblSaturation
			// 
			this.lblSaturation.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblSaturation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblSaturation.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.lblSaturation.Location = new System.Drawing.Point(264, 56);
			this.lblSaturation.Name = "lblSaturation";
			this.lblSaturation.Size = new System.Drawing.Size(136, 20);
			this.lblSaturation.TabIndex = 9;
			this.lblSaturation.Text = " Saturation";
			// 
			// lblHue
			// 
			this.lblHue.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblHue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblHue.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.lblHue.Location = new System.Drawing.Point(264, 32);
			this.lblHue.Name = "lblHue";
			this.lblHue.Size = new System.Drawing.Size(136, 20);
			this.lblHue.TabIndex = 8;
			this.lblHue.Text = " Hue";
			// 
			// lblBrightness
			// 
			this.lblBrightness.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblBrightness.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblBrightness.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.lblBrightness.Location = new System.Drawing.Point(264, 8);
			this.lblBrightness.Name = "lblBrightness";
			this.lblBrightness.Size = new System.Drawing.Size(136, 20);
			this.lblBrightness.TabIndex = 7;
			this.lblBrightness.Text = " Brightness";
			// 
			// Label1
			// 
			this.Label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Label1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Label1.Location = new System.Drawing.Point(8, 8);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(200, 20);
			this.Label1.TabIndex = 6;
			this.Label1.Text = " Choose a Background Color:";
			// 
			// lstColors
			// 
			this.lstColors.Location = new System.Drawing.Point(8, 36);
			this.lstColors.Name = "lstColors";
			this.lstColors.Size = new System.Drawing.Size(200, 238);
			this.lstColors.TabIndex = 5;
			this.lstColors.SelectedIndexChanged += new System.EventHandler(this.lstColors_SelectedIndexChanged);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(472, 290);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblSaturation,
																		  this.lblHue,
																		  this.lblBrightness,
																		  this.Label1,
																		  this.lstColors});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "Color Changer";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			string[] colorNames;
			colorNames = System.Enum.GetNames(typeof(KnownColor));

			lstColors.Items.AddRange(colorNames);
		}

		private void lstColors_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			KnownColor selectedColor;
			selectedColor = (KnownColor)System.Enum.Parse(typeof(KnownColor), lstColors.Text);
			
			this.BackColor = System.Drawing.Color.FromKnownColor(selectedColor);
			
			// Display color information.
			lblBrightness.Text = "Brightness = " +
                             this.BackColor.GetBrightness().ToString();
            lblHue.Text = "Hue = " + this.BackColor.GetHue().ToString();
			lblSaturation.Text = "Saturation = " + this.BackColor.GetSaturation().ToString();
		}

		

	}
}
